import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Student, AttendanceRecord, AttendanceType } from '../data/studentsData';
import { formatIndoDate } from '../services/attendanceService';

export interface ReportRow {
  no: number;
  nis: string;
  name: string;
  gender: string;
  className: string;
  masuk: string;
  pulang: string;
  dhuhur: string;
  jumat: string;
  keputrian: string;
  exemptInfo?: string;
}

export function buildReportMatrix(
  students: Student[],
  records: AttendanceRecord[],
  targetDate?: string
): ReportRow[] {
  // Filter records if single date target
  const relevantRecords = targetDate 
    ? records.filter(r => r.date === targetDate)
    : records;

  // Build map: `${studentNis}_${type}` -> status
  const studentRecordsMap = new Map<string, AttendanceRecord>();
  for (const r of relevantRecords) {
    const key = `${r.studentNis}_${r.type}`;
    // If multiple days, we can keep the latest or count
    studentRecordsMap.set(key, r);
  }

  return students.map((st, idx) => {
    const getStatusStr = (type: AttendanceType): string => {
      // Religious exemption check for Maximilianus, Diva Widiana, & Jevanya
      if (st.exemptReligious && (type === 'dhuhur' || type === 'jumat' || type === 'keputrian')) {
        return '-'; // Kosongi / dikecualikan per instruksi user
      }

      // Gender check
      if (type === 'jumat' && st.gender !== 'L') return '-';
      if (type === 'keputrian' && st.gender !== 'P') return '-';

      const rec = studentRecordsMap.get(`${st.nis}_${type}`);
      if (!rec) return 'Alpa';
      if (rec.status === 'hadir') return 'Hadir';
      if (rec.status === 'terlambat') return `Terlambat (${rec.timeStr})`;
      if (rec.status === 'haid') return 'Haid';
      if (rec.status === 'izin') return 'Izin';
      if (rec.status === 'sakit') return 'Sakit';
      return 'Alpa';
    };

    return {
      no: idx + 1,
      nis: st.nis,
      name: st.name,
      gender: st.gender,
      className: st.className,
      masuk: getStatusStr('masuk'),
      pulang: getStatusStr('pulang'),
      dhuhur: getStatusStr('dhuhur'),
      jumat: getStatusStr('jumat'),
      keputrian: getStatusStr('keputrian'),
      exemptInfo: st.exemptReligious ? 'Non-Muslim (Dikecualikan Sholat/Keputrian)' : ''
    };
  });
}

export function exportToExcel({
  students,
  records,
  dateRangeStr,
  className
}: {
  students: Student[];
  records: AttendanceRecord[];
  dateRangeStr: string;
  className: string;
}) {
  const rows = buildReportMatrix(students, records);

  const worksheetData = [
    ["PEMERINTAH KABUPATEN MALANG"],
    ["DINAS PENDIDIKAN"],
    ["SMP NEGERI 1 KALIPARE"],
    ["Jl. Raya Kalipare No. 1, Kalipare, Kab. Malang, Jawa Timur"],
    [""],
    ["LAPORAN REKAPITULASI PRESENSI KEHADIRAN SISWA"],
    [`Filter Periode: ${dateRangeStr}`],
    [`Kelas: ${className}`],
    [""],
    [
      "NO",
      "NIS",
      "NAMA LENGKAP",
      "L/P",
      "KELAS",
      "ABSEN MASUK",
      "ABSEN PULANG",
      "SHOLAT DHUHUR",
      "SHOLAT JUMAT",
      "KEPUTRIAN",
      "KETERANGAN KHUSUS"
    ],
    ...rows.map(r => [
      r.no,
      r.nis,
      r.name,
      r.gender,
      r.className,
      r.masuk,
      r.pulang,
      r.dhuhur,
      r.jumat,
      r.keputrian,
      r.exemptInfo || ""
    ]),
    [""],
    ["Catatan Khusus:"],
    ["* Siswa atas nama Maximilianus Wahyu Galih Pradana, Diva Widiana, dan Jevanya Anastasya Blegur dikecualikan dari presensi ibadah Sholat & Keputrian sesuai instruksi sekolah."]
  ];

  const ws = XLSX.utils.aoa_to_sheet(worksheetData);

  // Column widths
  ws['!cols'] = [
    { wch: 5 },  // No
    { wch: 10 }, // NIS
    { wch: 35 }, // Nama
    { wch: 6 },  // L/P
    { wch: 15 }, // Kelas
    { wch: 18 }, // Masuk
    { wch: 18 }, // Pulang
    { wch: 16 }, // Dhuhur
    { wch: 16 }, // Jumat
    { wch: 16 }, // Keputrian
    { wch: 38 }, // Keterangan
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Rekap_Presensi");

  const cleanClassName = className.replace(/\s+/g, '_');
  const filename = `Rekap_Absensi_SMPN1_Kalipare_${cleanClassName}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, filename);
}

export function exportToPDF({
  students,
  records,
  dateRangeStr,
  className
}: {
  students: Student[];
  records: AttendanceRecord[];
  dateRangeStr: string;
  className: string;
}) {
  const doc = new jsPDF('landscape', 'mm', 'a4');
  const pageWidth = doc.internal.pageSize.getWidth();

  // Kop Surat Sekolah
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('PEMERINTAH KABUPATEN MALANG', pageWidth / 2, 14, { align: 'center' });
  doc.text('DINAS PENDIDIKAN', pageWidth / 2, 20, { align: 'center' });
  doc.setFontSize(16);
  doc.text('SMP NEGERI 1 KALIPARE', pageWidth / 2, 27, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text('Jl. Raya Kalipare No. 1, Kec. Kalipare, Kab. Malang, Jawa Timur - Kode Pos: 65166', pageWidth / 2, 32, { align: 'center' });

  // Double horizontal rule
  doc.setLineWidth(0.8);
  doc.line(14, 35, pageWidth - 14, 35);
  doc.setLineWidth(0.2);
  doc.line(14, 36.2, pageWidth - 14, 36.2);

  // Subtitle
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('LAPORAN REKAPITULASI KEHADIRAN SISWA & KEGIATAN IBADAH', pageWidth / 2, 43, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Periode: ${dateRangeStr}  |  Kelas: ${className}`, pageWidth / 2, 49, { align: 'center' });

  const rows = buildReportMatrix(students, records);

  const tableBody = rows.map(r => [
    r.no,
    r.nis,
    r.name,
    r.gender,
    r.className,
    r.masuk,
    r.pulang,
    r.dhuhur,
    r.jumat,
    r.keputrian,
    r.exemptInfo ? 'Non-Muslim (-)' : ''
  ]);

  autoTable(doc, {
    startY: 53,
    head: [[
      'No', 
      'NIS', 
      'Nama Siswa', 
      'L/P', 
      'Kelas', 
      'Masuk', 
      'Pulang', 
      'Dhuhur', 
      'Jumatan (L)', 
      'Keputrian (P)',
      'Ket'
    ]],
    body: tableBody,
    theme: 'grid',
    headStyles: {
      fillColor: [30, 58, 138], // Deep navy blue
      textColor: [255, 255, 255],
      fontSize: 8,
      halign: 'center',
      fontStyle: 'bold'
    },
    bodyStyles: {
      fontSize: 7.5,
      cellPadding: 1.5,
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { halign: 'center', cellWidth: 15 },
      2: { cellWidth: 55 },
      3: { halign: 'center', cellWidth: 10 },
      4: { halign: 'center', cellWidth: 22 },
      5: { halign: 'center', cellWidth: 25 },
      6: { halign: 'center', cellWidth: 22 },
      7: { halign: 'center', cellWidth: 22 },
      8: { halign: 'center', cellWidth: 22 },
      9: { halign: 'center', cellWidth: 24 },
      10: { halign: 'center', cellWidth: 25 },
    },
    styles: {
      lineColor: [200, 200, 200],
      lineWidth: 0.1
    },
    didDrawPage: (data) => {
      // Footer page numbering
      const str = `Halaman ${doc.getNumberOfPages()}`;
      doc.setFontSize(8);
      doc.text(str, pageWidth - 20, doc.internal.pageSize.getHeight() - 8, { align: 'right' });
    }
  });

  // Signature Block
  const finalY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 12;
  const pageHeight = doc.internal.pageSize.getHeight();
  
  if (finalY + 35 < pageHeight) {
    const todayIndo = formatIndoDate(new Date().toISOString().slice(0, 10));
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    
    // Left side: Guru BK / Piket
    doc.text('Petugas Presensi / Piket,', 30, finalY);
    doc.text('_______________________', 30, finalY + 20);
    doc.text('NIP. ............................', 30, finalY + 25);

    // Right side: Kepala Sekolah
    doc.text(`Kalipare, ${todayIndo}`, pageWidth - 80, finalY);
    doc.text('Kepala SMP Negeri 1 Kalipare,', pageWidth - 80, finalY + 5);
    doc.text('_______________________', pageWidth - 80, finalY + 20);
    doc.text('NIP. ............................', pageWidth - 80, finalY + 25);
  }

  const cleanClassName = className.replace(/\s+/g, '_');
  const filename = `Laporan_Absensi_SMPN1_Kalipare_${cleanClassName}_${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(filename);
}
