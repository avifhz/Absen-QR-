import { Student, INITIAL_STUDENTS } from '../data/studentsData';
import { NESAKA_LOGO_BASE64 } from './logoBase64';
import firebaseConfig from '../../firebase-applet-config.json';

/**
 * Generates the Code.gs backend script for Google Apps Script connected to Google Sheets & Firebase Firestore.
 */
export function generateCodeGs(students: Student[] = INITIAL_STUDENTS): string {
  const studentsJson = JSON.stringify(students.map(s => ({
    nis: s.nis,
    name: s.name,
    className: s.className,
    gender: s.gender,
    exemptReligious: !!s.exemptReligious
  })));

  return `/**
 * ========================================================================
 * SISTEM PRESENSI QR CODE, BARCODE & RFID - SMP NEGERI 1 KALIPARE (NESAKA)
 * Backend Google Apps Script (Code.gs)
 * ========================================================================
 * Database: Google Spreadsheet Aktif & Terhubung ke Firebase Firestore
 * Pengembang: Tim IT SMP Negeri 1 Kalipare, Kab. Malang, Jawa Timur
 * 
 * Aturan Operasional:
 *  1. Absen Masuk: Senin - Jumat (Maks. 06:45 WIB, >06:45 terdata Terlambat)
 *  2. Absen Pulang: Senin - Jumat (Bebas Pukul Pulang)
 *  3. Sholat Dhuhur Berjamaah: Senin - Kamis Pukul 11:50 - 12:30 WIB.
 *     (Terkunci total di luar jam ini & TIDAK ADA menu buka paksa)
 *  4. Sholat Jumat (L) & Keputrian (P): Khusus Jumat Pukul 11:15 - 12:30 WIB
 *  5. Pengecualian Non-Muslim: Maximilianus Wahyu Galih Pradana, Diva Widiana,
 *     dan Jevanya Anastasya Blegur hanya absen Masuk & Pulang.
 *  6. Sinkronisasi Ganda: Data tersimpan di Google Sheets & Firebase Firestore
 *  7. Unduh Rekapan: Excel (.xlsx), PDF Kop Surat Resmi, dan Tab Sheet Baru
 * ========================================================================
 */

// Konfigurasi Database Sheet
var SHEET_STUDENTS = 'DATA_SISWA';
var SHEET_ATTENDANCE = 'PRESENSI_HARIAN';
var SHEET_REKAP = 'REKAPITULASI';

// Konfigurasi Firebase Firestore
var FIREBASE_PROJECT_ID = '${firebaseConfig.projectId || 'gen-lang-client-0302890897'}';
var FIRESTORE_DATABASE_ID = '${firebaseConfig.firestoreDatabaseId || 'ai-studio-dadb62ae-28ed-4648-9b39-e5cb0bd9d02d'}';
var FIREBASE_API_KEY = '${firebaseConfig.apiKey || 'AIzaSyB8b4o8tqKaVIPZoKoKd5ZrSGnGCilnlQU'}';

/**
 * Handler HTTP GET untuk menyajikan Web App (Index.html)
 */
function doGet(e) {
  try {
    setupSheetsIfEmpty();
  } catch (err) {
    Logger.log('Inisialisasi sheet: ' + err.toString());
  }

  var template = HtmlService.createTemplateFromFile('Index');
  return template.evaluate()
    .setTitle('Presensi Siswa SMP Negeri 1 Kalipare')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * Menu Kustom saat Google Spreadsheet dibuka
 */
function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('Presensi Nesaka')
    .addItem('🌐 Buka Aplikasi Web Presensi', 'openWebAppModal')
    .addSeparator()
    .addItem('⚙️ Inisialisasi / Reset Master 479 Siswa', 'setupSheetsIfEmpty')
    .addItem('📊 Buat Tab Rekapitulasi Baru', 'promptRekapToSheet')
    .addItem('🔄 Sinkronkan Data ke Firebase Firestore', 'syncAllAttendanceToFirestore')
    .addItem('ℹ️ Petunjuk Penggunaan & Pemasangan', 'showHelpModal')
    .addToUi();
}

/**
 * Membuka modal dialog berisi link Web App
 */
function openWebAppModal() {
  var url = ScriptApp.getService().getUrl();
  var html = '<div style="font-family:sans-serif;padding:16px;text-align:center;">'
    + '<h3 style="color:#1e3a8a;margin-top:0;">Web App Presensi SMPN 1 Kalipare</h3>'
    + '<p style="color:#475569;font-size:13px;">Buka aplikasi pemindai presensi di PC atau HP:</p>'
    + '<p><a href="' + url + '" target="_blank" style="background:#2563eb;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:bold;display:inline-block;">Buka Web App Presensi ↗</a></p>'
    + '<p style="font-size:11px;color:#94a3b8;margin-top:16px;">Tersambung ke Google Spreadsheet &amp; Firebase Firestore</p>'
    + '</div>';
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutput(html).setWidth(480).setHeight(220), 'Presensi Nesaka');
}

/**
 * Inisialisasi otomatis sheet dan master data 479 siswa SMP Negeri 1 Kalipare
 */
function setupSheetsIfEmpty() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  // 1. Setup Sheet DATA_SISWA
  var studentSheet = ss.getSheetByName(SHEET_STUDENTS);
  if (!studentSheet) {
    studentSheet = ss.insertSheet(SHEET_STUDENTS);
  }

  if (studentSheet.getLastRow() <= 1) {
    studentSheet.clear();
    var headers = ['NIS', 'Nama Siswa', 'Kelas', 'Jenis Kelamin', 'Pengecualian Agama', 'No WhatsApp Ortu', 'Status'];
    studentSheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    
    var headerRange = studentSheet.getRange(1, 1, 1, headers.length);
    headerRange.setBackground('#1e3a8a')
      .setFontColor('#ffffff')
      .setFontWeight('bold')
      .setHorizontalAlignment('center');
    studentSheet.setFrozenRows(1);

    var defaultStudents = ${studentsJson};
    var rows = defaultStudents.map(function(s) {
      return [
        s.nis,
        s.name,
        s.className,
        s.gender,
        s.exemptReligious ? 'YA (Non-Muslim)' : 'TIDAK',
        s.parentPhone || '',
        'AKTIF'
      ];
    });

    if (rows.length > 0) {
      studentSheet.getRange(2, 1, rows.length, headers.length).setValues(rows);
    }
    studentSheet.autoResizeColumns(1, headers.length);
  }

  // 2. Setup Sheet PRESENSI_HARIAN
  var attSheet = ss.getSheetByName(SHEET_ATTENDANCE);
  if (!attSheet) {
    attSheet = ss.insertSheet(SHEET_ATTENDANCE);
  }

  if (attSheet.getLastRow() === 0) {
    var attHeaders = [
      'Timestamp', 
      'Tanggal (YYYY-MM-DD)', 
      'Waktu (WIB)', 
      'NIS', 
      'Nama Siswa', 
      'Kelas', 
      'Gender', 
      'Jenis Presensi', 
      'Status', 
      'Metode Scan', 
      'Keterangan'
    ];
    attSheet.getRange(1, 1, 1, attHeaders.length).setValues([attHeaders]);
    var attHeaderRange = attSheet.getRange(1, 1, 1, attHeaders.length);
    attHeaderRange.setBackground('#0f172a')
      .setFontColor('#f8fafc')
      .setFontWeight('bold')
      .setHorizontalAlignment('center');
    attSheet.setFrozenRows(1);
    attSheet.autoResizeColumns(1, attHeaders.length);
  }

  return { success: true, message: 'Sheet dan Master Data Siswa berhasil diinisialisasi!' };
}

/**
 * Mendapatkan daftar seluruh siswa dari Sheet DATA_SISWA
 */
function getStudentsList() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_STUDENTS);
  if (!sheet || sheet.getLastRow() <= 1) {
    setupSheetsIfEmpty();
    sheet = ss.getSheetByName(SHEET_STUDENTS);
  }

  var data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 7).getValues();
  var students = [];
  for (var i = 0; i < data.length; i++) {
    var row = data[i];
    if (!row[0]) continue;
    students.push({
      nis: String(row[0]).trim(),
      name: String(row[1]).trim(),
      className: String(row[2]).trim(),
      gender: String(row[3]).trim().toUpperCase(),
      exemptReligious: String(row[4]).indexOf('YA') !== -1,
      parentPhone: String(row[5] || '').trim()
    });
  }
  return students;
}

/**
 * Mencatat presensi siswa ke Sheet PRESENSI_HARIAN dan sinkron ke Firebase Firestore
 * payload: { nis, type, status, method, note }
 */
function recordAttendance(payload) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var attSheet = ss.getSheetByName(SHEET_ATTENDANCE);
  if (!attSheet) {
    setupSheetsIfEmpty();
    attSheet = ss.getSheetByName(SHEET_ATTENDANCE);
  }

  var students = getStudentsList();
  var student = null;
  for (var i = 0; i < students.length; i++) {
    if (students[i].nis === String(payload.nis).trim()) {
      student = students[i];
      break;
    }
  }

  if (!student) {
    return { success: false, message: 'Siswa dengan NIS ' + payload.nis + ' tidak ditemukan di Master Data!' };
  }

  // 1. Pengecualian Agama Non-Muslim (Maximilianus, Diva Widiana, Jevanya)
  if (student.exemptReligious && (payload.type === 'dhuhur' || payload.type === 'jumat' || payload.type === 'keputrian')) {
    return {
      success: false,
      exempt: true,
      message: student.name + ' (' + student.className + ') dibebaskan dari presensi ' + payload.type + ' (Siswa Non-Muslim).'
    };
  }

  var now = new Date();
  var timeZone = 'Asia/Jakarta';
  var dateStr = Utilities.formatDate(now, timeZone, 'yyyy-MM-dd');
  var timeStr = Utilities.formatDate(now, timeZone, 'HH:mm:ss');
  var timestamp = Utilities.formatDate(now, timeZone, 'yyyy-MM-dd HH:mm:ss');
  var dayOfWeek = parseInt(Utilities.formatDate(now, timeZone, 'u'), 10); // 1 = Senin, ..., 7 = Minggu
  var hours = parseInt(Utilities.formatDate(now, timeZone, 'HH'), 10);
  var minutes = parseInt(Utilities.formatDate(now, timeZone, 'mm'), 10);
  var totalMinutes = hours * 60 + minutes;

  // 2. ATURAN KETAT SHOLAT DHUHUR BERJAMAAH:
  // Senin s/d Kamis pukul 11:50 - 12:30 WIB. Di luar jam ini terkunci & tidak ada buka paksa!
  if (payload.type === 'dhuhur') {
    if (dayOfWeek === 5) {
      return {
        success: false,
        message: 'Hari ini hari Jumat. Presensi Sholat Dhuhur berjamaah diadakan Senin s/d Kamis. Hari Jumat dialihkan ke Sholat Jumat & Keputrian.'
      };
    }
    if (dayOfWeek < 1 || dayOfWeek > 4) {
      return {
        success: false,
        message: 'Presensi Sholat Dhuhur Berjamaah hanya diadakan hari Senin s/d Kamis pukul 11:50 - 12:30 WIB.'
      };
    }
    if (totalMinutes < 710 || totalMinutes > 750) {
      return {
        success: false,
        message: 'Waktu saat ini ' + timeStr + ' WIB. Presensi Sholat Dhuhur Berjamaah HANYA dibuka pukul 11:50 - 12:30 WIB. Di luar jam ini siswa tidak bisa absen dan tidak ada menu buka paksa.'
      };
    }
  }

  // 3. Aturan Sholat Jumat & Keputrian: Khusus hari Jumat pukul 11:15 - 12:30 WIB
  if (payload.type === 'jumat' || payload.type === 'keputrian') {
    if (dayOfWeek !== 5) {
      return {
        success: false,
        message: 'Presensi ' + payload.type + ' hanya dibuka pada hari JUMAT pukul 11:15 - 12:30 WIB.'
      };
    }
    if (totalMinutes < 675 || totalMinutes > 750) {
      return {
        success: false,
        message: 'Waktu saat ini ' + timeStr + ' WIB. Presensi ' + payload.type + ' HANYA dibuka pukul 11:15 - 12:30 WIB.'
      };
    }
    if (payload.type === 'jumat' && student.gender !== 'L') {
      return { success: false, message: student.name + ' adalah siswi perempuan. Harap gunakan sesi Keputrian.' };
    }
    if (payload.type === 'keputrian' && student.gender !== 'P') {
      return { success: false, message: student.name + ' adalah siswa laki-laki. Harap gunakan sesi Sholat Jumat.' };
    }
  }

  // 4. Cek duplikasi presensi hari ini untuk tipe yang sama
  var lastRow = attSheet.getLastRow();
  if (lastRow > 1) {
    var existingRecords = attSheet.getRange(2, 2, lastRow - 1, 8).getValues();
    for (var r = 0; r < existingRecords.length; r++) {
      var rowDate = Utilities.formatDate(new Date(existingRecords[r][0]), timeZone, 'yyyy-MM-dd');
      var rowNis = String(existingRecords[r][2]).trim();
      var rowType = String(existingRecords[r][6]).trim().toLowerCase();
      
      if (rowDate === dateStr && rowNis === student.nis && rowType === payload.type.toLowerCase()) {
        return {
          success: false,
          alreadyRecorded: true,
          message: student.name + ' SUDAH tercatat pada presensi ' + payload.type + ' hari ini!'
        };
      }
    }
  }

  // 5. Tentukan status kehadiran (terlambat jika lewat 06:45 pada absen masuk)
  var finalStatus = payload.status || 'hadir';
  if (payload.type === 'masuk' && !payload.status) {
    if (totalMinutes > 405) { // 06:45 = 405 menit
      finalStatus = 'terlambat';
    }
  }

  // 6. Simpan baris ke Google Sheets
  var newRow = [
    timestamp,
    dateStr,
    timeStr,
    student.nis,
    student.name,
    student.className,
    student.gender,
    payload.type,
    finalStatus,
    payload.method || 'WEB_APP',
    payload.note || ''
  ];
  attSheet.appendRow(newRow);

  // 7. SINKRONISASI KE FIREBASE FIRESTORE (SESUAI ATURAN VALIDASI SECURITY RULES)
  try {
    syncSingleRecordToFirestore({
      nis: student.nis,
      name: student.name,
      className: student.className,
      gender: student.gender,
      type: payload.type,
      status: finalStatus,
      date: dateStr,
      timeStr: timeStr,
      timestamp: timestamp,
      method: payload.method || 'GAS_SPREADSHEET'
    });
  } catch (fsErr) {
    Logger.log('Firestore notice: ' + fsErr.toString());
  }

  // 8. NOTIFIKASI WHATSAPP KE ORANG TUA (JIKA ADA NOMOR WA)
  var waNotice = '';
  if (student.parentPhone) {
    try {
      var waMsg = '📢 *INFORMASI PRESENSI SMPN 1 KALIPARE*\\n\\n'
        + 'Yth. Wali Murid dari *' + student.name + '* (' + student.className + '), ananda telah tercatat pada presensi *' 
        + payload.type.toUpperCase() + '* pukul ' + timeStr + ' WIB dengan status *' + finalStatus.toUpperCase() + '*.';
      var isSent = sendWhatsAppToParent(student.parentPhone, waMsg);
      if (isSent) waNotice = ' (Notifikasi WA terkirim ke ' + student.parentPhone + ')';
    } catch (waErr) {
      Logger.log('WA notice: ' + waErr.toString());
    }
  }

  return {
    success: true,
    student: student,
    record: {
      date: dateStr,
      time: timeStr,
      type: payload.type,
      status: finalStatus
    },
    message: 'Presensi ' + payload.type + ' ' + student.name + ' berhasil dicatat (' + finalStatus.toUpperCase() + ')!' + waNotice
  };
}

/**
 * Mengirim notifikasi WhatsApp ke orang tua siswa via WhatsApp Gateway
 */
function sendWhatsAppToParent(parentPhone, message) {
  var token = PropertiesService.getScriptProperties().getProperty('FONNTE_TOKEN') || '';
  if (!token || !parentPhone) return false;

  var cleanPhone = String(parentPhone).replace(/\\D/g, '');
  if (cleanPhone.indexOf('0') === 0) cleanPhone = '62' + cleanPhone.substring(1);

  var payload = {
    target: cleanPhone,
    message: message,
    countryCode: '62'
  };

  var options = {
    method: 'post',
    headers: { 'Authorization': token },
    payload: payload,
    muteHttpExceptions: true
  };

  try {
    var res = UrlFetchApp.fetch('https://api.fonnte.com/send', options);
    return res.getResponseCode() === 200;
  } catch (e) {
    return false;
  }
}

/**
 * Sinkronisasi satu rekaman ke Firebase Firestore REST API
 * Mengikuti aturan keamanan: wajib recordId, studentNis, studentName, className, gender, date, type, status
 */
function syncSingleRecordToFirestore(rec) {
  var recordId = 'att_' + rec.date + '_' + rec.nis + '_' + rec.type;
  var url = 'https://firestore.googleapis.com/v1/projects/' + FIREBASE_PROJECT_ID 
    + '/databases/' + FIRESTORE_DATABASE_ID 
    + '/documents/attendance/' + recordId + '?key=' + FIREBASE_API_KEY;

  var docPayload = {
    fields: {
      recordId: { stringValue: recordId },
      studentNis: { stringValue: String(rec.nis) },
      studentName: { stringValue: String(rec.name) },
      className: { stringValue: String(rec.className) },
      gender: { stringValue: String(rec.gender) },
      type: { stringValue: String(rec.type) },
      status: { stringValue: String(rec.status) },
      date: { stringValue: String(rec.date) },
      timeStr: { stringValue: String(rec.timeStr) },
      timestamp: { stringValue: String(rec.timestamp) },
      method: { stringValue: String(rec.method) }
    }
  };

  var options = {
    method: 'patch',
    contentType: 'application/json',
    payload: JSON.stringify(docPayload),
    muteHttpExceptions: true
  };

  var response = UrlFetchApp.fetch(url, options);
  return response.getResponseCode() === 200;
}

/**
 * Sinkronisasi seluruh log presensi di sheet ke Firebase Firestore
 */
function syncAllAttendanceToFirestore() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var attSheet = ss.getSheetByName(SHEET_ATTENDANCE);
  if (!attSheet || attSheet.getLastRow() <= 1) {
    SpreadsheetApp.getUi().alert('Belum ada data presensi untuk disinkronkan.');
    return;
  }

  var data = attSheet.getRange(2, 1, attSheet.getLastRow() - 1, 11).getValues();
  var timeZone = 'Asia/Jakarta';
  var count = 0;

  for (var i = 0; i < data.length; i++) {
    var row = data[i];
    var rDate = Utilities.formatDate(new Date(row[1]), timeZone, 'yyyy-MM-dd');
    syncSingleRecordToFirestore({
      timestamp: String(row[0]),
      date: rDate,
      timeStr: String(row[2]),
      nis: String(row[3]),
      name: String(row[4]),
      className: String(row[5]),
      gender: String(row[6]),
      type: String(row[7]),
      status: String(row[8]),
      method: 'GAS_BULK_SYNC'
    });
    count++;
  }

  SpreadsheetApp.getUi().alert('Berhasil menyinkronkan ' + count + ' data presensi ke Firebase Firestore!');
}

/**
 * Ambil data presensi hari ini
 */
function getTodayAttendance(dateStr) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var attSheet = ss.getSheetByName(SHEET_ATTENDANCE);
  if (!attSheet || attSheet.getLastRow() <= 1) {
    return [];
  }

  var timeZone = 'Asia/Jakarta';
  var targetDate = dateStr || Utilities.formatDate(new Date(), timeZone, 'yyyy-MM-dd');

  var lastRow = attSheet.getLastRow();
  var data = attSheet.getRange(2, 1, lastRow - 1, 11).getValues();
  var results = [];

  for (var i = 0; i < data.length; i++) {
    var row = data[i];
    var rowDate = Utilities.formatDate(new Date(row[1]), timeZone, 'yyyy-MM-dd');
    if (rowDate === targetDate) {
      results.push({
        id: 'rec_' + i,
        timestamp: row[0],
        date: rowDate,
        time: String(row[2]),
        nis: String(row[3]),
        name: String(row[4]),
        className: String(row[5]),
        gender: String(row[6]),
        type: String(row[7]),
        status: String(row[8]),
        method: String(row[9]),
        note: String(row[10])
      });
    }
  }

  return results;
}

/**
 * EKSPORT RESMI KE TAB BARU DI SPREADSHEET
 */
function exportRekapToSheet(rekapData, periodTitle, className) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheetName = 'Rekap_' + (className || 'Semua') + '_' + Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyyMMdd_HHmm');
  var sheet = ss.insertSheet(sheetName);

  // Kop Surat Resmi
  sheet.getRange('A1:L1').merge().setValue('PEMERINTAH KABUPATEN MALANG').setFontWeight('bold').setHorizontalAlignment('center');
  sheet.getRange('A2:L2').merge().setValue('DINAS PENDIDIKAN').setFontWeight('bold').setHorizontalAlignment('center');
  sheet.getRange('A3:L3').merge().setValue('SMP NEGERI 1 KALIPARE').setFontSize(14).setFontWeight('bold').setHorizontalAlignment('center').setFontColor('#1e3a8a');
  sheet.getRange('A4:L4').merge().setValue('REKAPITULASI PRESENSI SISWA - PERIODE: ' + (periodTitle || 'SEMUA')).setFontWeight('bold').setHorizontalAlignment('center');
  sheet.getRange('A5:L5').merge().setValue('Kelas: ' + (className || 'Semua Kelas') + ' | Dicetak: ' + Utilities.formatDate(new Date(), 'Asia/Jakarta', 'dd MMMM yyyy HH:mm WIB')).setFontSize(9).setHorizontalAlignment('center');

  var headers = ['No', 'NIS', 'Nama Siswa', 'Kelas', 'L/P', 'Hadir', 'Terlambat', 'Izin', 'Sakit', 'Haid', 'Alpa', '% Kehadiran'];
  sheet.getRange(7, 1, 1, headers.length).setValues([headers]);
  var hRange = sheet.getRange(7, 1, 1, headers.length);
  hRange.setBackground('#1e3a8a').setFontColor('#ffffff').setFontWeight('bold').setHorizontalAlignment('center');

  var rows = [];
  for (var i = 0; i < rekapData.length; i++) {
    var r = rekapData[i];
    var totalAttended = (r.hadir || 0) + (r.terlambat || 0) + (r.haid || 0);
    var totalDays = totalAttended + (r.izin || 0) + (r.sakit || 0) + (r.alpa || 0);
    var pct = totalDays > 0 ? Math.round((totalAttended / totalDays) * 100) + '%' : '0%';

    rows.push([
      i + 1,
      r.nis,
      r.name,
      r.className,
      r.gender,
      r.hadir || 0,
      r.terlambat || 0,
      r.izin || 0,
      r.sakit || 0,
      r.haid || 0,
      r.alpa || 0,
      pct
    ]);
  }

  if (rows.length > 0) {
    sheet.getRange(8, 1, rows.length, headers.length).setValues(rows);
    var dataRange = sheet.getRange(8, 1, rows.length, headers.length);
    dataRange.setBorder(true, true, true, true, true, true);
  }

  sheet.autoResizeColumns(1, headers.length);
  return { success: true, sheetName: sheetName };
}

/**
 * PENGUNDUHAN VIA GOOGLE DRIVE (Anti-Sandbox Block):
 * Membuat spreadsheet file di Google Drive dan mengembalikan link download langsung
 */
function createDriveExcelDownload(rekapData, periodTitle, className) {
  var title = 'Rekap_Presensi_SMPN1Kalipare_' + (className || 'Semua') + '_' + Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyyMMdd_HHmm');
  var newSpreadsheet = SpreadsheetApp.create(title);
  var sheet = newSpreadsheet.getActiveSheet();

  sheet.getRange('A1:L1').merge().setValue('PEMERINTAH KABUPATEN MALANG').setFontWeight('bold').setHorizontalAlignment('center');
  sheet.getRange('A2:L2').merge().setValue('DINAS PENDIDIKAN').setFontWeight('bold').setHorizontalAlignment('center');
  sheet.getRange('A3:L3').merge().setValue('SMP NEGERI 1 KALIPARE').setFontSize(14).setFontWeight('bold').setHorizontalAlignment('center').setFontColor('#1e3a8a');
  sheet.getRange('A4:L4').merge().setValue('REKAPITULASI PRESENSI SISWA - PERIODE: ' + (periodTitle || 'SEMUA')).setFontWeight('bold').setHorizontalAlignment('center');
  sheet.getRange('A5:L5').merge().setValue('Kelas: ' + (className || 'Semua Kelas') + ' | Dicetak: ' + Utilities.formatDate(new Date(), 'Asia/Jakarta', 'dd MMMM yyyy HH:mm WIB')).setFontSize(9).setHorizontalAlignment('center');

  var headers = ['No', 'NIS', 'Nama Siswa', 'Kelas', 'L/P', 'Hadir', 'Terlambat', 'Izin', 'Sakit', 'Haid', 'Alpa', '% Kehadiran'];
  sheet.getRange(7, 1, 1, headers.length).setValues([headers]);
  sheet.getRange(7, 1, 1, headers.length).setBackground('#1e3a8a').setFontColor('#ffffff').setFontWeight('bold').setHorizontalAlignment('center');

  var rows = [];
  for (var i = 0; i < rekapData.length; i++) {
    var r = rekapData[i];
    var totalAttended = (r.hadir || 0) + (r.terlambat || 0) + (r.haid || 0);
    var totalDays = totalAttended + (r.izin || 0) + (r.sakit || 0) + (r.alpa || 0);
    var pct = totalDays > 0 ? Math.round((totalAttended / totalDays) * 100) + '%' : '0%';

    rows.push([
      i + 1,
      r.nis,
      r.name,
      r.className,
      r.gender,
      r.hadir || 0,
      r.terlambat || 0,
      r.izin || 0,
      r.sakit || 0,
      r.haid || 0,
      r.alpa || 0,
      pct
    ]);
  }

  if (rows.length > 0) {
    sheet.getRange(8, 1, rows.length, headers.length).setValues(rows);
    sheet.getRange(8, 1, rows.length, headers.length).setBorder(true, true, true, true, true, true);
  }
  sheet.autoResizeColumns(1, headers.length);

  var file = DriveApp.getFileById(newSpreadsheet.getId());
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

  return {
    success: true,
    fileUrl: newSpreadsheet.getUrl(),
    downloadXlsxUrl: 'https://docs.google.com/spreadsheets/d/' + newSpreadsheet.getId() + '/export?format=xlsx',
    downloadPdfUrl: 'https://docs.google.com/spreadsheets/d/' + newSpreadsheet.getId() + '/export?format=pdf'
  };
}

/**
 * Petunjuk Bantuan dalam Modal Dialog
 */
function showHelpModal() {
  var html = '<div style="font-family:sans-serif;padding:16px;line-height:1.6;font-size:13px;color:#334155;">'
    + '<h3 style="color:#1e3a8a;margin-top:0;">Petunjuk Presensi Nesaka</h3>'
    + '<ol style="padding-left:20px;">'
    + '<li>Buka menu <b>Presensi Nesaka &gt; Buka Aplikasi Web Presensi</b> untuk membuka scan kamera &amp; barcode HP.</li>'
    + '<li>Presensi Sholat Dhuhur dibuka <b>Senin s/d Kamis pukul 11:50 - 12:30 WIB</b> (Terkunci total di luar jam ini).</li>'
    + '<li>Presensi Jumat dibuka <b>Khusus Jumat pukul 11:15 - 12:30 WIB</b>.</li>'
    + '<li>Data tersimpan ganda secara otomatis ke Google Spreadsheet dan Firebase Firestore.</li>'
    + '<li>Tombol unduh rekapan Excel (.xlsx) dan PDF resmi tersedia di tab Rekapitulasi.</li>'
    + '</ol>'
    + '</div>';
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutput(html).setWidth(480).setHeight(280), 'Panduan Presensi Nesaka');
}
`;
}

/**
 * Generates the Index.html standalone frontend for Google Apps Script Web App.
 */
export function generateIndexHtml(students: Student[] = INITIAL_STUDENTS): string {
  const studentsJson = JSON.stringify(students.map(s => ({
    nis: s.nis,
    name: s.name,
    className: s.className,
    gender: s.gender,
    exemptReligious: !!s.exemptReligious
  })));

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Presensi QR & Barcode Siswa - SMP Negeri 1 Kalipare</title>
  
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  
  <!-- html5-qrcode CDN supporting all 1D Barcode & QR Code formats -->
  <script src="https://unpkg.com/html5-qrcode"></script>
  
  <!-- SheetJS CDN for Excel (.xlsx) Export -->
  <script src="https://cdn.sheetjs.com/xlsx-latest/package/dist/xlsx.full.min.js"></script>
  
  <!-- jsPDF & AutoTable CDN for Official PDF Export -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js"></script>

  <style>
    @keyframes pulse-subtle {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.6; }
    }
    .scanner-active { animation: pulse-subtle 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
  </style>
</head>
<body class="bg-slate-100 text-slate-800 min-h-screen flex flex-col font-sans antialiased">

  <!-- Header Navbar SMP Negeri 1 Kalipare -->
  <header class="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white shadow-lg sticky top-0 z-40">
    <div class="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3 border-b border-blue-800/60">
      <div class="flex items-center space-x-3.5">
        <!-- Logo Resmi SMP Negeri 1 Kalipare (Nesaka) -->
        <img 
          src="${NESAKA_LOGO_BASE64}" 
          alt="Logo SMP Negeri 1 Kalipare" 
          class="w-13 h-13 sm:w-15 sm:h-15 object-contain shrink-0 drop-shadow-md select-none"
        />
        <div>
          <div class="flex items-center gap-2">
            <h1 class="font-extrabold text-base sm:text-lg tracking-tight text-white flex items-center gap-2">
              SMP NEGERI 1 KALIPARE
            </h1>
            <span class="hidden sm:inline-block px-2 py-0.5 rounded text-xs font-semibold bg-blue-700/80 text-blue-100 border border-blue-500/50">
              Kab. Malang
            </span>
            <span class="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Google Sheets + Firebase
            </span>
          </div>
          <p class="text-xs text-blue-200/90 font-medium">
            Sistem Presensi QR Code &amp; Barcode &bull; Masuk, Pulang, Dhuhur, Jumat &amp; Keputrian
          </p>
        </div>
      </div>

      <!-- Real-time Clock & Sync Badges -->
      <div class="flex items-center gap-2 ml-auto">
        <div class="hidden md:flex items-center gap-2 bg-blue-950/60 px-3 py-1.5 rounded-lg border border-blue-700/50 text-xs">
          <span id="live-date" class="text-blue-100 font-medium"></span>
          <span id="live-clock" class="text-amber-300 font-mono font-bold"></span>
        </div>
        <div class="flex items-center gap-1.5 bg-blue-950/70 px-2.5 py-1.5 rounded-lg border border-blue-700/50 text-[11px] text-blue-200">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span>Google Sheets + Firestore</span>
        </div>
      </div>
    </div>

    <!-- Navigation Tabs -->
    <div class="max-w-7xl mx-auto px-4">
      <nav class="flex space-x-2 overflow-x-auto py-2 no-scrollbar">
        <button onclick="switchTab('scan')" id="tab-btn-scan" class="tab-btn px-4 py-2 rounded-lg text-sm font-bold bg-amber-400 text-slate-950 shadow-md">
          Scan QR &amp; Barcode
        </button>
        <button onclick="switchTab('manual')" id="tab-btn-manual" class="tab-btn px-4 py-2 rounded-lg text-sm font-semibold text-blue-100 hover:bg-blue-800/60">
          Absen Manual
        </button>
        <button onclick="switchTab('dashboard')" id="tab-btn-dashboard" class="tab-btn px-4 py-2 rounded-lg text-sm font-semibold text-blue-100 hover:bg-blue-800/60">
          Dashboard Live
        </button>
        <button onclick="switchTab('rekap')" id="tab-btn-rekap" class="tab-btn px-4 py-2 rounded-lg text-sm font-semibold text-blue-100 hover:bg-blue-800/60">
          Rekapitulasi &amp; Unduh
        </button>
      </nav>
    </div>
  </header>

  <!-- Main Content Container -->
  <main class="max-w-7xl mx-auto px-4 py-6 w-full flex-1">

    <!-- Hardware / Scanner Notice Banner -->
    <div class="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-blue-900 shadow-xs">
      <div class="flex items-center gap-2.5">
        <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
        <span><b>Mendukung Barcode &amp; QR Code (Kamera HP &amp; Alat USB):</b> Pemindai kamera telah dioptimalkan untuk memindai Barcode 1D (Code 128, Code 39, EAN) dan QR Code. Di PC, pemindai USB/RFID dapat memindai otomatis secara plug and play.</span>
      </div>
      <span class="px-2 py-0.5 rounded bg-blue-100 text-blue-700 font-mono font-semibold shrink-0">HP &amp; PC Ready</span>
    </div>

    <!-- ================= TAB 1: SCAN QR & BARCODE ================= -->
    <section id="tab-scan" class="space-y-6">
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Left: Scanner Controls & Camera View -->
        <div class="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
          <div class="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <h2 class="text-base font-bold text-slate-800">Sesi Presensi Aktif</h2>
              <p class="text-xs text-slate-500">Pilih sesi kehadiran yang sedang berlangsung</p>
            </div>
            
            <!-- Attendance Session Selectors -->
            <div class="flex flex-wrap gap-1.5">
              <button onclick="setSession('masuk')" id="btn-session-masuk" class="session-btn px-3 py-1.5 rounded-lg text-xs font-bold bg-blue-600 text-white shadow-xs">
                Masuk (Max 06:45)
              </button>
              <button onclick="setSession('pulang')" id="btn-session-pulang" class="session-btn px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200">
                Pulang (Bebas)
              </button>
              <button onclick="setSession('dhuhur')" id="btn-session-dhuhur" class="session-btn px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200">
                Dhuhur (11:50-12:30)
              </button>
              <button onclick="setSession('jumat')" id="btn-session-jumat" class="session-btn px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200">
                Sholat Jumat (L)
              </button>
              <button onclick="setSession('keputrian')" id="btn-session-keputrian" class="session-btn px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200">
                Keputrian (P)
              </button>
            </div>
          </div>

          <!-- Schedule Notice Alert -->
          <div id="schedule-notice" class="mt-4 p-3 rounded-xl text-xs flex items-center justify-between gap-2 bg-amber-50 text-amber-900 border border-amber-200">
            <span id="schedule-notice-text">Senin - Jumat: Siswa masuk maksimal pukul 06:45 WIB. Melebihi 06:45 otomatis terdata Terlambat.</span>
          </div>

          <!-- Camera & Barcode Scanner Viewport -->
          <div class="mt-4 space-y-3">
            <!-- Camera selection & controls -->
            <div class="flex flex-wrap items-center justify-between gap-2">
              <div class="flex items-center gap-2">
                <select id="camera-select" class="px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-700">
                  <option value="">Pilih Kamera Belakang / Depan...</option>
                </select>
                <button onclick="initCameraList()" class="px-2.5 py-1.5 text-xs bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 font-semibold cursor-pointer">
                  🔄 Muat Kamera
                </button>
              </div>

              <div class="flex items-center gap-2">
                <!-- File Upload / Photo Snap Fallback for HP -->
                <label class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg cursor-pointer border border-slate-300 flex items-center gap-1">
                  <span>📷 Foto / Unggah Barcode</span>
                  <input type="file" id="file-barcode-input" accept="image/*" capture="environment" class="hidden" onchange="handleFileScan(event)" />
                </label>
              </div>
            </div>

            <!-- Viewport container -->
            <div id="qr-reader" class="w-full max-w-md mx-auto rounded-xl overflow-hidden border border-slate-300 bg-slate-900 min-h-[260px] flex items-center justify-center text-slate-400 text-xs relative">
              <div class="text-center p-4">
                <p class="font-medium text-slate-200 mb-2">Pemindai Barcode &amp; QR Code Kamera HP Standby</p>
                <p class="text-[11px] text-slate-400 mb-3">Tekan tombol di bawah untuk menyalakan kamera HP / Laptop</p>
                <button onclick="toggleCamera()" id="btn-toggle-cam" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shadow-sm cursor-pointer">
                  Aktifkan Kamera Scan
                </button>
              </div>
            </div>

            <!-- Manual NIS Quick Input for HP -->
            <div class="max-w-md mx-auto flex items-center gap-2 pt-2">
              <input 
                type="text" 
                id="manual-nis-input" 
                placeholder="Ketik NIS siswa atau scan barcode..." 
                class="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                onkeydown="if(event.key==='Enter') processManualInput()"
              />
              <button onclick="processManualInput()" class="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-lg shadow-xs cursor-pointer">
                Scan
              </button>
            </div>
          </div>

          <!-- Scan Status & Last Scanned Student Info -->
          <div id="scan-feedback" class="mt-4 p-4 rounded-xl border border-slate-200 bg-slate-50 transition-all">
            <div class="text-center text-slate-500 text-xs">
              Menunggu pemindaian Barcode, QR Code, atau scan RFID...
            </div>
          </div>
        </div>

        <!-- Right: Real-time Today Log -->
        <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 flex flex-col">
          <div class="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 class="font-bold text-sm text-slate-800">Presensi Hari Ini</h3>
            <span id="today-count-badge" class="px-2 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">0 Scan</span>
          </div>
          
          <div id="today-records-list" class="mt-3 flex-1 overflow-y-auto max-h-[460px] space-y-2 pr-1 text-xs">
            <div class="text-center py-10 text-slate-400">Belum ada data scan hari ini</div>
          </div>
        </div>

      </div>
    </section>

    <!-- ================= TAB 2: ABSEN MANUAL ================= -->
    <section id="tab-manual" class="space-y-6 hidden">
      <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 class="text-base font-bold text-slate-800">Absensi Manual Kelas</h2>
            <p class="text-xs text-slate-500">Tandai kehadiran siswa secara manual (Hadir, Terlambat, Izin, Sakit, Alpa, Haid)</p>
          </div>
          
          <div class="flex items-center gap-3">
            <select id="manual-class-select" onchange="renderManualTable()" class="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold bg-white">
              <option value="7 Kutai">7 Kutai</option>
              <option value="7 Majapahit">7 Majapahit</option>
              <option value="7 Singosari">7 Singosari</option>
              <option value="7 Sriwijaya">7 Sriwijaya</option>
              <option value="7 Mataram">7 Mataram</option>
              <option value="7 Kahuripan">7 Kahuripan</option>
              <option value="8 Kutai">8 Kutai</option>
              <option value="8 Majapahit">8 Majapahit</option>
              <option value="8 Singosari">8 Singosari</option>
              <option value="8 Sriwijaya">8 Sriwijaya</option>
              <option value="8 Mataram">8 Mataram</option>
              <option value="8 Kahuripan">8 Kahuripan</option>
              <option value="9 Kutai">9 Kutai</option>
              <option value="9 Majapahit">9 Majapahit</option>
              <option value="9 Singosari">9 Singosari</option>
              <option value="9 Sriwijaya">9 Sriwijaya</option>
              <option value="9 Mataram">9 Mataram</option>
              <option value="9 Pajajaran">9 Pajajaran</option>
            </select>
          </div>
        </div>

        <div class="mt-4 overflow-x-auto">
          <table class="w-full text-xs text-left">
            <thead class="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th class="p-2.5">No</th>
                <th class="p-2.5">NIS</th>
                <th class="p-2.5">Nama Lengkap</th>
                <th class="p-2.5">L/P</th>
                <th class="p-2.5">Status Saat Ini</th>
                <th class="p-2.5 text-center">Tandai Status Kehadiran</th>
              </tr>
            </thead>
            <tbody id="manual-table-body" class="divide-y divide-slate-100">
              <!-- Rendered via JS -->
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- ================= TAB 3: DASHBOARD LIVE ================= -->
    <section id="tab-dashboard" class="space-y-6 hidden">
      <!-- Summary Cards -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <p class="text-[11px] font-semibold text-slate-400">Total Siswa</p>
          <p id="dash-total" class="text-2xl font-black text-slate-800 mt-1">479</p>
        </div>
        <div class="bg-white p-4 rounded-xl border border-emerald-200 bg-emerald-50/30 shadow-xs">
          <p class="text-[11px] font-semibold text-emerald-600">Hadir</p>
          <p id="dash-hadir" class="text-2xl font-black text-emerald-700 mt-1">0</p>
        </div>
        <div class="bg-white p-4 rounded-xl border border-amber-200 bg-amber-50/30 shadow-xs">
          <p class="text-[11px] font-semibold text-amber-600">Terlambat (&gt;06:45)</p>
          <p id="dash-terlambat" class="text-2xl font-black text-amber-700 mt-1">0</p>
        </div>
        <div class="bg-white p-4 rounded-xl border border-blue-200 bg-blue-50/30 shadow-xs">
          <p class="text-[11px] font-semibold text-blue-600">Izin / Sakit</p>
          <p id="dash-izinsakit" class="text-2xl font-black text-blue-700 mt-1">0</p>
        </div>
        <div class="bg-white p-4 rounded-xl border border-purple-200 bg-purple-50/30 shadow-xs">
          <p class="text-[11px] font-semibold text-purple-600">Haid (Dhuhur)</p>
          <p id="dash-haid" class="text-2xl font-black text-purple-700 mt-1">0</p>
        </div>
        <div class="bg-white p-4 rounded-xl border border-rose-200 bg-rose-50/30 shadow-xs">
          <p class="text-[11px] font-semibold text-rose-600">Belum Scan (Alpa)</p>
          <p id="dash-alpa" class="text-2xl font-black text-rose-700 mt-1">479</p>
        </div>
      </div>
    </section>

    <!-- ================= TAB 4: REKAPITULASI & UNDUH ================= -->
    <section id="tab-rekap" class="space-y-6 hidden">
      <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
        
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 class="text-base font-bold text-slate-800">Rekapitulasi Presensi &amp; Unduh Dokumen</h2>
            <p class="text-xs text-slate-500">Mendukung rekap Harian, Mingguan, Bulanan, dan Tengah Semester (3 Bulan / Triwulan)</p>
          </div>

          <!-- EXPORT BUTTONS (Client Direct + Google Drive Anti-Sandbox) -->
          <div class="flex flex-wrap items-center gap-2">
            <!-- Button Unduh Excel (.xlsx) -->
            <button onclick="downloadExcelRekap()" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
              <span>Unduh Excel (.xlsx)</span>
            </button>

            <!-- Button Unduh PDF Resmi -->
            <button onclick="downloadPdfRekap()" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
              <span>Unduh PDF Resmi (Kop Surat)</span>
            </button>

            <!-- Button Simpan ke Tab Baru Spreadsheet -->
            <button onclick="saveToSpreadsheetTab()" class="px-3.5 py-2 rounded-xl text-xs font-bold bg-blue-700 hover:bg-blue-800 text-white shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
              <span>Simpan ke Tab Sheet Baru</span>
            </button>
          </div>
        </div>

        <!-- Filter Bar -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 py-3">
          <div>
            <label class="block text-[11px] font-semibold text-slate-500 mb-1">Periode Rekapitulasi</label>
            <select id="rekap-period-select" onchange="handlePeriodChange()" class="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold bg-white">
              <option value="tengah_semester">Tengah Semester (3 Bulan / Triwulan)</option>
              <option value="hari_ini">Hari Ini</option>
              <option value="mingguan">Minggu Ini</option>
              <option value="bulanan">Bulan Ini</option>
              <option value="semester">Satu Semester (6 Bulan)</option>
            </select>
          </div>

          <div id="sub-period-container">
            <label class="block text-[11px] font-semibold text-slate-500 mb-1">Pilihan Triwulan (3 Bulan)</label>
            <select id="rekap-sub-period-select" onchange="renderRekapTable()" class="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold bg-white">
              <option value="triwulan_1">Triwulan I / STS 1 (Juli - September)</option>
              <option value="triwulan_2">Triwulan II / PAS 1 (Oktober - Desember)</option>
              <option value="triwulan_3">Triwulan III / STS 2 (Januari - Maret)</option>
              <option value="triwulan_4">Triwulan IV / PAT 2 (April - Juni)</option>
            </select>
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-500 mb-1">Filter Kelas</label>
            <select id="rekap-class-select" onchange="renderRekapTable()" class="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold bg-white">
              <option value="ALL">Semua Kelas (479 Siswa)</option>
              <option value="7 Kutai">7 Kutai</option>
              <option value="7 Majapahit">7 Majapahit</option>
              <option value="7 Singosari">7 Singosari</option>
              <option value="7 Sriwijaya">7 Sriwijaya</option>
              <option value="7 Mataram">7 Mataram</option>
              <option value="7 Kahuripan">7 Kahuripan</option>
              <option value="8 Kutai">8 Kutai</option>
              <option value="8 Majapahit">8 Majapahit</option>
              <option value="8 Singosari">8 Singosari</option>
              <option value="8 Sriwijaya">8 Sriwijaya</option>
              <option value="8 Mataram">8 Mataram</option>
              <option value="8 Kahuripan">8 Kahuripan</option>
              <option value="9 Kutai">9 Kutai</option>
              <option value="9 Majapahit">9 Majapahit</option>
              <option value="9 Singosari">9 Singosari</option>
              <option value="9 Sriwijaya">9 Sriwijaya</option>
              <option value="9 Mataram">9 Mataram</option>
              <option value="9 Pajajaran">9 Pajajaran</option>
            </select>
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-500 mb-1">Cari Nama / NIS</label>
            <input type="text" id="rekap-search-input" oninput="renderRekapTable()" placeholder="Ketik nama / NIS siswa..." class="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white" />
          </div>
        </div>

        <!-- Rekap Table -->
        <div class="mt-4 overflow-x-auto rounded-xl border border-slate-200">
          <table class="w-full text-xs text-left" id="rekap-table-content">
            <thead class="bg-blue-900 text-white font-bold">
              <tr>
                <th class="p-2.5">No</th>
                <th class="p-2.5">NIS</th>
                <th class="p-2.5">Nama Lengkap</th>
                <th class="p-2.5">Kelas</th>
                <th class="p-2.5">L/P</th>
                <th class="p-2.5 text-center text-emerald-300">Hadir</th>
                <th class="p-2.5 text-center text-amber-300">Terlambat</th>
                <th class="p-2.5 text-center text-blue-300">Izin</th>
                <th class="p-2.5 text-center text-indigo-300">Sakit</th>
                <th class="p-2.5 text-center text-purple-300">Haid</th>
                <th class="p-2.5 text-center text-rose-300">Alpa</th>
                <th class="p-2.5 text-center">% Kehadiran</th>
              </tr>
            </thead>
            <tbody id="rekap-table-body" class="divide-y divide-slate-100 bg-white">
              <!-- Rendered via JS -->
            </tbody>
          </table>
        </div>

      </div>
    </section>

  </main>

  <!-- Download Ready Modal Dialog -->
  <div id="download-modal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 hidden">
    <div class="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 space-y-4 border border-slate-200">
      <div class="flex items-center justify-between pb-2 border-b border-slate-100">
        <h3 id="modal-title" class="font-black text-slate-800 text-base">Berkas Rekapitulasi Siap Diunduh</h3>
        <button onclick="closeDownloadModal()" class="text-slate-400 hover:text-slate-700 text-xl font-bold cursor-pointer">&times;</button>
      </div>
      <p id="modal-desc" class="text-xs text-slate-600 leading-relaxed">
        File telah dipersiapkan oleh sistem. Silakan klik tombol di bawah untuk mengunduh atau membuka langsung di Google Drive Anda:
      </p>
      <div id="modal-actions" class="space-y-2 pt-2">
        <!-- Injected via JS -->
      </div>
      <div class="pt-2 text-right">
        <button onclick="closeDownloadModal()" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer">
          Tutup
        </button>
      </div>
    </div>
  </div>

  <!-- School Footer -->
  <footer class="bg-white border-t border-slate-200 py-4 text-slate-500 text-xs mt-auto">
    <div class="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
      <div>
        <span class="font-bold text-slate-800">SMP NEGERI 1 KALIPARE</span> &bull; Kabupaten Malang, Jawa Timur
      </div>
      <div>
        Versi Google Apps Script &bull; Tersambung ke Google Spreadsheet &amp; Firebase Firestore
      </div>
    </div>
  </footer>

  <!-- JAVASCRIPT LOGIC -->
  <script>
    // Master data 479 Siswa SMP Negeri 1 Kalipare
    const ALL_STUDENTS = ${studentsJson};
    
    // Konfigurasi REST Firebase Firestore
    const FS_PROJECT_ID = "${firebaseConfig.projectId || 'gen-lang-client-0302890897'}";
    const FS_DB_ID = "${firebaseConfig.firestoreDatabaseId || 'ai-studio-dadb62ae-28ed-4648-9b39-e5cb0bd9d02d'}";
    const FS_API_KEY = "${firebaseConfig.apiKey || 'AIzaSyB8b4o8tqKaVIPZoKoKd5ZrSGnGCilnlQU'}";

    let currentSession = 'masuk';
    let todayRecords = [];
    let html5QrScanner = null;
    let cameraActive = false;
    let rfidBuffer = '';
    let rfidTimer = null;

    // Live Clock
    function updateClock() {
      const now = new Date();
      document.getElementById('live-clock').innerText = now.toLocaleTimeString('id-ID', { hour12: false }) + ' WIB';
      document.getElementById('live-date').innerText = now.toLocaleDateString('id-ID', { 
        weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' 
      });
    }
    setInterval(updateClock, 1000);
    updateClock();

    // Tab Switching
    function switchTab(tabId) {
      document.querySelectorAll('.tab-btn').forEach(b => {
        b.className = 'tab-btn px-4 py-2 rounded-lg text-sm font-semibold text-blue-100 hover:bg-blue-800/60';
      });
      document.getElementById('tab-btn-' + tabId).className = 'tab-btn px-4 py-2 rounded-lg text-sm font-bold bg-amber-400 text-slate-950 shadow-md';

      ['scan', 'manual', 'dashboard', 'rekap'].forEach(t => {
        document.getElementById('tab-' + t).classList.add('hidden');
      });
      document.getElementById('tab-' + tabId).classList.remove('hidden');

      if (tabId === 'manual') renderManualTable();
      if (tabId === 'dashboard') renderDashboard();
      if (tabId === 'rekap') renderRekapTable();
    }

    // Set Attendance Session & Schedule Check
    function setSession(sessionType) {
      currentSession = sessionType;
      document.querySelectorAll('.session-btn').forEach(b => {
        b.className = 'session-btn px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200';
      });
      document.getElementById('btn-session-' + sessionType).className = 'session-btn px-3 py-1.5 rounded-lg text-xs font-bold bg-blue-600 text-white shadow-xs';

      const notice = document.getElementById('schedule-notice-text');
      const noticeBox = document.getElementById('schedule-notice');

      if (sessionType === 'masuk') {
        notice.innerText = 'Senin - Jumat: Siswa masuk maksimal pukul 06:45 WIB. Melebihi 06:45 otomatis terdata Terlambat.';
        noticeBox.className = 'mt-4 p-3 rounded-xl text-xs flex items-center justify-between gap-2 bg-amber-50 text-amber-900 border border-amber-200';
      } else if (sessionType === 'pulang') {
        notice.innerText = 'Senin - Jumat: Siswa pulang bebas waktu kepulangan.';
        noticeBox.className = 'mt-4 p-3 rounded-xl text-xs flex items-center justify-between gap-2 bg-blue-50 text-blue-900 border border-blue-200';
      } else if (sessionType === 'dhuhur') {
        notice.innerText = 'Senin - Kamis (11:50 - 12:30 WIB): Sholat Dhuhur Berjamaah. Di luar jam ini terkunci total dan TIDAK ADA menu buka paksa.';
        noticeBox.className = 'mt-4 p-3 rounded-xl text-xs flex items-center justify-between gap-2 bg-purple-50 text-purple-900 border border-purple-200 font-bold';
      } else if (sessionType === 'jumat') {
        notice.innerText = 'Khusus Hari Jumat Pukul 11:15 - 12:30 WIB: Sholat Jumat Berjamaah bagi siswa laki-laki.';
        noticeBox.className = 'mt-4 p-3 rounded-xl text-xs flex items-center justify-between gap-2 bg-indigo-50 text-indigo-900 border border-indigo-200';
      } else if (sessionType === 'keputrian') {
        notice.innerText = 'Khusus Hari Jumat Pukul 11:15 - 12:30 WIB: Keputrian bagi siswi perempuan.';
        noticeBox.className = 'mt-4 p-3 rounded-xl text-xs flex items-center justify-between gap-2 bg-pink-50 text-pink-900 border border-pink-200';
      }
    }

    // Function to Sync Direct to Firebase Firestore REST API
    function syncToFirestoreDirect(record) {
      const recordId = 'att_' + record.date + '_' + record.nis + '_' + record.type;
      const url = 'https://firestore.googleapis.com/v1/projects/' + FS_PROJECT_ID 
        + '/databases/' + FS_DB_ID 
        + '/documents/attendance/' + recordId + '?key=' + FS_API_KEY;

      const payload = {
        fields: {
          recordId: { stringValue: recordId },
          studentNis: { stringValue: String(record.nis) },
          studentName: { stringValue: String(record.name) },
          className: { stringValue: String(record.className) },
          gender: { stringValue: String(record.gender) },
          type: { stringValue: String(record.type) },
          status: { stringValue: String(record.status) },
          date: { stringValue: String(record.date) },
          timeStr: { stringValue: String(record.time) },
          timestamp: { stringValue: String(record.timestamp) },
          method: { stringValue: 'GAS_CLIENT_REST' }
        }
      };

      fetch(url, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      .then(res => {
        if (res.ok) console.log("Tersimpan di Firebase Firestore:", recordId);
        else console.warn("Firestore response status:", res.status);
      })
      .catch(err => {
        console.warn("Firestore sync fetch notice:", err);
      });
    }

    // Process Attendance Scan (RFID, Barcode, or Camera)
    function processScannedNis(rawInput) {
      const nis = String(rawInput).trim().replace(/[^0-9]/g, '');
      if (!nis) return;

      const student = ALL_STUDENTS.find(s => s.nis === nis);
      if (!student) {
        showFeedback(false, 'Kartu / Barcode Tidak Dikenal', 'NIS ' + nis + ' tidak terdaftar di SMP Negeri 1 Kalipare.');
        playBeep(false);
        return;
      }

      // 1. Aturan Khusus Siswa Non-Muslim (Maximilianus, Diva Widiana, Jevanya)
      if (student.exemptReligious && (currentSession === 'dhuhur' || currentSession === 'jumat' || currentSession === 'keputrian')) {
        showFeedback(false, 'Pengecualian Agama Non-Muslim', student.name + ' (' + student.className + ') dibebaskan dari presensi ' + currentSession + '.');
        playBeep(false);
        return;
      }

      // 2. ATURAN SHOLAT DHUHUR: 11:50 - 12:30 WIB Senin s/d Kamis (Tanpa Buka Paksa)
      const now = new Date();
      const day = now.getDay();
      const totalMinutes = now.getHours() * 60 + now.getMinutes();

      if (currentSession === 'dhuhur') {
        if (day === 5) {
          showFeedback(false, 'Sholat Dhuhur Dialihkan', 'Hari Jumat dialihkan ke Sholat Jumat (Laki-laki) dan Keputrian (Perempuan).');
          playBeep(false);
          return;
        }
        if (day < 1 || day > 4) {
          showFeedback(false, 'Di Luar Hari Operasional', 'Presensi Sholat Dhuhur Berjamaah hanya diadakan hari Senin s/d Kamis.');
          playBeep(false);
          return;
        }
        if (totalMinutes < 710 || totalMinutes > 750) {
          showFeedback(false, 'Sesi Sholat Dhuhur Terkunci', 'Presensi Sholat Dhuhur HANYA dibuka pukul 11:50 - 12:30 WIB. Di luar jam tersebut siswa tidak bisa absen dan tidak ada menu buka paksa.');
          playBeep(false);
          return;
        }
      }

      // 3. ATURAN SHOLAT JUMAT & KEPUTRIAN: Jumat 11:15 - 12:30 WIB
      if (currentSession === 'jumat' || currentSession === 'keputrian') {
        if (day !== 5) {
          showFeedback(false, 'Jadwal Khusus Hari Jumat', 'Presensi ' + currentSession + ' hanya dibuka pada hari JUMAT pukul 11:15 - 12:30 WIB.');
          playBeep(false);
          return;
        }
        if (totalMinutes < 675 || totalMinutes > 750) {
          showFeedback(false, 'Di Luar Jam Presensi', 'Presensi ' + currentSession + ' hanya dibuka pada pukul 11:15 - 12:30 WIB.');
          playBeep(false);
          return;
        }
        if (currentSession === 'jumat' && student.gender !== 'L') {
          showFeedback(false, 'Salah Sesi Presensi', student.name + ' adalah siswi perempuan. Harap pindah ke sesi Keputrian.');
          playBeep(false);
          return;
        }
        if (currentSession === 'keputrian' && student.gender !== 'P') {
          showFeedback(false, 'Salah Sesi Presensi', student.name + ' adalah siswa laki-laki. Harap pindah ke sesi Sholat Jumat.');
          playBeep(false);
          return;
        }
      }

      // 4. Cek duplikasi
      const dateStr = now.toISOString().split('T')[0];
      const already = todayRecords.find(r => r.nis === student.nis && r.type === currentSession);
      if (already) {
        showFeedback(false, 'Sudah Presensi', student.name + ' sudah tercatat pada sesi ' + currentSession + ' (' + already.status.toUpperCase() + ').');
        playBeep(false);
        return;
      }

      // 5. Tentukan status kehadiran (terlambat jika lewat 06:45 pada absen masuk)
      let status = 'hadir';
      if (currentSession === 'masuk') {
        if (totalMinutes > 405) {
          status = 'terlambat';
        }
      }

      const newRecord = {
        nis: student.nis,
        name: student.name,
        className: student.className,
        gender: student.gender,
        type: currentSession,
        status: status,
        time: now.toLocaleTimeString('id-ID', { hour12: false }) + ' WIB',
        date: dateStr,
        timestamp: now.toISOString()
      };

      todayRecords.unshift(newRecord);
      renderTodayList();
      showFeedback(true, student.name, student.className + ' &bull; Status: ' + status.toUpperCase() + ' &bull; ' + newRecord.time);
      playBeep(true);

      // SINKRONISASI 1: TERSIMPAN DI FIREBASE FIRESTORE
      syncToFirestoreDirect(newRecord);

      // SINKRONISASI 2: TERSIMPAN DI GOOGLE SPREADSHEET
      if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run
          .withSuccessHandler(function(res) {
            console.log('Saved to Google Sheets:', res);
          })
          .withFailureHandler(function(err) {
            console.error('Save to Sheets error:', err);
          })
          .recordAttendance({
            nis: student.nis,
            type: currentSession,
            status: status,
            method: 'WEB_APP_SCAN'
          });
      }
    }

    function processManualInput() {
      const input = document.getElementById('manual-nis-input');
      const val = input.value.trim();
      if (val) {
        processScannedNis(val);
        input.value = '';
      }
    }

    // Display Feedback Card
    function showFeedback(success, title, subtitle) {
      const fb = document.getElementById('scan-feedback');
      if (success) {
        fb.className = 'mt-4 p-4 rounded-xl border border-emerald-300 bg-emerald-50 text-emerald-950 transition-all';
        fb.innerHTML = '<div class="flex items-center gap-3">'
          + '<div class="w-10 h-10 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-lg shrink-0">✓</div>'
          + '<div><h4 class="font-bold text-sm text-emerald-900">' + title + '</h4>'
          + '<p class="text-xs text-emerald-700 mt-0.5">' + subtitle + '</p></div></div>';
      } else {
        fb.className = 'mt-4 p-4 rounded-xl border border-rose-300 bg-rose-50 text-rose-950 transition-all';
        fb.innerHTML = '<div class="flex items-center gap-3">'
          + '<div class="w-10 h-10 rounded-full bg-rose-500 text-white flex items-center justify-center font-bold text-lg shrink-0">!</div>'
          + '<div><h4 class="font-bold text-sm text-rose-900">' + title + '</h4>'
          + '<p class="text-xs text-rose-700 mt-0.5">' + subtitle + '</p></div></div>';
      }
    }

    // Sound Beep Generator (Web Audio API)
    function playBeep(success) {
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        if (success) {
          osc.frequency.setValueAtTime(880, ctx.currentTime);
          osc.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.15);
        } else {
          osc.frequency.setValueAtTime(320, ctx.currentTime);
          osc.frequency.exponentialRampToValueAtTime(180, ctx.currentTime + 0.25);
        }
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
        osc.start();
        osc.stop(ctx.currentTime + 0.26);
      } catch (e) {}
    }

    // Global USB Barcode & RFID Scanner Listener (HID Keyboard Emulator)
    window.addEventListener('keydown', function(e) {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
      if (e.key === 'Enter') {
        if (rfidBuffer.length >= 4) {
          processScannedNis(rfidBuffer);
        }
        rfidBuffer = '';
      } else if (e.key.length === 1) {
        rfidBuffer += e.key;
        clearTimeout(rfidTimer);
        rfidTimer = setTimeout(function() { rfidBuffer = ''; }, 200);
      }
    });

    // Render Today Records List
    function renderTodayList() {
      const container = document.getElementById('today-records-list');
      document.getElementById('today-count-badge').innerText = todayRecords.length + ' Scan';
      if (todayRecords.length === 0) {
        container.innerHTML = '<div class="text-center py-10 text-slate-400">Belum ada data scan hari ini</div>';
        return;
      }
      let html = '';
      todayRecords.forEach(r => {
        let badgeClass = 'bg-emerald-100 text-emerald-800 border-emerald-200';
        if (r.status === 'terlambat') badgeClass = 'bg-amber-100 text-amber-800 border-amber-200';
        if (r.status === 'haid') badgeClass = 'bg-purple-100 text-purple-800 border-purple-200';
        html += '<div class="p-2.5 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between gap-2">'
          + '<div><p class="font-bold text-slate-800">' + r.name + '</p>'
          + '<p class="text-[11px] text-slate-500">' + r.nis + ' &bull; ' + r.className + ' (' + r.type.toUpperCase() + ')</p></div>'
          + '<div class="text-right"><span class="px-2 py-0.5 rounded text-[10px] font-bold border ' + badgeClass + '">' + r.status.toUpperCase() + '</span>'
          + '<p class="text-[10px] text-slate-400 font-mono mt-0.5">' + r.time + '</p></div></div>';
      });
      container.innerHTML = html;
    }

    // Render Manual Table
    function renderManualTable() {
      const selectedClass = document.getElementById('manual-class-select').value;
      const classStudents = ALL_STUDENTS.filter(s => s.className === selectedClass);
      const tbody = document.getElementById('manual-table-body');
      let html = '';

      // Check if dhuhur is locked
      const now = new Date();
      const totalMinutes = now.getHours() * 60 + now.getMinutes();
      const day = now.getDay();
      const isDhuhurLocked = currentSession === 'dhuhur' && (day < 1 || day > 4 || totalMinutes < 710 || totalMinutes > 750);

      classStudents.forEach((s, idx) => {
        const existing = todayRecords.find(r => r.nis === s.nis && r.type === currentSession);
        const currentStatus = existing ? existing.status.toUpperCase() : 'ALPA (BELUM SCAN)';
        const isNonMuslimExempt = s.exemptReligious && (currentSession === 'dhuhur' || currentSession === 'jumat' || currentSession === 'keputrian');

        html += '<tr class="hover:bg-slate-50">'
          + '<td class="p-2.5">' + (idx + 1) + '</td>'
          + '<td class="p-2.5 font-mono">' + s.nis + '</td>'
          + '<td class="p-2.5 font-bold">' + s.name + (s.exemptReligious ? ' <span class="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 text-amber-800">Non-Muslim</span>' : '') + '</td>'
          + '<td class="p-2.5">' + s.gender + '</td>'
          + '<td class="p-2.5 font-semibold">' + (isNonMuslimExempt ? '<span class="text-slate-400">- (Bebas)</span>' : currentStatus) + '</td>'
          + '<td class="p-2.5 text-center">'
          + (isNonMuslimExempt ? '<span class="text-xs text-slate-400 italic">Dibebaskan dari presensi sholat</span>' :
             isDhuhurLocked ? '<span class="text-xs text-rose-600 font-bold">Terkunci (Hanya 11:50-12:30 WIB)</span>' :
            '<div class="flex items-center justify-center gap-1">'
            + '<button onclick="setManualStatus(\\'' + s.nis + '\\', \\'hadir\\')" class="px-2 py-1 bg-emerald-600 text-white rounded text-[11px] font-bold cursor-pointer">Hadir</button>'
            + '<button onclick="setManualStatus(\\'' + s.nis + '\\', \\'terlambat\\')" class="px-2 py-1 bg-amber-500 text-white rounded text-[11px] font-bold cursor-pointer">Terlambat</button>'
            + '<button onclick="setManualStatus(\\'' + s.nis + '\\', \\'izin\\')" class="px-2 py-1 bg-blue-600 text-white rounded text-[11px] font-bold cursor-pointer">Izin</button>'
            + '<button onclick="setManualStatus(\\'' + s.nis + '\\', \\'sakit\\')" class="px-2 py-1 bg-indigo-600 text-white rounded text-[11px] font-bold cursor-pointer">Sakit</button>'
            + (s.gender === 'P' && currentSession === 'dhuhur' ? '<button onclick="setManualStatus(\\'' + s.nis + '\\', \\'haid\\')" class="px-2 py-1 bg-purple-600 text-white rounded text-[11px] font-bold cursor-pointer">Haid</button>' : '')
            + '<button onclick="setManualStatus(\\'' + s.nis + '\\', \\'alpa\\')" class="px-2 py-1 bg-rose-600 text-white rounded text-[11px] font-bold cursor-pointer">Alpa</button>'
            + '</div>'
          )
          + '</td></tr>';
      });
      tbody.innerHTML = html;
    }

    function setManualStatus(nis, status) {
      const student = ALL_STUDENTS.find(s => s.nis === nis);
      if (!student) return;
      const now = new Date();
      const existingIdx = todayRecords.findIndex(r => r.nis === nis && r.type === currentSession);
      const record = {
        nis: student.nis,
        name: student.name,
        className: student.className,
        gender: student.gender,
        type: currentSession,
        status: status,
        time: now.toLocaleTimeString('id-ID', { hour12: false }) + ' WIB',
        date: now.toISOString().split('T')[0],
        timestamp: now.toISOString()
      };
      if (existingIdx >= 0) todayRecords[existingIdx] = record;
      else todayRecords.unshift(record);

      renderTodayList();
      renderManualTable();
      showFeedback(true, student.name, 'Status ' + student.name + ' diubah ke: ' + status.toUpperCase());

      // Dual Save: Firestore + Sheets
      syncToFirestoreDirect(record);

      if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run.recordAttendance({
          nis: student.nis,
          type: currentSession,
          status: status,
          method: 'MANUAL_TEACHER'
        });
      }
    }

    // Render Dashboard
    function renderDashboard() {
      document.getElementById('dash-total').innerText = ALL_STUDENTS.length;
      const hadir = todayRecords.filter(r => r.status === 'hadir').length;
      const terlambat = todayRecords.filter(r => r.status === 'terlambat').length;
      const izinsakit = todayRecords.filter(r => r.status === 'izin' || r.status === 'sakit').length;
      const haid = todayRecords.filter(r => r.status === 'haid').length;
      const alpa = Math.max(0, ALL_STUDENTS.length - (hadir + terlambat + izinsakit + haid));

      document.getElementById('dash-hadir').innerText = hadir;
      document.getElementById('dash-terlambat').innerText = terlambat;
      document.getElementById('dash-izinsakit').innerText = izinsakit;
      document.getElementById('dash-haid').innerText = haid;
      document.getElementById('dash-alpa').innerText = alpa;
    }

    // Period Change Handler
    function handlePeriodChange() {
      const p = document.getElementById('rekap-period-select').value;
      const subContainer = document.getElementById('sub-period-container');
      if (p === 'tengah_semester') {
        subContainer.classList.remove('hidden');
      } else {
        subContainer.classList.add('hidden');
      }
      renderRekapTable();
    }

    // Calculate & Render Rekap Table
    function getCalculatedRekapData() {
      const cls = document.getElementById('rekap-class-select').value;
      const search = document.getElementById('rekap-search-input').value.toLowerCase().trim();
      let list = ALL_STUDENTS;
      if (cls !== 'ALL') list = list.filter(s => s.className === cls);
      if (search) list = list.filter(s => s.name.toLowerCase().includes(search) || s.nis.includes(search));

      return list.map(s => {
        const studentRecords = todayRecords.filter(r => r.nis === s.nis);
        const hadir = studentRecords.filter(r => r.status === 'hadir').length;
        const terlambat = studentRecords.filter(r => r.status === 'terlambat').length;
        const izin = studentRecords.filter(r => r.status === 'izin').length;
        const sakit = studentRecords.filter(r => r.status === 'sakit').length;
        const haid = studentRecords.filter(r => r.status === 'haid').length;
        const alpa = studentRecords.length === 0 ? 1 : 0;
        const total = hadir + terlambat + haid;
        const pct = (hadir + terlambat + haid + izin + sakit + alpa) > 0 
          ? Math.round((total / (hadir + terlambat + haid + izin + sakit + alpa)) * 100) + '%' 
          : '0%';

        return {
          nis: s.nis,
          name: s.name,
          className: s.className,
          gender: s.gender,
          exemptReligious: s.exemptReligious,
          hadir,
          terlambat,
          izin,
          sakit,
          haid,
          alpa,
          pct
        };
      });
    }

    function renderRekapTable() {
      const data = getCalculatedRekapData();
      const tbody = document.getElementById('rekap-table-body');
      let html = '';

      data.forEach((r, idx) => {
        html += '<tr class="hover:bg-slate-50">'
          + '<td class="p-2.5">' + (idx + 1) + '</td>'
          + '<td class="p-2.5 font-mono">' + r.nis + '</td>'
          + '<td class="p-2.5 font-bold">' + r.name + (r.exemptReligious ? ' <span class="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 text-amber-800">Non-Muslim</span>' : '') + '</td>'
          + '<td class="p-2.5">' + r.className + '</td>'
          + '<td class="p-2.5">' + r.gender + '</td>'
          + '<td class="p-2.5 text-center font-bold text-emerald-600">' + r.hadir + '</td>'
          + '<td class="p-2.5 text-center font-bold text-amber-600">' + r.terlambat + '</td>'
          + '<td class="p-2.5 text-center font-bold text-blue-600">' + r.izin + '</td>'
          + '<td class="p-2.5 text-center font-bold text-indigo-600">' + r.sakit + '</td>'
          + '<td class="p-2.5 text-center font-bold text-purple-600">' + r.haid + '</td>'
          + '<td class="p-2.5 text-center font-bold text-rose-600">' + r.alpa + '</td>'
          + '<td class="p-2.5 text-center font-bold">' + r.pct + '</td>'
          + '</tr>';
      });

      tbody.innerHTML = html;
    }

    // Modal Helpers
    function showDownloadModal(title, desc, actionsHtml) {
      document.getElementById('modal-title').innerText = title;
      document.getElementById('modal-desc').innerText = desc;
      document.getElementById('modal-actions').innerHTML = actionsHtml;
      document.getElementById('download-modal').classList.remove('hidden');
    }

    function closeDownloadModal() {
      document.getElementById('download-modal').classList.add('hidden');
    }

    // EXPORT 1: UNDUH REKAP EXCEL (.xlsx) - ANTI BLOKIR SANDBOX
    function downloadExcelRekap() {
      const data = getCalculatedRekapData();
      const p = document.getElementById('rekap-period-select').value;
      const sub = document.getElementById('rekap-sub-period-select').value;
      const cls = document.getElementById('rekap-class-select').value;
      let periodLabel = p;
      if (p === 'tengah_semester') periodLabel = sub.toUpperCase();

      showFeedback(true, 'Menyiapkan File Excel...', 'Membuat berkas rekap presensi resmi...');

      if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run
          .withSuccessHandler(function(res) {
            if (res && res.downloadXlsxUrl) {
              const actions = '<a href="' + res.downloadXlsxUrl + '" target="_blank" class="block w-full text-center px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs">📥 Klik Untuk Mengunduh File Excel (.xlsx)</a>'
                + '<a href="' + res.fileUrl + '" target="_blank" class="block w-full text-center px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs">📂 Buka di Google Drive</a>';
              showDownloadModal('Unduh File Excel Berhasil', 'File Excel telah berhasil dibuat di Google Drive sekolah. Klik link berikut untuk mengunduh ke PC/HP Anda:', actions);
            }
          })
          .withFailureHandler(function(err) {
            clientSideExcelDownload(data, periodLabel, cls);
          })
          .createDriveExcelDownload(data, periodLabel, cls);
        return;
      }

      clientSideExcelDownload(data, periodLabel, cls);
    }

    function clientSideExcelDownload(data, periodLabel, cls) {
      const rows = [
        ['PEMERINTAH KABUPATEN MALANG'],
        ['DINAS PENDIDIKAN'],
        ['SMP NEGERI 1 KALIPARE'],
        ['REKAPITULASI PRESENSI SISWA'],
        ['Periode: ' + periodLabel + ' | Kelas: ' + cls],
        ['Dicetak pada: ' + new Date().toLocaleString('id-ID')],
        [],
        ['No', 'NIS', 'Nama Lengkap', 'Kelas', 'L/P', 'Hadir', 'Terlambat', 'Izin', 'Sakit', 'Haid', 'Alpa', '% Kehadiran']
      ];

      data.forEach((r, idx) => {
        rows.push([
          idx + 1, r.nis, r.name, r.className, r.gender,
          r.hadir, r.terlambat, r.izin, r.sakit, r.haid, r.alpa, r.pct
        ]);
      });

      const ws = XLSX.utils.aoa_to_sheet(rows);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Rekap Presensi');
      const filename = 'Rekap_Presensi_SMPN1Kalipare_' + periodLabel + '_' + cls + '.xlsx';

      try {
        const b64 = XLSX.write(wb, { bookType: 'xlsx', type: 'base64' });
        const uri = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,' + b64;
        const actions = '<a href="' + uri + '" download="' + filename + '" class="block w-full text-center px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs">📥 Simpan File Excel (' + filename + ')</a>';
        showDownloadModal('Unduh File Excel', 'Klik tombol di bawah untuk menyimpan file Excel ke perangkat Anda:', actions);
      } catch (err) {
        XLSX.writeFile(wb, filename);
      }
    }

    // EXPORT 2: UNDUH PDF RESMI (KOP SURAT + TANDA TANGAN)
    function downloadPdfRekap() {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF('p', 'mm', 'a4');
      const data = getCalculatedRekapData();
      const p = document.getElementById('rekap-period-select').value;
      const sub = document.getElementById('rekap-sub-period-select').value;
      const cls = document.getElementById('rekap-class-select').value;
      let periodLabel = p.toUpperCase();
      if (p === 'tengah_semester') periodLabel = 'TENGAH SEMESTER (3 BULAN) - ' + sub.toUpperCase();

      // Kop Surat Resmi
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.text('PEMERINTAH KABUPATEN MALANG', 105, 14, { align: 'center' });
      doc.text('DINAS PENDIDIKAN', 105, 19, { align: 'center' });
      doc.setFontSize(14);
      doc.setTextColor(30, 58, 138);
      doc.text('SMP NEGERI 1 KALIPARE', 105, 25, { align: 'center' });
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(71, 85, 105);
      doc.text('Jl. Raya Kalipare, Kec. Kalipare, Kab. Malang, Jawa Timur 65166', 105, 29, { align: 'center' });
      
      doc.setDrawColor(30, 58, 138);
      doc.setLineWidth(0.8);
      doc.line(14, 32, 196, 32);
      doc.setLineWidth(0.2);
      doc.line(14, 33, 196, 33);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text('REKAPITULASI PRESENSI SISWA', 105, 40, { align: 'center' });
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text('Periode: ' + periodLabel + '  |  Kelas: ' + cls, 105, 45, { align: 'center' });

      const tableRows = data.map((r, i) => [
        i + 1, r.nis, r.name, r.className, r.gender,
        r.hadir, r.terlambat, r.izin, r.sakit, r.haid, r.alpa, r.pct
      ]);

      doc.autoTable({
        startY: 50,
        head: [['No', 'NIS', 'Nama Siswa', 'Kelas', 'L/P', 'H', 'T', 'I', 'S', 'Hd', 'A', '%']],
        body: tableRows,
        theme: 'grid',
        headStyles: { fillColor: [30, 58, 138], textColor: 255, fontSize: 8, halign: 'center' },
        styles: { fontSize: 7, cellPadding: 1.5 },
        columnStyles: {
          0: { halign: 'center', cellWidth: 8 },
          1: { cellWidth: 16 },
          3: { cellWidth: 20 },
          4: { halign: 'center', cellWidth: 8 },
          5: { halign: 'center', cellWidth: 9 },
          6: { halign: 'center', cellWidth: 9 },
          7: { halign: 'center', cellWidth: 9 },
          8: { halign: 'center', cellWidth: 9 },
          9: { halign: 'center', cellWidth: 9 },
          10: { halign: 'center', cellWidth: 9 },
          11: { halign: 'center', cellWidth: 12 }
        }
      });

      const finalY = doc.lastAutoTable.finalY + 12;
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text('Mengetahui,', 25, finalY);
      doc.text('Kepala SMP Negeri 1 Kalipare', 25, finalY + 5);
      doc.text('(...................................................)', 25, finalY + 25);

      doc.text('Kalipare, ' + new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }), 140, finalY);
      doc.text('Wali Kelas / Petugas Presensi', 140, finalY + 5);
      doc.text('(...................................................)', 140, finalY + 25);

      try {
        const pdfDataUri = doc.output('datauristring');
        const actions = '<a href="' + pdfDataUri + '" download="Rekap_Presensi_SMPN1Kalipare.pdf" class="block w-full text-center px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs shadow-xs">📥 Simpan Dokumen PDF Resmi</a>'
          + '<a href="' + pdfDataUri + '" target="_blank" class="block w-full text-center px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs">🖨️ Pratinjau / Cetak Dokumen</a>';
        showDownloadModal('Dokumen PDF Resmi Siap', 'Silakan klik tombol di bawah untuk menyimpan PDF atau mencetak langsung:', actions);
      } catch (e) {
        doc.save('Rekap_Presensi_SMPN1Kalipare.pdf');
      }
    }

    // EXPORT 3: SIMPAN KE TAB SHEET BARU
    function saveToSpreadsheetTab() {
      if (typeof google === 'undefined' || !google.script || !google.script.run) {
        alert('Fitur Simpan ke Tab Sheet aktif ketika Web App dijalankan di Google Spreadsheet.');
        return;
      }
      const data = getCalculatedRekapData();
      const p = document.getElementById('rekap-period-select').value;
      const sub = document.getElementById('rekap-sub-period-select').value;
      const cls = document.getElementById('rekap-class-select').value;
      let periodLabel = p;
      if (p === 'tengah_semester') periodLabel = sub.toUpperCase();

      google.script.run
        .withSuccessHandler(function(res) {
          alert('Berhasil membuat tab baru di Google Spreadsheet: ' + res.sheetName);
        })
        .withFailureHandler(function(err) {
          alert('Gagal membuat tab spreadsheet: ' + err.toString());
        })
        .exportRekapToSheet(data, periodLabel, cls);
    }

    // Camera List Initialization
    function initCameraList() {
      Html5Qrcode.getCameras().then(cameras => {
        const select = document.getElementById('camera-select');
        select.innerHTML = '';
        if (cameras && cameras.length > 0) {
          cameras.forEach((cam, idx) => {
            const opt = document.createElement('option');
            opt.value = cam.id;
            opt.text = cam.label || ('Kamera ' + (idx + 1));
            if (cam.label.toLowerCase().includes('back') || cam.label.toLowerCase().includes('rear') || cam.label.toLowerCase().includes('environment') || cam.label.toLowerCase().includes('belakang')) {
              opt.selected = true;
            }
            select.appendChild(opt);
          });
        } else {
          select.innerHTML = '<option value="">Tidak ada kamera terdeteksi</option>';
        }
      }).catch(err => {
        console.warn("Get cameras error:", err);
      });
    }

    // Camera Scan Toggle supporting Barcodes 1D & QR Code
    function toggleCamera() {
      const btn = document.getElementById('btn-toggle-cam');
      if (!cameraActive) {
        if (currentSession === 'dhuhur') {
          const now = new Date();
          const day = now.getDay();
          const totalMinutes = now.getHours() * 60 + now.getMinutes();
          if (day < 1 || day > 4 || totalMinutes < 710 || totalMinutes > 750) {
            alert('Presensi Sholat Dhuhur Berjamaah terkunci total di luar pukul 11:50 - 12:30 WIB (Senin - Kamis). Tidak ada menu buka paksa.');
            return;
          }
        }

        const selectedCamId = document.getElementById('camera-select').value;
        const cameraConfig = selectedCamId ? { deviceId: { exact: selectedCamId } } : { facingMode: "environment" };

        html5QrScanner = new Html5Qrcode("qr-reader", {
          formatsToSupport: [
            Html5QrcodeSupportedFormats.QR_CODE,
            Html5QrcodeSupportedFormats.CODE_128,
            Html5QrcodeSupportedFormats.CODE_39,
            Html5QrcodeSupportedFormats.EAN_13,
            Html5QrcodeSupportedFormats.UPC_A,
            Html5QrcodeSupportedFormats.CODABAR,
            Html5QrcodeSupportedFormats.ITF
          ],
          verbose: false
        });

        html5QrScanner.start(
          cameraConfig,
          { 
            fps: 15, 
            qrbox: (w, h) => {
              const min = Math.min(w, h);
              return { width: Math.floor(min * 0.8), height: Math.floor(min * 0.8) };
            } 
          },
          (decodedText) => {
            processScannedNis(decodedText);
          },
          () => {}
        ).then(() => {
          cameraActive = true;
          btn.innerText = 'Matikan Kamera';
          btn.className = 'px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg shadow-sm cursor-pointer';
        }).catch(err => {
          alert('Gagal membuka kamera: ' + err + '. Pastikan izin kamera telah disetujui pada browser HP Anda.');
        });
      } else {
        html5QrScanner.stop().then(() => {
          cameraActive = false;
          btn.innerText = 'Aktifkan Kamera Scan';
          btn.className = 'px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shadow-sm cursor-pointer';
        });
      }
    }

    // Photo / File Snapshot Scan Fallback for HP
    function handleFileScan(e) {
      const file = e.target.files[0];
      if (!file) return;

      if (!html5QrScanner) {
        html5QrScanner = new Html5Qrcode("qr-reader", {
          formatsToSupport: [
            Html5QrcodeSupportedFormats.QR_CODE,
            Html5QrcodeSupportedFormats.CODE_128,
            Html5QrcodeSupportedFormats.CODE_39,
            Html5QrcodeSupportedFormats.EAN_13,
            Html5QrcodeSupportedFormats.UPC_A
          ]
        });
      }

      html5QrScanner.scanFile(file, true)
        .then(decodedText => {
          processScannedNis(decodedText);
        })
        .catch(err => {
          showFeedback(false, 'Gagal Membaca Barcode', 'Barcode tidak terbaca dengan jelas dari foto. Harap ulangi foto atau gunakan input NIS.');
        });
    }

    // Load initial data on startup
    window.addEventListener('load', function() {
      initCameraList();

      if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run
          .withSuccessHandler(function(records) {
            if (records && records.length > 0) {
              todayRecords = records;
              renderTodayList();
            }
          })
          .getTodayAttendance();
      }
    });
  </script>
</body>
</html>
`;
}
