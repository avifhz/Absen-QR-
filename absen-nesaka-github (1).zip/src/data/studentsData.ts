export interface Student {
  id: string; // usually NIS or sanitized ID
  nis: string;
  name: string;
  gender: 'L' | 'P';
  className: string;
  exemptReligious?: boolean; // Khusus Jevanya (9 Mataram) dan Diva Widiana (7 Mataram)
  parentPhone?: string; // Nomor WhatsApp Orang Tua / Wali (contoh: 081234567890)
}

export const INITIAL_STUDENTS: Student[] = [
  // ================= KELAS 7 KUTAI (33 Siswa) =================
  { id: "06694", nis: "06694", name: "ADIB ZAKI PRATAMA", gender: "L", className: "7 Kutai" },
  { id: "06695", nis: "06695", name: "AISYA", gender: "P", className: "7 Kutai" },
  { id: "06696", nis: "06696", name: "ALBY RIZKY RAMADHANI", gender: "L", className: "7 Kutai" },
  { id: "06697", nis: "06697", name: "ALEXA NANDA NOR IMAM", gender: "L", className: "7 Kutai" },
  { id: "06698", nis: "06698", name: "ARDI KHOIRUL ADHA", gender: "L", className: "7 Kutai" },
  { id: "06699", nis: "06699", name: "CARISSA DEANDRA", gender: "P", className: "7 Kutai" },
  { id: "06700", nis: "06700", name: "CELLINA TASYA RAMADHANI", gender: "P", className: "7 Kutai" },
  { id: "06701", nis: "06701", name: "DILLA NOVITA SARI", gender: "P", className: "7 Kutai" },
  { id: "06702", nis: "06702", name: "DINDA NURAINI", gender: "P", className: "7 Kutai" },
  { id: "06703", nis: "06703", name: "ELLENA SUKMAWATI MEYLAN", gender: "P", className: "7 Kutai" },
  { id: "06704", nis: "06704", name: "EMBUN KHANZA ARVANIA", gender: "P", className: "7 Kutai" },
  { id: "06705", nis: "06705", name: "HABIBUR ROHMAN", gender: "L", className: "7 Kutai" },
  { id: "06706", nis: "06706", name: "HERFIZA KHANZA ALZAHRA", gender: "P", className: "7 Kutai" },
  { id: "06707", nis: "06707", name: "MARCHELIA ANGEL", gender: "P", className: "7 Kutai" },
  { id: "06708", nis: "06708", name: "MAXIMILIANUS WAHYU GALIH PRADANA", gender: "L", className: "7 Kutai", exemptReligious: true },
  { id: "06709", nis: "06709", name: "MOZA AYUDIA ARTAFIA", gender: "P", className: "7 Kutai" },
  { id: "06710", nis: "06710", name: "MUCHAMMAD NAFI'", gender: "L", className: "7 Kutai" },
  { id: "06711", nis: "06711", name: "MUHAMMAD ADI TIYA", gender: "L", className: "7 Kutai" },
  { id: "06712", nis: "06712", name: "MUHAMMAD DAFFA PRATAMA", gender: "L", className: "7 Kutai" },
  { id: "06713", nis: "06713", name: "MUHAMMAD ILHAM RAMADHAN", gender: "L", className: "7 Kutai" },
  { id: "06714", nis: "06714", name: "MUHAMMAD WILDAN RAMA SANJAYA", gender: "L", className: "7 Kutai" },
  { id: "06715", nis: "06715", name: "MUSLIMAH KHOIRIYAH IZZATI", gender: "P", className: "7 Kutai" },
  { id: "06716", nis: "06716", name: "NIZAM DWI SAPUTRA", gender: "L", className: "7 Kutai" },
  { id: "06717", nis: "06717", name: "PUTRA WAHYU ARJUNA", gender: "L", className: "7 Kutai" },
  { id: "06718", nis: "06718", name: "RAVELIO RUDI PRASTYO", gender: "L", className: "7 Kutai" },
  { id: "06719", nis: "06719", name: "RIFKY ASCA PRATAMA", gender: "L", className: "7 Kutai" },
  { id: "06720", nis: "06720", name: "RIZKY FEBRIANSYAH RAMADHANI", gender: "L", className: "7 Kutai" },
  { id: "06721", nis: "06721", name: "SALSABILA QATRUNNADA", gender: "P", className: "7 Kutai" },
  { id: "06722", nis: "06722", name: "SANJAYA ARDHIKA PRATAMA", gender: "L", className: "7 Kutai" },
  { id: "06723", nis: "06723", name: "SHAKIRA TALITA ZAHRA", gender: "P", className: "7 Kutai" },
  { id: "06724", nis: "06724", name: "SYAKIRA AYLA NADHIIFAH", gender: "P", className: "7 Kutai" },
  { id: "06725", nis: "06725", name: "TUFA AZAHRA", gender: "P", className: "7 Kutai" },
  { id: "06726", nis: "06726", name: "ULFATUN KHOMILAH", gender: "P", className: "7 Kutai" },

  // ================= KELAS 7 MAJAPAHIT (33 Siswa) =================
  { id: "06727", nis: "06727", name: "ABIZAR MANDA RAMADHAN", gender: "L", className: "7 Majapahit" },
  { id: "06728", nis: "06728", name: "ALDI LUTHFY FACHRY", gender: "L", className: "7 Majapahit" },
  { id: "06729", nis: "06729", name: "ALMIRA TALITA ZAHRA", gender: "P", className: "7 Majapahit" },
  { id: "06730", nis: "06730", name: "AMELILA RAMADHANI", gender: "P", className: "7 Majapahit" },
  { id: "06731", nis: "06731", name: "AMIRAH FIRA ZAHRA", gender: "P", className: "7 Majapahit" },
  { id: "06732", nis: "06732", name: "ANANDANA KANTATA CAHYA", gender: "L", className: "7 Majapahit" },
  { id: "06733", nis: "06733", name: "AQIDATUL IZAA NUR KHOIRUNNISA", gender: "P", className: "7 Majapahit" },
  { id: "06734", nis: "06734", name: "ARDAN PUTRA IMZIANANDO", gender: "L", className: "7 Majapahit" },
  { id: "06735", nis: "06735", name: "AULIA IZZATUNNISA", gender: "P", className: "7 Majapahit" },
  { id: "06736", nis: "06736", name: "AULYA FEBBY MARCELLA", gender: "P", className: "7 Majapahit" },
  { id: "06737", nis: "06737", name: "AURORA PRADITA PUTRI", gender: "P", className: "7 Majapahit" },
  { id: "06738", nis: "06738", name: "AVIKA AYU CAHYANI", gender: "P", className: "7 Majapahit" },
  { id: "06739", nis: "06739", name: "AZIZAH BELLA KHOIRUNISA", gender: "P", className: "7 Majapahit" },
  { id: "06740", nis: "06740", name: "DAEHAN FACHRURROZI", gender: "L", className: "7 Majapahit" },
  { id: "06741", nis: "06741", name: "GISEL ANATASYA", gender: "P", className: "7 Majapahit" },
  { id: "06742", nis: "06742", name: "HERRIS ROBBI MANTOFA", gender: "L", className: "7 Majapahit" },
  { id: "06743", nis: "06743", name: "HUMAIRA TRI HANEY RAMADANI", gender: "P", className: "7 Majapahit" },
  { id: "06744", nis: "06744", name: "LAILATUL ASYIFA NUR FADILA", gender: "P", className: "7 Majapahit" },
  { id: "06745", nis: "06745", name: "M. DICKY ALVARO", gender: "L", className: "7 Majapahit" },
  { id: "06746", nis: "06746", name: "MAULANA FIRDAUS RAMADAN", gender: "L", className: "7 Majapahit" },
  { id: "06747", nis: "06747", name: "MAULANA RIZAL NUR ABDILAH", gender: "L", className: "7 Majapahit" },
  { id: "06748", nis: "06748", name: "MIKHAYLA NADYA AYUNDA", gender: "P", className: "7 Majapahit" },
  { id: "06749", nis: "06749", name: "MOCHAMAD RIDHUAN EGY PRASETYA", gender: "L", className: "7 Majapahit" },
  { id: "06750", nis: "06750", name: "MUCHAMMAD RIDWAN ARDIANSYAH", gender: "L", className: "7 Majapahit" },
  { id: "06751", nis: "06751", name: "MUHAMMAD BAGAS DISTYANDRA", gender: "L", className: "7 Majapahit" },
  { id: "06752", nis: "06752", name: "MUHAMMAD FADHIL JADZILAZIKRA", gender: "L", className: "7 Majapahit" },
  { id: "06753", nis: "06753", name: "MUHAMMAD VANO SYAHRONI", gender: "L", className: "7 Majapahit" },
  { id: "06754", nis: "06754", name: "NAFISA AULIA AVANDA RESMITA", gender: "P", className: "7 Majapahit" },
  { id: "06755", nis: "06755", name: "PUTRI AIDA NURWANDINI", gender: "P", className: "7 Majapahit" },
  { id: "06756", nis: "06756", name: "PUTRI CHELXIEA FARADECTA", gender: "P", className: "7 Majapahit" },
  { id: "06757", nis: "06757", name: "SATIYADI CAHYONO KURNIAWAN", gender: "L", className: "7 Majapahit" },
  { id: "06758", nis: "06758", name: "YA'QUB KHIDMATUL AMRU", gender: "L", className: "7 Majapahit" },
  { id: "06759", nis: "06759", name: "ZAKY FEBIANSAH PUTRA", gender: "L", className: "7 Majapahit" },

  // ================= KELAS 7 MATARAM (33 Siswa) =================
  { id: "06760", nis: "06760", name: "ABILA PRASTIKA", gender: "P", className: "7 Mataram" },
  { id: "06761", nis: "06761", name: "ACHMAD ARIEFIN SETYONO", gender: "L", className: "7 Mataram" },
  { id: "06762", nis: "06762", name: "ADELIA PUTRI CANTIKA", gender: "P", className: "7 Mataram" },
  { id: "06763", nis: "06763", name: "ADINDA NAYLA RAHMAH", gender: "P", className: "7 Mataram" },
  { id: "06764", nis: "06764", name: "AFIKA CAHYANI", gender: "P", className: "7 Mataram" },
  { id: "06765", nis: "06765", name: "AHMAD RIEVKY ALBRIANTO", gender: "L", className: "7 Mataram" },
  { id: "06766", nis: "06766", name: "AKHMAD RIZKI RAMADHANI", gender: "L", className: "7 Mataram" },
  { id: "06767", nis: "06767", name: "ARJUNA BAYU PRATAMA", gender: "L", className: "7 Mataram" },
  { id: "06768", nis: "06768", name: "AYLA NATASYA AZAHRA", gender: "P", className: "7 Mataram" },
  { id: "06769", nis: "06769", name: "CALVIN ALIFER WILDAN SEPTIAN", gender: "L", className: "7 Mataram" },
  { id: "06770", nis: "06770", name: "CHYNTIA PUTRI ANGELINA", gender: "P", className: "7 Mataram" },
  { id: "06771", nis: "06771", name: "ELI ROHAYATI", gender: "P", className: "7 Mataram" },
  { id: "06772", nis: "06772", name: "FABIAN MAULANA", gender: "L", className: "7 Mataram" },
  { id: "06773", nis: "06773", name: "FAREL YUAN SYAHBANA", gender: "L", className: "7 Mataram" },
  { id: "06774", nis: "06774", name: "KAFA BIH MUGHITSAN", gender: "L", className: "7 Mataram" },
  { id: "06775", nis: "06775", name: "KELVIN FERDIANSYAH", gender: "L", className: "7 Mataram" },
  { id: "06776", nis: "06776", name: "KEVIN ALVARO CAHYA ARDANA", gender: "L", className: "7 Mataram" },
  { id: "06777", nis: "06777", name: "KHOLIFATUL EKA LILYANA", gender: "P", className: "7 Mataram" },
  { id: "06778", nis: "06778", name: "LUHITA MAYA INDRASWARI", gender: "P", className: "7 Mataram" },
  { id: "06779", nis: "06779", name: "MASHILAL KENZIE DAPHA", gender: "L", className: "7 Mataram" },
  { id: "06780", nis: "06780", name: "MIKO ARDIANSYAH SAPUTRA", gender: "L", className: "7 Mataram" },
  { id: "06782", nis: "06782", name: "NADA BELLVANIA CINTA KIRANA", gender: "P", className: "7 Mataram" },
  { id: "06783", nis: "06783", name: "NAVISA AYU NABILA", gender: "P", className: "7 Mataram" },
  { id: "06784", nis: "06784", name: "NAYLA NUR FIDAYAH", gender: "L", className: "7 Mataram" },
  { id: "06785", nis: "06785", name: "NUR HUTSSY ELYA NADIYANA FILLAH", gender: "P", className: "7 Mataram" },
  { id: "06786", nis: "06786", name: "QUEENZA DESYCA FONNA WIDODO", gender: "P", className: "7 Mataram" },
  { id: "06787", nis: "06787", name: "RAMDHANIA RISMA SEPTIANI", gender: "P", className: "7 Mataram" },
  { id: "06788", nis: "06788", name: "RENDRA VINCENT ALDIRA CAESAR", gender: "L", className: "7 Mataram" },
  { id: "06789", nis: "06789", name: "REZTU EKA RAMADHAN", gender: "L", className: "7 Mataram" },
  { id: "06790", nis: "06790", name: "SANDY ARGYHA ANDIKA WIDODO", gender: "L", className: "7 Mataram" },
  { id: "06791", nis: "06791", name: "SYAFA'ATUL AYU ANDIRA", gender: "P", className: "7 Mataram" },
  { id: "06792", nis: "06792", name: "TRIZTA DEWI ARINI", gender: "P", className: "7 Mataram" },
  { id: "06861", nis: "06861", name: "DIVA WIDIANA", gender: "P", className: "7 Mataram", exemptReligious: true },

  // ================= KELAS 7 SINGHASARI (33 Siswa) =================
  { id: "06793", nis: "06793", name: "AHMAD FAJAR HANDIKA", gender: "L", className: "7 Singhasari" },
  { id: "06794", nis: "06794", name: "AKHADI WIRA SATRIAJI", gender: "L", className: "7 Singhasari" },
  { id: "06795", nis: "06795", name: "ANDHINI INTAN SYAFILLA", gender: "P", className: "7 Singhasari" },
  { id: "06796", nis: "06796", name: "AQILA NURRIL AZZAHRA", gender: "P", className: "7 Singhasari" },
  { id: "06797", nis: "06797", name: "AS-SYIFA MEIDA SAFIRA", gender: "P", className: "7 Singhasari" },
  { id: "06798", nis: "06798", name: "ATHALA BIMA SYAPUTRA", gender: "L", className: "7 Singhasari" },
  { id: "06799", nis: "06799", name: "AULIYA NAFIZAH DWI AGUSTIN", gender: "P", className: "7 Singhasari" },
  { id: "06800", nis: "06800", name: "AYU PUSPITA SARI", gender: "P", className: "7 Singhasari" },
  { id: "06801", nis: "06801", name: "AZZAM RAEHAN RAHARJO", gender: "L", className: "7 Singhasari" },
  { id: "06802", nis: "06802", name: "DAVA PRATAMA", gender: "L", className: "7 Singhasari" },
  { id: "06803", nis: "06803", name: "DENIKA LAILA ANANDITA", gender: "P", className: "7 Singhasari" },
  { id: "06804", nis: "06804", name: "EZA YUSRIANSYAH", gender: "L", className: "7 Singhasari" },
  { id: "06805", nis: "06805", name: "GISHEL KAYLA AZZAHRA", gender: "P", className: "7 Singhasari" },
  { id: "06806", nis: "06806", name: "JASSICA ELLIENA EVELLIEN", gender: "P", className: "7 Singhasari" },
  { id: "06807", nis: "06807", name: "JESSICA SILVIANA DEWI", gender: "P", className: "7 Singhasari" },
  { id: "06808", nis: "06808", name: "JIHAN TANIA AZZAHRA", gender: "P", className: "7 Singhasari" },
  { id: "06809", nis: "06809", name: "M GIBRAN AL HAFIDZ", gender: "L", className: "7 Singhasari" },
  { id: "06810", nis: "06810", name: "MUHAMAD KEVIN ADITYA SAPUTRA", gender: "L", className: "7 Singhasari" },
  { id: "06811", nis: "06811", name: "MUHAMMAD ABHIZAR", gender: "L", className: "7 Singhasari" },
  { id: "06812", nis: "06812", name: "MUHAMMAD AZRIL", gender: "L", className: "7 Singhasari" },
  { id: "06813", nis: "06813", name: "MUHAMMAD DARMA RADITYO", gender: "L", className: "7 Singhasari" },
  { id: "06814", nis: "06814", name: "MUHAMMAD HAFIDZ AMAR", gender: "L", className: "7 Singhasari" },
  { id: "06815", nis: "06815", name: "MUHAMMAD RAFID AKMAL", gender: "L", className: "7 Singhasari" },
  { id: "06816", nis: "06816", name: "NAYLA AZZAHRA", gender: "P", className: "7 Singhasari" },
  { id: "06817", nis: "06817", name: "OKTAMA ADE PRASETYA", gender: "L", className: "7 Singhasari" },
  { id: "06818", nis: "06818", name: "OKTAVIA PRADITA SARI", gender: "P", className: "7 Singhasari" },
  { id: "06819", nis: "06819", name: "QUEENSHEA ALIYA RAMADHANI", gender: "P", className: "7 Singhasari" },
  { id: "06820", nis: "06820", name: "RIZKA AFRIANDITA AMANDA", gender: "P", className: "7 Singhasari" },
  { id: "06821", nis: "06821", name: "SA'AD NAZIL MAULANA", gender: "L", className: "7 Singhasari" },
  { id: "06822", nis: "06822", name: "TIRTA AWANGGA", gender: "L", className: "7 Singhasari" },
  { id: "06823", nis: "06823", name: "UMAIROH AINUN MAHYA", gender: "P", className: "7 Singhasari" },
  { id: "06824", nis: "06824", name: "WIDI DHIVA DHASYILVA", gender: "P", className: "7 Singhasari" },
  { id: "06825", nis: "06825", name: "ZUHRO FAIDA ANNAILA", gender: "P", className: "7 Singhasari" },

  // ================= KELAS 7 SRIWIJAYA (33 Siswa) =================
  { id: "06826", nis: "06826", name: "ACHMAD RAFA ALFARIZI", gender: "L", className: "7 Sriwijaya" },
  { id: "06827", nis: "06827", name: "ADELA NADYATUS SHOLEHA", gender: "P", className: "7 Sriwijaya" },
  { id: "06828", nis: "06828", name: "ADELIA RISMA", gender: "P", className: "7 Sriwijaya" },
  { id: "06829", nis: "06829", name: "AGUNG DWI PUTRA RAMADHAN", gender: "L", className: "7 Sriwijaya" },
  { id: "06830", nis: "06830", name: "ALIEF PRANATA", gender: "L", className: "7 Sriwijaya" },
  { id: "06831", nis: "06831", name: "ALIFAH EKA NURONA", gender: "P", className: "7 Sriwijaya" },
  { id: "06832", nis: "06832", name: "ALVIAN MIFTHAKUL PRATAMA", gender: "L", className: "7 Sriwijaya" },
  { id: "06833", nis: "06833", name: "ALVINO FAJAR WIDIANTORO", gender: "L", className: "7 Sriwijaya" },
  { id: "06834", nis: "06834", name: "ANANDA FANDI SAPUTRA", gender: "L", className: "7 Sriwijaya" },
  { id: "06835", nis: "06835", name: "AQILA OKTA ALIFIA FARIZHA", gender: "P", className: "7 Sriwijaya" },
  { id: "06836", nis: "06836", name: "AISYAH MIKAYLA GUNAWAN", gender: "P", className: "7 Sriwijaya" },
  { id: "06837", nis: "06837", name: "AUFAR ZAHIRUD DIYA ALDIN", gender: "L", className: "7 Sriwijaya" },
  { id: "06838", nis: "06838", name: "AZHARIA JEVA ARIE RIZKYAN", gender: "L", className: "7 Sriwijaya" },
  { id: "06839", nis: "06839", name: "BILAL AL FARISI", gender: "L", className: "7 Sriwijaya" },
  { id: "06840", nis: "06840", name: "BILQIS YERIS UFAIRA", gender: "P", className: "7 Sriwijaya" },
  { id: "06841", nis: "06841", name: "CHIKA SEPTI AURELYA", gender: "P", className: "7 Sriwijaya" },
  { id: "06842", nis: "06842", name: "DANENDRA GIBRAN YURI ALVARO", gender: "L", className: "7 Sriwijaya" },
  { id: "06843", nis: "06843", name: "DELILA PUTRI AZAHRA ISHAURA", gender: "P", className: "7 Sriwijaya" },
  { id: "06844", nis: "06844", name: "FAREL ALHAM SULISTYO", gender: "L", className: "7 Sriwijaya" },
  { id: "06845", nis: "06845", name: "FARIS TRI ALDIANO", gender: "L", className: "7 Sriwijaya" },
  { id: "06846", nis: "06846", name: "GENDIS DIRKHA AVANZA", gender: "P", className: "7 Sriwijaya" },
  { id: "06847", nis: "06847", name: "GISHELVA ATHIFA WIJAYA", gender: "P", className: "7 Sriwijaya" },
  { id: "06848", nis: "06848", name: "GRACELLA ANANDA", gender: "P", className: "7 Sriwijaya" },
  { id: "06849", nis: "06849", name: "INAYA AZMI ATHIFA", gender: "P", className: "7 Sriwijaya" },
  { id: "06850", nis: "06850", name: "KANAYA AYUNINDITA", gender: "P", className: "7 Sriwijaya" },
  { id: "06851", nis: "06851", name: "MUHAMMAD DARUN NAFIS SAPUTRA", gender: "L", className: "7 Sriwijaya" },
  { id: "06852", nis: "06852", name: "NAUFAL ALVIAN FAEYZHA", gender: "L", className: "7 Sriwijaya" },
  { id: "06853", nis: "06853", name: "NAURA AYUNDA CITRA", gender: "P", className: "7 Sriwijaya" },
  { id: "06854", nis: "06854", name: "ROFFI AUFAR MAULANA PRASMIANTO", gender: "L", className: "7 Sriwijaya" },
  { id: "06855", nis: "06855", name: "TALITA KHUMAIRO HANIFA", gender: "P", className: "7 Sriwijaya" },
  { id: "06856", nis: "06856", name: "TEJA KURNIAWAN", gender: "L", className: "7 Sriwijaya" },
  { id: "06857", nis: "06857", name: "WILLIAM PUTRA WAIN", gender: "L", className: "7 Sriwijaya" },
  { id: "06858", nis: "06858", name: "ZASKIA ANINDHITA RAHMADANI", gender: "P", className: "7 Sriwijaya" },

  // ================= KELAS 8 KUTAI (34 Siswa) =================
  { id: "06619", nis: "06619", name: "ABDUL ROHMAN ALFAHRI", gender: "L", className: "8 Kutai" },
  { id: "06588", nis: "06588", name: "AHMAD FAUZI BAGAS PRASETYO", gender: "L", className: "8 Kutai" },
  { id: "06590", nis: "06590", name: "ANAZTASIA PRITHA FEBBY NURAINI", gender: "P", className: "8 Kutai" },
  { id: "06692", nis: "06692", name: "AULIA PUTRI SYAFIRA", gender: "P", className: "8 Kutai" },
  { id: "06661", nis: "06661", name: "CHEVIRA AULIA NADJASHA", gender: "P", className: "8 Kutai" },
  { id: "06666", nis: "06666", name: "DEA CALISTA FAUSTINA PUTRI", gender: "P", className: "8 Kutai" },
  { id: "06594", nis: "06594", name: "DEALOVAGA ARIMBI EAPASE", gender: "P", className: "8 Kutai" },
  { id: "06628", nis: "06628", name: "DWI FITRIANI", gender: "P", className: "8 Kutai" },
  { id: "06536", nis: "06536", name: "EKA DEVIANA RONY SETYOWATI", gender: "P", className: "8 Kutai" },
  { id: "06596", nis: "06596", name: "ELMA NURAINI", gender: "P", className: "8 Kutai" },
  { id: "06668", nis: "06668", name: "ELVIRA KHAIRUN NISA", gender: "P", className: "8 Kutai" },
  { id: "06568", nis: "06568", name: "FAJAR GUMILANG", gender: "L", className: "8 Kutai" },
  { id: "06629", nis: "06629", name: "FARES AZHAR FIRDANA", gender: "L", className: "8 Kutai" },
  { id: "06630", nis: "06630", name: "FARHAN DWI APRILIO SYAHPUTRA", gender: "L", className: "8 Kutai" },
  { id: "06670", nis: "06670", name: "GEISHA KANZA AZAHRA", gender: "P", className: "8 Kutai" },
  { id: "06599", nis: "06599", name: "JEFE NUR FAHLIQ", gender: "L", className: "8 Kutai" },
  { id: "06634", nis: "06634", name: "KHARIR AZMI", gender: "L", className: "8 Kutai" },
  { id: "06574", nis: "06574", name: "MUHAMAT AJIZ RAHMADAN", gender: "L", className: "8 Kutai" },
  { id: "06544", nis: "06544", name: "MUHAMMAD RAIHAN SAPUTRA", gender: "L", className: "8 Kutai" },
  { id: "06637", nis: "06637", name: "MUHAMMAD RIFKY RAMADHAN", gender: "L", className: "8 Kutai" },
  { id: "06547", nis: "06547", name: "NASYIFA ANINDYA KINARIAN", gender: "P", className: "8 Kutai" },
  { id: "06579", nis: "06579", name: "RADITYA PRAMA PUTRA", gender: "L", className: "8 Kutai" },
  { id: "06580", nis: "06580", name: "RAFFAEL ADITYA RAMADHANI", gender: "L", className: "8 Kutai" },
  { id: "06641", nis: "06641", name: "RAHMAT FAUZAN CATUR TRISWI", gender: "L", className: "8 Kutai" },
  { id: "06581", nis: "06581", name: "REFIN AZZAMI SAUKI", gender: "L", className: "8 Kutai" },
  { id: "06583", nis: "06583", name: "RETNO CAHAYA PUTRI HARIYANTO", gender: "P", className: "8 Kutai" },
  { id: "06610", nis: "06610", name: "RIVAL DWI SEPTIAWAN", gender: "L", className: "8 Kutai" },
  { id: "06585", nis: "06585", name: "SYAQILLA CHELSEA RAHMADITYA", gender: "P", className: "8 Kutai" },
  { id: "06553", nis: "06553", name: "TIARA ANEZKABILLAH", gender: "P", className: "8 Kutai" },
  { id: "06586", nis: "06586", name: "VANESSA MAULIDINA PUTRI", gender: "P", className: "8 Kutai" },
  { id: "06554", nis: "06554", name: "VILEN MARETA PUTRI", gender: "P", className: "8 Kutai" },
  { id: "06616", nis: "06616", name: "YUAN DIANDRA ARMANDO TORRES", gender: "L", className: "8 Kutai" },
  { id: "06587", nis: "06587", name: "ZIHAN RAMADANIA", gender: "P", className: "8 Kutai" },
  { id: "06860", nis: "06860", name: "RIZKY ASEN ARYANDANU", gender: "L", className: "8 Kutai" },

  // ================= KELAS 8 MAJAPAHIT (33 Siswa) =================
  { id: "06653", nis: "06653", name: "ADHIMAS SATYO LUKMANSYAH", gender: "L", className: "8 Majapahit" },
  { id: "06654", nis: "06654", name: "AFZAAL ZAKI YUSUF. P", gender: "L", className: "8 Majapahit" },
  { id: "06527", nis: "06527", name: "AGUSTINA ZAHRA EKA AMELIA", gender: "P", className: "8 Majapahit" },
  { id: "06559", nis: "06559", name: "AISHAH MELDAWATI", gender: "P", className: "8 Majapahit" },
  { id: "06656", nis: "06656", name: "AKHILA ZAHRA REVALDA", gender: "P", className: "8 Majapahit" },
  { id: "06560", nis: "06560", name: "ALEA WENZA ONEVIA", gender: "P", className: "8 Majapahit" },
  { id: "06626", nis: "06626", name: "ARJUNA DAVA SAPUTRA", gender: "L", className: "8 Majapahit" },
  { id: "06657", nis: "06657", name: "AULIA ZAHWA SAFANA", gender: "P", className: "8 Majapahit" },
  { id: "06658", nis: "06658", name: "BARA KEYTAMA WIDIANTORO", gender: "L", className: "8 Majapahit" },
  { id: "06660", nis: "06660", name: "CHELLO PUTRA MAHARDIKA", gender: "L", className: "8 Majapahit" },
  { id: "06662", nis: "06662", name: "CHIKA DEVINA RAMADHANTI", gender: "P", className: "8 Majapahit" },
  { id: "06533", nis: "06533", name: "DAFA AJI SAKA AL BARA RAMADHAN", gender: "L", className: "8 Majapahit" },
  { id: "06665", nis: "06665", name: "DAVIAN RUDITA PUTRA", gender: "L", className: "8 Majapahit" },
  { id: "06632", nis: "06632", name: "GISYA NURFITA SARI", gender: "P", className: "8 Majapahit" },
  { id: "06598", nis: "06598", name: "IBRAHIM HAFID PRASETYO", gender: "L", className: "8 Majapahit" },
  { id: "06672", nis: "06672", name: "KEYLA AZZAHRA AULIA", gender: "P", className: "8 Majapahit" },
  { id: "06541", nis: "06541", name: "LING LING ZULFA NUR AZIZAH", gender: "P", className: "8 Majapahit" },
  { id: "06676", nis: "06676", name: "MOCH HAFIZ DAFA MAULANA", gender: "L", className: "8 Majapahit" },
  { id: "06677", nis: "06677", name: "MUHAMMAD ALEAN YUDISWINATA", gender: "L", className: "8 Majapahit" },
  { id: "06679", nis: "06679", name: "MUHAMMAD RAFFA ARDHANA SETIAWAN", gender: "L", className: "8 Majapahit" },
  { id: "06545", nis: "06545", name: "MUHAMMAD RIFKY TRI ADITAMA", gender: "L", className: "8 Majapahit" },
  { id: "06548", nis: "06548", name: "OCTAVINAYA KARAROP", gender: "P", className: "8 Majapahit" },
  { id: "06639", nis: "06639", name: "PRAMUDITA AZHA DEWI", gender: "P", className: "8 Majapahit" },
  { id: "06680", nis: "06680", name: "PRASTA PUTRA BRAHMA WISNU SETYA JAYA", gender: "L", className: "8 Majapahit" },
  { id: "06681", nis: "06681", name: "PRATIWI SETYO NINGRUM", gender: "P", className: "8 Majapahit" },
  { id: "06642", nis: "06642", name: "RAVASHA NUR ALIFIANSYAH", gender: "L", className: "8 Majapahit" },
  { id: "06683", nis: "06683", name: "RIDHO DARMA PRAYOGA", gender: "L", className: "8 Majapahit" },
  { id: "06584", nis: "06584", name: "RISA DWI SURYANINGSIH", gender: "P", className: "8 Majapahit" },
  { id: "06611", nis: "06611", name: "RIZKILAH AISYAHRANI", gender: "P", className: "8 Majapahit" },
  { id: "06684", nis: "06684", name: "SAKA BAGAS AJI SUNARKO", gender: "L", className: "8 Majapahit" },
  { id: "06615", nis: "06615", name: "SYAVIRA SYAFA'ATU ROHMAH", gender: "P", className: "8 Majapahit" },
  { id: "06618", nis: "06618", name: "ZAFANIA AURELYA PRASETYA", gender: "P", className: "8 Majapahit" },
  { id: "06685", nis: "06685", name: "ZULFA NAHDIANA MAHDIYA", gender: "P", className: "8 Majapahit" },

  // ================= KELAS 8 MATARAM (32 Siswa) =================
  { id: "06525", nis: "06525", name: "ADAM MUHAMAD YUNA", gender: "L", className: "8 Mataram" },
  { id: "06655", nis: "06655", name: "AGISTA DEVIA SARI", gender: "P", className: "8 Mataram" },
  { id: "06528", nis: "06528", name: "AKMAL HAFIDH AUFA EDY ASHFA", gender: "L", className: "8 Mataram" },
  { id: "06621", nis: "06621", name: "ALIEF ARIYA PUTRA", gender: "L", className: "8 Mataram" },
  { id: "06622", nis: "06622", name: "ALIKA JAZILATUZ ZAHRA", gender: "P", className: "8 Mataram" },
  { id: "06625", nis: "06625", name: "ARIDA SYAFINANDA", gender: "P", className: "8 Mataram" },
  { id: "06562", nis: "06562", name: "ASCADIO REZKA EFENDI", gender: "L", className: "8 Mataram" },
  { id: "06662_8mat", nis: "06662", name: "CHIKA AULIASARI", gender: "P", className: "8 Mataram" },
  { id: "06564", nis: "06564", name: "CINTA MEY IZATUL ILMI", gender: "P", className: "8 Mataram" },
  { id: "06534", nis: "06534", name: "DELA AULIA", gender: "P", className: "8 Mataram" },
  { id: "06565", nis: "06565", name: "DELICIA ANGGUN HELMALIA PUTRI", gender: "P", className: "8 Mataram" },
  { id: "06669", nis: "06669", name: "FITRI NUR WAHYUNI", gender: "P", className: "8 Mataram" },
  { id: "06571", nis: "06571", name: "ILHAM RAMADANI", gender: "L", className: "8 Mataram" },
  { id: "06691", nis: "06691", name: "INDAH DEWI MAULANI", gender: "P", className: "8 Mataram" },
  { id: "06540", nis: "06540", name: "IVANDER ERICK CANTONA HARYONO", gender: "L", className: "8 Mataram" },
  { id: "06600", nis: "06600", name: "KEVIN PUTRA DWI PRATAMA", gender: "L", className: "8 Mataram" },
  { id: "06601", nis: "06601", name: "KHOIRUN NISA'", gender: "P", className: "8 Mataram" },
  { id: "06603", nis: "06603", name: "MARCEL NUR PRATAMA", gender: "L", className: "8 Mataram" },
  { id: "06604", nis: "06604", name: "MUHAMMAD AZKA FATHURROHMAN", gender: "L", className: "8 Mataram" },
  { id: "06693", nis: "06693", name: "NADIA AULIA RAHMAWATI", gender: "P", className: "8 Mataram" },
  { id: "06549", nis: "06549", name: "RAHEL WAHYU PUTRA DARMANSYAH", gender: "L", className: "8 Mataram" },
  { id: "06582", nis: "06582", name: "REHAN PUTRA ARDIANSYAH", gender: "L", className: "8 Mataram" },
  { id: "06608", nis: "06608", name: "RENDI SANTOSO", gender: "L", className: "8 Mataram" },
  { id: "06550", nis: "06550", name: "RENSY WIDY BELINDA", gender: "P", className: "8 Mataram" },
  { id: "06645", nis: "06645", name: "REYNA AILIZIA YURI", gender: "P", className: "8 Mataram" },
  { id: "06609", nis: "06609", name: "RISKA SIVA PUTRI", gender: "P", className: "8 Mataram" },
  { id: "06551", nis: "06551", name: "ROSSA MEUTHIA MUCHTAR", gender: "P", className: "8 Mataram" },
  { id: "06647", nis: "06647", name: "SAFIRA AMIRLI", gender: "P", className: "8 Mataram" },
  { id: "06552", nis: "06552", name: "SATRIA EKA PUTRA PRATAMA", gender: "L", className: "8 Mataram" },
  { id: "06648", nis: "06648", name: "SAVIA PUTRI NABILA", gender: "P", className: "8 Mataram" },
  { id: "06650", nis: "06650", name: "SHOFYAN ABID ARSYAD", gender: "L", className: "8 Mataram" },
  { id: "06651", nis: "06651", name: "SULTAN FADHIL FABIYAN", gender: "L", className: "8 Mataram" },

  // ================= KELAS 8 SINGHASARI (33 Siswa) =================
  { id: "06561", nis: "06561", name: "ALFINZA ETGAR AVRIELDO", gender: "L", className: "8 Singhasari" },
  { id: "06589", nis: "06589", name: "AMIRA IZZATULIFA", gender: "P", className: "8 Singhasari" },
  { id: "06624", nis: "06624", name: "ANDRIAN NUR CAHYO", gender: "L", className: "8 Singhasari" },
  { id: "06591", nis: "06591", name: "AQIL ARIF SAPUTRA", gender: "L", className: "8 Singhasari" },
  { id: "06531", nis: "06531", name: "AZAM ASADULLAH", gender: "L", className: "8 Singhasari" },
  { id: "06563", nis: "06563", name: "BINTANG KELANA ABIANU", gender: "L", className: "8 Singhasari" },
  { id: "06532", nis: "06532", name: "CAHAYA VANESSA POETRI", gender: "P", className: "8 Singhasari" },
  { id: "06667", nis: "06667", name: "DENIA ANGGREINY", gender: "P", className: "8 Singhasari" },
  { id: "06535", nis: "06535", name: "DIMAS BAGUS ROHMATULLOH", gender: "L", className: "8 Singhasari" },
  { id: "06567", nis: "06567", name: "ERSA FEBRIANI", gender: "P", className: "8 Singhasari" },
  { id: "06538", nis: "06538", name: "FANNI AYU RISA", gender: "P", className: "8 Singhasari" },
  { id: "06569", nis: "06569", name: "FAREL YULIAN ALFAREZA", gender: "L", className: "8 Singhasari" },
  { id: "06570", nis: "06570", name: "HASNA NABILA SYARIFAH", gender: "P", className: "8 Singhasari" },
  { id: "06635", nis: "06635", name: "KHUMAIROH SHOFIYAH AL ADAWIYAH", gender: "P", className: "8 Singhasari" },
  { id: "06687", nis: "06687", name: "KRISHA NADIA FIRLI", gender: "P", className: "8 Singhasari" },
  { id: "06673", nis: "06673", name: "LUCKI SEFTIANO ADI PUTRA", gender: "L", className: "8 Singhasari" },
  { id: "06674", nis: "06674", name: "M AFIF FIRDAUS", gender: "L", className: "8 Singhasari" },
  { id: "06605", nis: "06605", name: "MUHAMMAD FAAZA ADHIMA", gender: "L", className: "8 Singhasari" },
  { id: "06606", nis: "06606", name: "MUHAMMAD FAISAL PRATAMA", gender: "L", className: "8 Singhasari" },
  { id: "06678", nis: "06678", name: "MUHAMMAD NAZRIL IZAM", gender: "L", className: "8 Singhasari" },
  { id: "06543", nis: "06543", name: "MUHAMMAD RAFAEL DWI RYHANDIKA", gender: "L", className: "8 Singhasari" },
  { id: "06576", nis: "06576", name: "NAYLA SARUJIANTI", gender: "P", className: "8 Singhasari" },
  { id: "06689", nis: "06689", name: "NOVELA VIDA SALSABILA", gender: "P", className: "8 Singhasari" },
  { id: "06577", nis: "06577", name: "PAMELLA MEIKO NURAINI", gender: "P", className: "8 Singhasari" },
  { id: "06578", nis: "06578", name: "PRITY AULIA", gender: "P", className: "8 Singhasari" },
  { id: "06640", nis: "06640", name: "PUTRI NAURA AYA NADHIIFA", gender: "P", className: "8 Singhasari" },
  { id: "06643", nis: "06643", name: "REFI PRICILYA", gender: "P", className: "8 Singhasari" },
  { id: "06644", nis: "06644", name: "REVAN RADITYA GUTAMA", gender: "L", className: "8 Singhasari" },
  { id: "06682", nis: "06682", name: "REYHAN NURIL ARIFIN", gender: "L", className: "8 Singhasari" },
  { id: "06646", nis: "06646", name: "RISTA SRI YUANSI", gender: "P", className: "8 Singhasari" },
  { id: "06614", nis: "06614", name: "SIFA NUR APRILIANI", gender: "P", className: "8 Singhasari" },
  { id: "06555", nis: "06555", name: "VINO ABBYAN ALMUZAKKY", gender: "L", className: "8 Singhasari" },
  { id: "06859", nis: "06859", name: "MUHAMMAD ANDIKA PUTRA P.", gender: "L", className: "8 Singhasari" },

  // ================= KELAS 8 SRIWIJAYA (33 Siswa) =================
  { id: "06652", nis: "06652", name: "ADAM DAFFA GAIFALDO", gender: "L", className: "8 Sriwijaya" },
  { id: "06620", nis: "06620", name: "ADHELIA MEGA AZZAHRA", gender: "P", className: "8 Sriwijaya" },
  { id: "06526", nis: "06526", name: "AFIQ FATHA RIKO BAHTIAR", gender: "L", className: "8 Sriwijaya" },
  { id: "06557", nis: "06557", name: "AHMAD KHOIRI ABDILLAH", gender: "L", className: "8 Sriwijaya" },
  { id: "06529", nis: "06529", name: "ALANDA MAULANA", gender: "L", className: "8 Sriwijaya" },
  { id: "06623", nis: "06623", name: "ALISTYA IBANEZA ANDROMEDHA", gender: "P", className: "8 Sriwijaya" },
  { id: "06530", nis: "06530", name: "AULIYA HASANAH", gender: "P", className: "8 Sriwijaya" },
  { id: "06592", nis: "06592", name: "AURA PUTRI JELITA", gender: "P", className: "8 Sriwijaya" },
  { id: "06659", nis: "06659", name: "BIANCA FELITA PUTRIADI", gender: "P", className: "8 Sriwijaya" },
  { id: "06664", nis: "06664", name: "CLOVENISA AVRILIA EDYSON", gender: "P", className: "8 Sriwijaya" },
  { id: "06593", nis: "06593", name: "DAVA RAMADAN", gender: "L", className: "8 Sriwijaya" },
  { id: "06627", nis: "06627", name: "DESTI AULIANATASYA SOHIBAH FANESA PUTRI", gender: "P", className: "8 Sriwijaya" },
  { id: "06566", nis: "06566", name: "DHEA OKTAVIA", gender: "P", className: "8 Sriwijaya" },
  { id: "06595", nis: "06595", name: "DINDA VIKA SEBTIANA", gender: "P", className: "8 Sriwijaya" },
  { id: "06537", nis: "06537", name: "ERISA CHANDRA WINDI ANGGRAINI", gender: "P", className: "8 Sriwijaya" },
  { id: "06631", nis: "06631", name: "FARIZ NAUFAL APRILLIAN", gender: "L", className: "8 Sriwijaya" },
  { id: "06539", nis: "06539", name: "GALANG NUR RAHMADANI", gender: "L", className: "8 Sriwijaya" },
  { id: "06597", nis: "06597", name: "GIOKTA KHEZIA ANATASYA", gender: "P", className: "8 Sriwijaya" },
  { id: "06671", nis: "06671", name: "KENDY ARYA SAPUTRA", gender: "L", className: "8 Sriwijaya" },
  { id: "06636", nis: "06636", name: "LINTANG KELANA ABIANU", gender: "L", className: "8 Sriwijaya" },
  { id: "06675", nis: "06675", name: "MARCHELINO ARY ZULJARNAIN", gender: "L", className: "8 Sriwijaya" },
  { id: "06542", nis: "06542", name: "MARWAH NIZMA AZZAHRA", gender: "P", className: "8 Sriwijaya" },
  { id: "06572", nis: "06572", name: "MOH AZRIEL FIRMANSYAH", gender: "L", className: "8 Sriwijaya" },
  { id: "06573", nis: "06573", name: "MUHAMAD DEDI KURNIAWAN", gender: "L", className: "8 Sriwijaya" },
  { id: "06638", nis: "06638", name: "MUHAMMAD SYAMSIR ARAFA", gender: "L", className: "8 Sriwijaya" },
  { id: "06575", nis: "06575", name: "NAILA DHEA ARJANTI", gender: "P", className: "8 Sriwijaya" },
  { id: "06607", nis: "06607", name: "RAHMA YULIA SYAHWA", gender: "P", className: "8 Sriwijaya" },
  { id: "06612", nis: "06612", name: "SAFA NUR APRILIANA", gender: "P", className: "8 Sriwijaya" },
  { id: "06613", nis: "06613", name: "SATRIA EKA RAMADHANI", gender: "L", className: "8 Sriwijaya" },
  { id: "06649", nis: "06649", name: "SHERLY EKA PUTRI MAULITDYA", gender: "P", className: "8 Sriwijaya" },
  { id: "06617", nis: "06617", name: "YUDHA SAPUTRA ANWAR", gender: "L", className: "8 Sriwijaya" },
  { id: "06556", nis: "06556", name: "ZASKIA EKA MAHARANI", gender: "P", className: "8 Sriwijaya" },
  { id: "06781", nis: "06781", name: "ILHAM FERDIANSYAH", gender: "L", className: "8 Sriwijaya" },

  // ================= KELAS 9 MAJAPAHIT (36 Siswa) =================
  { id: "06482", nis: "06482", name: "ADE RAIVAN EKA OCKTA RAMADHANI", gender: "L", className: "9 Majapahit" },
  { id: "154", nis: "154", name: "ALIA SHOFIA", gender: "P", className: "9 Majapahit" },
  { id: "06377", nis: "06377", name: "ALIFAH ONE PRATIWI", gender: "P", className: "9 Majapahit" },
  { id: "06449", nis: "06449", name: "AULIA WINDI MARFELLIA", gender: "P", className: "9 Majapahit" },
  { id: "06450", nis: "06450", name: "AZZAHRA FADILATUL T", gender: "P", className: "9 Majapahit" },
  { id: "06419", nis: "06419", name: "CANDRA WAHYU NURJANNAH", gender: "P", className: "9 Majapahit" },
  { id: "06491", nis: "06491", name: "DE ANDRA BIMA ARKANA", gender: "L", className: "9 Majapahit" },
  { id: "06489", nis: "06489", name: "DEVI KIRANA", gender: "P", className: "9 Majapahit" },
  { id: "06490", nis: "06490", name: "DEVI WIDYANDINI", gender: "P", className: "9 Majapahit" },
  { id: "06455", nis: "06455", name: "FAHMI FRANANDA ADITYA", gender: "L", className: "9 Majapahit" },
  { id: "06425", nis: "06425", name: "FRENSA ADITYA PRANATA", gender: "L", className: "9 Majapahit" },
  { id: "06497", nis: "06497", name: "GURIED DYAN ALMAGHFIRA", gender: "P", className: "9 Majapahit" },
  { id: "06456", nis: "06456", name: "HAFIDZ FIQIH NAZARUDIN", gender: "L", className: "9 Majapahit" },
  { id: "06457", nis: "06457", name: "HAFIZ AGIL NUGRAHADI", gender: "L", className: "9 Majapahit" },
  { id: "06429", nis: "06429", name: "IVAN L ARDIANSYAH", gender: "L", className: "9 Majapahit" },
  { id: "06390", nis: "06390", name: "JAMAL SYAUQIL HABIBI", gender: "L", className: "9 Majapahit" },
  { id: "06499", nis: "06499", name: "JELHIN TANIA PUTRI", gender: "P", className: "9 Majapahit" },
  { id: "06391", nis: "06391", name: "JENNYFER SHAKIRA SUSANTO", gender: "P", className: "9 Majapahit" },
  { id: "06432", nis: "06432", name: "LAYINA QOMAIDA", gender: "P", className: "9 Majapahit" },
  { id: "06503", nis: "06503", name: "LAYLA AZKA WIDOWATI", gender: "P", className: "9 Majapahit" },
  { id: "06505", nis: "06505", name: "MARSYAH PUTRA", gender: "L", className: "9 Majapahit" },
  { id: "06465", nis: "06465", name: "MUHAMMAD MIKO SAPUTRA", gender: "L", className: "9 Majapahit" },
  { id: "06466", nis: "06466", name: "NABILA CHARISSA PUTRI", gender: "P", className: "9 Majapahit" },
  { id: "06510", nis: "06510", name: "NAJLAA PUTRI NAZHIIFAH", gender: "P", className: "9 Majapahit" },
  { id: "06435", nis: "06435", name: "NATASYA RAMADHANIA PUTRI", gender: "P", className: "9 Majapahit" },
  { id: "06436", nis: "06436", name: "NAZWA AURELIA RENATA", gender: "P", className: "9 Majapahit" },
  { id: "06513", nis: "06513", name: "OLIVIA PUTRI AJI FANESA", gender: "P", className: "9 Majapahit" },
  { id: "06438", nis: "06438", name: "RAHEZHA ARSYAD ZAINHAKIM", gender: "L", className: "9 Majapahit" },
  { id: "06400", nis: "06400", name: "RAVA ALVIN NUR RIZKY", gender: "L", className: "9 Majapahit" },
  { id: "06474", nis: "06474", name: "RISKI DAVIN ANDIKA", gender: "L", className: "9 Majapahit" },
  { id: "06516", nis: "06516", name: "SHELLA APRILIANATUL KHASANAH", gender: "P", className: "9 Majapahit" },
  { id: "06406_9maj", nis: "06406", name: "SHYFA NUR AFNI AZIZAH", gender: "P", className: "9 Majapahit" },
  { id: "06443", nis: "06443", name: "TRI LINTANG AYU PRAMUDITA", gender: "P", className: "9 Majapahit" },
  { id: "06445", nis: "06445", name: "VANESA DELLA RAHMADANI", gender: "P", className: "9 Majapahit" },
  { id: "06517", nis: "06517", name: "WAHYU RIZKY PUTRA", gender: "L", className: "9 Majapahit" },
  { id: "06480", nis: "06480", name: "ZAHRO QUMALA", gender: "P", className: "9 Majapahit" },

  // ================= KELAS 9 MATARAM (35 Siswa) =================
  { id: "06372", nis: "06372", name: "ACHMAD FARHAN ADITYA", gender: "L", className: "9 Mataram" },
  { id: "06410", nis: "06410", name: "AGUS RAMADANI", gender: "L", className: "9 Mataram" },
  { id: "06411", nis: "06411", name: "AHMAD RIFKI MAULANA", gender: "L", className: "9 Mataram" },
  { id: "06483", nis: "06483", name: "AISH ALEXANDRA ZALIYANTI", gender: "P", className: "9 Mataram" },
  { id: "06486", nis: "06486", name: "ANDRO YUSTIN", gender: "L", className: "9 Mataram" },
  { id: "06415", nis: "06415", name: "ANJELITA VERONICA TAMARA", gender: "P", className: "9 Mataram" },
  { id: "06381", nis: "06381", name: "ARDIANSYAH FAJAR", gender: "L", className: "9 Mataram" },
  { id: "06521", nis: "06521", name: "AUSY REGINA PRAMESTY", gender: "P", className: "9 Mataram" },
  { id: "06417", nis: "06417", name: "AYRINATUL HUSNA", gender: "P", className: "9 Mataram" },
  { id: "06418", nis: "06418", name: "AZMI RAMADHAN", gender: "L", className: "9 Mataram" },
  { id: "06451", nis: "06451", name: "CLARA OLIVIA SALSA BILA", gender: "P", className: "9 Mataram" },
  { id: "06386", nis: "06386", name: "DANI", gender: "L", className: "9 Mataram" },
  { id: "06421", nis: "06421", name: "DIEGO REVAN PUTRA RUDIZTY", gender: "L", className: "9 Mataram" },
  { id: "06454", nis: "06454", name: "DIVO ANDREAS GALANG SAPUTRA", gender: "L", className: "9 Mataram" },
  { id: "06387", nis: "06387", name: "DZAKI AKBAR ALDIANSAH", gender: "L", className: "9 Mataram" },
  { id: "06495", nis: "06495", name: "GADIZ AIRA CANTIKA KIRANA", gender: "P", className: "9 Mataram" },
  { id: "06458", nis: "06458", name: "IBNU ALWAN", gender: "L", className: "9 Mataram" },
  { id: "06430", nis: "06430", name: "IVE JUNIVER", gender: "P", className: "9 Mataram" },
  { id: "06498", nis: "06498", name: "JANABIHAH KATINA", gender: "P", className: "9 Mataram" },
  { id: "06460", nis: "06460", name: "JEVANYA ANASTASYA BLEGUR", gender: "P", className: "9 Mataram", exemptReligious: true },
  { id: "06461", nis: "06461", name: "KAYLA AUDYA PRATIWI", gender: "P", className: "9 Mataram" },
  { id: "06392", nis: "06392", name: "LAILATUL QOMARIYAH", gender: "P", className: "9 Mataram" },
  { id: "06393", nis: "06393", name: "LENY SHALSHA ANABELA", gender: "P", className: "9 Mataram" },
  { id: "06504", nis: "06504", name: "LILIN NUR AGUSTINA", gender: "P", className: "9 Mataram" },
  { id: "06394", nis: "06394", name: "MECCA ASSYIFA SALSABILLA", gender: "P", className: "9 Mataram" },
  { id: "06464", nis: "06464", name: "MELATI NURIN PUTRI PRATAMA", gender: "P", className: "9 Mataram" },
  { id: "06433", nis: "06433", name: "MILADIA FINOLIA", gender: "P", className: "9 Mataram" },
  { id: "06399", nis: "06399", name: "NICKYTA ANABELA AURELIA", gender: "P", className: "9 Mataram" },
  { id: "06470", nis: "06470", name: "NIDA AZIZAH PRIYANA", gender: "P", className: "9 Mataram" },
  { id: "06511", nis: "06511", name: "NUR HADIFAH SEKAR ARUM", gender: "P", className: "9 Mataram" },
  { id: "06472", nis: "06472", name: "RAKA DWI PUTRA", gender: "L", className: "9 Mataram" },
  { id: "06402", nis: "06402", name: "SALSABILLA VERONIKA NANTO", gender: "P", className: "9 Mataram" },
  { id: "06515", nis: "06515", name: "SELY ERIENDITA", gender: "P", className: "9 Mataram" },
  { id: "06404", nis: "06404", name: "SHIVA ABILIA CANTIKA PUTRI", gender: "P", className: "9 Mataram" },
  { id: "06479", nis: "06479", name: "YAHYA DAVID CRESTYAWAN", gender: "L", className: "9 Mataram" },

  // ================= KELAS 9 SINGHASARI (35 Siswa) =================
  { id: "06373", nis: "06373", name: "AFRILIA RISMA PUTRI", gender: "P", className: "9 Singhasari" },
  { id: "06484", nis: "06484", name: "ALDI JEFRI PRAYOGA", gender: "L", className: "9 Singhasari" },
  { id: "06414", nis: "06414", name: "ALEXA HEFFY PRADITA MAULIDA", gender: "P", className: "9 Singhasari" },
  { id: "06447", nis: "06447", name: "ANDRO MEGA WIJAYA", gender: "L", className: "9 Singhasari" },
  { id: "156", nis: "156", name: "ANGGA DWI SYAHPUTRA", gender: "L", className: "9 Singhasari" },
  { id: "06379", nis: "06379", name: "ANJANI ULANSARI", gender: "P", className: "9 Singhasari" },
  { id: "06380", nis: "06380", name: "ANNISA NUR ZAIFA AZZAHIRANI", gender: "P", className: "9 Singhasari" },
  { id: "06384", nis: "06384", name: "AZMY KHALILA AZ-ZAHRA", gender: "P", className: "9 Singhasari" },
  { id: "06385", nis: "06385", name: "BIMA JADID WIRATAMA", gender: "L", className: "9 Singhasari" },
  { id: "06453", nis: "06453", name: "DEWI YASMIN HASBILANI KINARA", gender: "P", className: "9 Singhasari" },
  { id: "06420", nis: "06420", name: "DHESIFA ELSA JENNY ZIFARA", gender: "P", className: "9 Singhasari" },
  { id: "06422", nis: "06422", name: "DISTA VIRLY ALICHA", gender: "P", className: "9 Singhasari" },
  { id: "06492", nis: "06492", name: "ENJEL MELINDA ELVI", gender: "P", className: "9 Singhasari" },
  { id: "06424", nis: "06424", name: "FEBRIANI SUSILOWATI", gender: "P", className: "9 Singhasari" },
  { id: "06427", nis: "06427", name: "GRESILA AZAHIRA IASHA CINDY", gender: "P", className: "9 Singhasari" },
  { id: "06388", nis: "06388", name: "HELENA AYUDYA GAYATRI", gender: "P", className: "9 Singhasari" },
  { id: "06389", nis: "06389", name: "ILHAM HIDAYAT", gender: "L", className: "9 Singhasari" },
  { id: "06500", nis: "06500", name: "JESIKA AMELIA", gender: "P", className: "9 Singhasari" },
  { id: "06434", nis: "06434", name: "MOCHAMAD VALENTINO", gender: "L", className: "9 Singhasari" },
  { id: "06395", nis: "06395", name: "MOH ZAINUR CAHYA", gender: "L", className: "9 Singhasari" },
  { id: "06396", nis: "06396", name: "MOHAMMAD RIKO SYAHFANDI", gender: "L", className: "9 Singhasari" },
  { id: "06398", nis: "06398", name: "NESHA FIORENZA ELISYA CLORINDA ZHEVANA", gender: "P", className: "9 Singhasari" },
  { id: "06437", nis: "06437", name: "NUR AZZAM ALMALIQ", gender: "L", className: "9 Singhasari" },
  { id: "06512", nis: "06512", name: "NUR WAHYU SETYAWAN", gender: "L", className: "9 Singhasari" },
  { id: "06471", nis: "06471", name: "PUTRA NANDO SADEWO", gender: "L", className: "9 Singhasari" },
  { id: "06523", nis: "06523", name: "REVAN ANGGI SEVIANA", gender: "P", className: "9 Singhasari" },
  { id: "06473", nis: "06473", name: "REZA ADY RAMANTHA", gender: "L", className: "9 Singhasari" },
  { id: "06401", nis: "06401", name: "RISKA RAHMA DIANA", gender: "P", className: "9 Singhasari" },
  { id: "06475", nis: "06475", name: "SAFIRA AYU PUTRI", gender: "P", className: "9 Singhasari" },
  { id: "06476", nis: "06476", name: "SARAH APRILIA", gender: "P", className: "9 Singhasari" },
  { id: "06403", nis: "06403", name: "SHAFIRA AYU SALSA BELLA", gender: "P", className: "9 Singhasari" },
  { id: "06406_9sing", nis: "06406", name: "SYIFA ROUDHOTUL JANNAH", gender: "P", className: "9 Singhasari" },
  { id: "06481", nis: "06481", name: "YASA ANESTA", gender: "L", className: "9 Singhasari" },
  { id: "06407", nis: "06407", name: "YOHAN FERDIANSYAH", gender: "L", className: "9 Singhasari" },
  { id: "06408", nis: "06408", name: "ZAHRA TALITHA ATHAYA", gender: "P", className: "9 Singhasari" },

  // ================= KELAS 9 SRIWIJAYA (36 Siswa) =================
  { id: "06409", nis: "06409", name: "AFIFAH DWI RAHMAWATI", gender: "P", className: "9 Sriwijaya" },
  { id: "06374", nis: "06374", name: "AIDAN WAJENDRA PUTRA SETIAWAN", gender: "L", className: "9 Sriwijaya" },
  { id: "06412", nis: "06412", name: "AIRA ALZABANI", gender: "P", className: "9 Sriwijaya" },
  { id: "06446", nis: "06446", name: "AISYARANI TALIA TANZILA", gender: "P", className: "9 Sriwijaya" },
  { id: "06375", nis: "06375", name: "ALFIANO RAMADANU", gender: "L", className: "9 Sriwijaya" },
  { id: "06485", nis: "06485", name: "ALVIAN PUTRA MANGGALI", gender: "L", className: "9 Sriwijaya" },
  { id: "06448", nis: "06448", name: "ANISA PUTRI PRIANDINI", gender: "P", className: "9 Sriwijaya" },
  { id: "06416", nis: "06416", name: "ARDINA HUSNIA NAFISA", gender: "P", className: "9 Sriwijaya" },
  { id: "06382", nis: "06382", name: "ARYA FARADILAN SANDI", gender: "L", className: "9 Sriwijaya" },
  { id: "06487", nis: "06487", name: "ASYIFA ALIFATUL RAMADHANI", gender: "P", className: "9 Sriwijaya" },
  { id: "06488", nis: "06488", name: "CARRISA PRISCHILLA RAMADHANI", gender: "P", className: "9 Sriwijaya" },
  { id: "06452", nis: "06452", name: "DEVINA PUTRI BUDI HARTO", gender: "P", className: "9 Sriwijaya" },
  { id: "06493", nis: "06493", name: "ERLINA ROSA ANATASHA ANWARI", gender: "P", className: "9 Sriwijaya" },
  { id: "06423", nis: "06423", name: "FATHIR MAULANA SYAHREZA", gender: "L", className: "9 Sriwijaya" },
  { id: "06494", nis: "06494", name: "FITRAH AGIT FIRMANSYAH", gender: "L", className: "9 Sriwijaya" },
  { id: "06426", nis: "06426", name: "GLEAND VINDO VERDILA", gender: "L", className: "9 Sriwijaya" },
  { id: "06428", nis: "06428", name: "ILYAS EKBAHTIAR DWICAKSONO", gender: "L", className: "9 Sriwijaya" },
  { id: "06459", nis: "06459", name: "IMROATUS SOLIHA", gender: "P", className: "9 Sriwijaya" },
  { id: "06431", nis: "06431", name: "JESYCA VELLYA WATI", gender: "P", className: "9 Sriwijaya" },
  { id: "06501", nis: "06501", name: "JUNIOR ANDIANO PUTRA", gender: "L", className: "9 Sriwijaya" },
  { id: "06462_kesa", nis: "06462", name: "KESA HANA SABRINA", gender: "P", className: "9 Sriwijaya" },
  { id: "06462_keysha", nis: "06462", name: "KEYSHA FIANDRA APRISTA", gender: "P", className: "9 Sriwijaya" },
  { id: "06463", nis: "06463", name: "MAURISTA LOVIANA DARSONO", gender: "P", className: "9 Sriwijaya" },
  { id: "06506", nis: "06506", name: "MIFTAH MAR'ATUSSOLIHA", gender: "P", className: "9 Sriwijaya" },
  { id: "06507", nis: "06507", name: "MIFTHA'UL SYIFA", gender: "P", className: "9 Sriwijaya" },
  { id: "06397", nis: "06397", name: "MUHAMMAD HALILINTAR", gender: "L", className: "9 Sriwijaya" },
  { id: "06508", nis: "06508", name: "MUHAMMAD NABIL LIVIN", gender: "L", className: "9 Sriwijaya" },
  { id: "06467", nis: "06467", name: "NABILA TULZANAH", gender: "P", className: "9 Sriwijaya" },
  { id: "06468", nis: "06468", name: "NADHIRA REZKITA JASMINE", gender: "P", className: "9 Sriwijaya" },
  { id: "06469", nis: "06469", name: "NADYA DESI RAHMAWATI", gender: "P", className: "9 Sriwijaya" },
  { id: "06514", nis: "06514", name: "RAFKA ANANDA YUDHISTIRA", gender: "L", className: "9 Sriwijaya" },
  { id: "06440", nis: "06440", name: "RIZKA DESI HARDIANTI", gender: "P", className: "9 Sriwijaya" },
  { id: "06441", nis: "06441", name: "SALSABILLA AMANDA SAFITRI", gender: "P", className: "9 Sriwijaya" },
  { id: "06444", nis: "06444", name: "ULFATUL CHOIRIYAHSMA MUFIDAH", gender: "P", className: "9 Sriwijaya" },
  { id: "06478", nis: "06478", name: "WIRATAMA ADRIAN ALFATAH", gender: "L", className: "9 Sriwijaya" },
  { id: "06862", nis: "06862", name: "MUHAMMAD SYAHRUN UMAN", gender: "L", className: "9 Sriwijaya" }
];

export const SCHOOL_CLASSES = [
  "7 Kutai",
  "7 Majapahit",
  "7 Mataram",
  "7 Singhasari",
  "7 Sriwijaya",
  "8 Kutai",
  "8 Majapahit",
  "8 Mataram",
  "8 Singhasari",
  "8 Sriwijaya",
  "9 Majapahit",
  "9 Mataram",
  "9 Singhasari",
  "9 Sriwijaya"
];

export const ATTENDANCE_TYPES = [
  { id: "masuk", label: "Absen Masuk", shortLabel: "Masuk", icon: "LogIn", desc: "Senin - Jumat (Maks. 06:45 WIB)" },
  { id: "pulang", label: "Absen Pulang", shortLabel: "Pulang", icon: "LogOut", desc: "Senin - Jumat (Bebas Pukul Pulang)" },
  { id: "dhuhur", label: "Sholat Dhuhur Berjamaah", shortLabel: "Dhuhur", icon: "Sun", desc: "Senin - Kamis (11:50 - 12:30 WIB, Terkunci Total)" },
  { id: "jumat", label: "Sholat Jumat (Laki-laki)", shortLabel: "Jumatan", icon: "Moon", desc: "Khusus Jumat L (11:15 - 12:30 WIB)" },
  { id: "keputrian", label: "Absen Keputrian (Perempuan)", shortLabel: "Keputrian", icon: "HeartHandshake", desc: "Khusus Jumat P (11:15 - 12:30 WIB)" },
] as const;

export type AttendanceType = typeof ATTENDANCE_TYPES[number]['id'];

export interface AttendanceRecord {
  id: string;
  recordId: string;
  studentNis: string;
  studentName: string;
  className: string;
  gender: 'L' | 'P';
  date: string; // YYYY-MM-DD
  type: AttendanceType;
  status: 'hadir' | 'terlambat' | 'izin' | 'sakit' | 'alpa' | 'haid' | 'dikecualikan';
  timestamp: string;
  timeStr: string; // HH:mm:ss
  notes?: string;
  method?: string;
}

export function getScheduleValidity(type: AttendanceType, targetDate?: Date): {
  isValid: boolean;
  dayName: string;
  isWeekend: boolean;
  reason?: string;
  timeStr: string;
} {
  const d = targetDate || new Date();
  const day = d.getDay(); // 0 = Minggu, 1 = Senin, ..., 5 = Jumat, 6 = Sabtu
  const hours = d.getHours();
  const minutes = d.getMinutes();
  const timeStr = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
  const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  const dayName = dayNames[day];
  const isWeekend = day === 0 || day === 6;

  // 1. Libur Akhir Pekan: Sabtu & Minggu siswa libur
  if (isWeekend) {
    return {
      isValid: false,
      dayName,
      isWeekend: true,
      timeStr,
      reason: `Hari ini hari ${dayName} (Siswa Libur Akhir Pekan). Absensi masuk & pulang serta ibadah aktif hari Senin sampai Jumat.`
    };
  }

  // 2. Absen Masuk & Pulang: Senin sampai Jumat
  if (type === 'masuk' || type === 'pulang') {
    return {
      isValid: true,
      dayName,
      isWeekend: false,
      timeStr
    };
  }

  // 3. Sholat Dhuhur Berjamaah: Senin sampai Kamis pukul 11:50 - 12:30 WIB (Terkunci total tanpa menu buka paksa)
  if (type === 'dhuhur') {
    if (day === 5) {
      return {
        isValid: false,
        dayName,
        isWeekend: false,
        timeStr,
        reason: `Hari ini hari Jumat. Presensi Sholat Dhuhur berjamaah diadakan Senin s/d Kamis. Hari Jumat dialihkan ke Sholat Jumat (Laki-laki) dan Keputrian (Perempuan).`
      };
    }
    if (day < 1 || day > 4) {
      return {
        isValid: false,
        dayName,
        isWeekend: false,
        timeStr,
        reason: `Hari ini hari ${dayName}. Presensi Sholat Dhuhur Berjamaah hanya diadakan pada hari Senin sampai Kamis pukul 11:50 - 12:30 WIB.`
      };
    }

    const totalMinutes = hours * 60 + minutes;
    const isWithinDhuhurHours = totalMinutes >= 710 && totalMinutes <= 750;
    if (!isWithinDhuhurHours) {
      return {
        isValid: false,
        dayName,
        isWeekend: false,
        timeStr,
        reason: `Waktu saat ini (${timeStr} WIB). Presensi Sholat Dhuhur Berjamaah HANYA dibuka pada pukul 11:50 - 12:30 WIB. Di luar jam ini siswa tidak bisa absen dan tidak ada menu buka paksa.`
      };
    }

    return {
      isValid: true,
      dayName,
      isWeekend: false,
      timeStr
    };
  }

  // 4. Sholat Jumat (L) & Keputrian (P): Khusus hari Jumat pukul 11:15 - 12:30 WIB
  if (type === 'jumat' || type === 'keputrian') {
    if (day !== 5) {
      return {
        isValid: false,
        dayName,
        isWeekend: false,
        timeStr,
        reason: `Presensi ${type === 'jumat' ? 'Sholat Jumat' : 'Keputrian'} KHUSUS dibuka pada hari JUMAT pukul 11:15 - 12:30 WIB (Hari ini: ${dayName}).`
      };
    }

    const totalMinutes = hours * 60 + minutes;
    const isWithinHours = totalMinutes >= 675 && totalMinutes <= 750;
    if (!isWithinHours) {
      return {
        isValid: false,
        dayName,
        isWeekend: false,
        timeStr,
        reason: `Waktu saat ini (${timeStr} WIB). Presensi ${type === 'jumat' ? 'Sholat Jumat' : 'Keputrian'} HANYA dibuka pada pukul 11:15 - 12:30 WIB.`
      };
    }

    return {
      isValid: true,
      dayName,
      isWeekend: false,
      timeStr
    };
  }

  return { isValid: true, dayName, isWeekend: false, timeStr };
}

// Backward-compatible helper for Friday prayer window
export function isFridayPrayerTimeWindow(targetDate?: Date): {
  isFriday: boolean;
  isWithinHours: boolean;
  isValid: boolean;
  currentDayName: string;
  timeStr: string;
  reason?: string;
} {
  const check = getScheduleValidity('jumat', targetDate);
  const d = targetDate || new Date();
  const day = d.getDay();
  const hours = d.getHours();
  const minutes = d.getMinutes();
  const totalMinutes = hours * 60 + minutes;
  const isWithinHours = totalMinutes >= 675 && totalMinutes <= 750;

  return {
    isFriday: day === 5,
    isWithinHours,
    isValid: check.isValid,
    currentDayName: check.dayName,
    timeStr: check.timeStr,
    reason: check.reason
  };
}

export function isStudentExemptFromReligious(student: Student, type: AttendanceType): boolean {
  if (!student.exemptReligious) return false;
  return type === 'dhuhur' || type === 'jumat' || type === 'keputrian';
}

export function isStudentEligibleForActivity(
  student: Student, 
  type: AttendanceType,
  bypassScheduleCheck = false
): { eligible: boolean; reason?: string } {
  // Special exception: non-Muslim students (Maximilianus, Diva Widiana, Jevanya)
  if (student.exemptReligious && (type === 'dhuhur' || type === 'jumat' || type === 'keputrian')) {
    return {
      eligible: false,
      reason: `${student.name} dikecualikan dari absen ${type === 'jumat' ? 'Sholat Jumat' : type === 'keputrian' ? 'Keputrian' : 'Sholat Dhuhur'} (Hanya terdaftar di Absen Masuk & Pulang).`
    };
  }

  // Operational schedule day validation
  if (type === 'dhuhur') {
    // Sholat Dhuhur: Terkunci total 11:50 - 12:30 WIB Senin s/d Kamis, tidak ada menu buka paksa
    const timeCheck = getScheduleValidity('dhuhur');
    if (!timeCheck.isValid) {
      return {
        eligible: false,
        reason: timeCheck.reason
      };
    }
  } else if (!bypassScheduleCheck) {
    const timeCheck = getScheduleValidity(type);
    if (!timeCheck.isValid) {
      return {
        eligible: false,
        reason: timeCheck.reason
      };
    }
  }

  // Gender check for Friday prayer and Keputrian
  if (type === 'jumat' && student.gender !== 'L') {
    return {
      eligible: false,
      reason: `Sholat Jumat hanya diwajibkan untuk siswa laki-laki (L). Siswi perempuan mengikuti Keputrian.`
    };
  }

  if (type === 'keputrian' && student.gender !== 'P') {
    return {
      eligible: false,
      reason: `Kegiatan Keputrian hanya untuk siswi perempuan (P). Siswa laki-laki mengikuti Sholat Jumat.`
    };
  }

  return { eligible: true };
}
