/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, testFirestoreConnection } from './firebase';
import { Student, AttendanceRecord, INITIAL_STUDENTS } from './data/studentsData';
import { seedStudentsIfEmpty, submitAttendance, getTodayDateStr, syncExemptionsAndCleanup, clearParentPhones } from './services/attendanceService';
import { Navbar } from './components/Navbar';
import { QRScannerTab } from './components/QRScannerTab';
import { StudentQRCardsTab } from './components/StudentQRCardsTab';
import { DashboardTab } from './components/DashboardTab';
import { RekapitulasiTab } from './components/RekapitulasiTab';
import { StudentsListTab } from './components/StudentsListTab';
import { AbsenManualTab } from './components/AbsenManualTab';
import { GoogleAppsScriptTab } from './components/GoogleAppsScriptTab';
import { WhatsAppGatewayTab } from './components/WhatsAppGatewayTab';
import { AndroidInstallModal } from './components/AndroidInstallModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { AppTab } from './components/Navbar';
import { School, Database, Sparkles, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<AppTab>('scan');
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [isConnected, setIsConnected] = useState<boolean>(true);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);
  const [seedSuccessNotice, setSeedSuccessNotice] = useState<string | null>(null);
  const [showInstallModal, setShowInstallModal] = useState<boolean>(false);

  // Initialize Firestore and seed if necessary
  useEffect(() => {
    let unsubscribeStudents: (() => void) | undefined;
    let unsubscribeAttendance: (() => void) | undefined;

    const init = async () => {
      try {
        await testFirestoreConnection();
        setIsConnected(true);

        // Clean up exemptions & sync Maximilianus Wahyu Galih Pradana
        syncExemptionsAndCleanup().catch(console.error);

        // Seed initial students into Firestore if empty
        seedStudentsIfEmpty().then((count) => {
          if (count > 0) {
            console.log(`Synced ${count} students to Firestore.`);
          }
        }).catch(console.error);

        // Real-time listener for students
        const studentsPath = 'students';
        unsubscribeStudents = onSnapshot(
          collection(db, studentsPath),
          (snapshot) => {
            if (!snapshot.empty) {
              const loaded: Student[] = [];
              snapshot.forEach((doc) => {
                const data = doc.data();
                const fallback = INITIAL_STUDENTS.find(s => s.id === doc.id || s.nis === data.nis);
                const nis = String(data.nis || fallback?.nis || doc.id);
                const name = String(data.name || fallback?.name || `Siswa ${doc.id}`);
                const gender = (data.gender || fallback?.gender || 'L') as 'L' | 'P';
                const className = String(data.className || fallback?.className || '7 Kutai');
                const exempt = Boolean(data.exemptReligious ?? fallback?.exemptReligious);
                const parentPhone = data.parentPhone ? String(data.parentPhone).trim() : (fallback?.parentPhone || undefined);

                loaded.push({
                  id: doc.id,
                  nis,
                  name,
                  gender,
                  className,
                  exemptReligious: exempt,
                  parentPhone
                });
              });
              // Sort by class then NIS with safe string fallbacks
              loaded.sort((a, b) => 
                (a.className || '').localeCompare(b.className || '') || 
                (a.nis || '').localeCompare(b.nis || '')
              );
              setStudents(loaded);

              // Auto-clean: Hapus nomor 628139152310 / 82139152310 dari WhatsApp orang tua/wali siswa jika masih ada
              const hasTestPhone = loaded.some(s => s.parentPhone && (s.parentPhone.includes('8139152310') || s.parentPhone.includes('82139152310')));
              if (hasTestPhone) {
                clearParentPhones('628139152310').catch(console.warn);
              }
            }
          },
          (error) => {
            try {
              handleFirestoreError(error, OperationType.GET, studentsPath);
            } catch (err) {
              console.warn("Student listener notice:", err);
            }
          }
        );

        // Real-time listener for attendance records
        const attendancePath = 'attendance';
        unsubscribeAttendance = onSnapshot(
          collection(db, attendancePath),
          (snapshot) => {
            const loadedRecords: AttendanceRecord[] = [];
            snapshot.forEach((doc) => {
              const data = doc.data() as AttendanceRecord;
              loadedRecords.push({
                ...data,
                id: doc.id
              });
            });
            setRecords(loadedRecords);
            setIsInitializing(false);
          },
          (error) => {
            try {
              handleFirestoreError(error, OperationType.GET, attendancePath);
            } catch (err) {
              console.warn("Attendance listener notice:", err);
            }
            setIsInitializing(false);
          }
        );
      } catch (err) {
        console.error("Firebase init error:", err);
        setIsConnected(false);
        setIsInitializing(false);
      }
    };

    init();

    return () => {
      if (unsubscribeStudents) unsubscribeStudents();
      if (unsubscribeAttendance) unsubscribeAttendance();
    };
  }, []);

  const todayStr = getTodayDateStr();
  const todayRecords = records.filter(r => r.date === todayStr);

  // Helper to generate a realistic sample day for testing if empty
  const handleSeedSampleAttendance = async () => {
    if (!confirm("Buat data simulasi kehadiran hari ini untuk menguji grafik & rekapitulasi?")) return;
    setSeedSuccessNotice("Sedang mengisi data simulasi kehadiran...");
    try {
      // Pick random 85% of students to simulate arrival
      const studentsToAttend = students.slice(0, 150);
      for (const st of studentsToAttend) {
        const isLate = Math.random() < 0.12;
        await submitAttendance({
          student: st,
          type: 'masuk',
          overrideStatus: isLate ? 'terlambat' : 'hadir',
          method: 'SIMULASI_DEMO'
        });

        // Also some for dhuhur if eligible
        if (!st.exemptReligious && Math.random() < 0.8) {
          await submitAttendance({
            student: st,
            type: 'dhuhur',
            overrideStatus: 'hadir',
            method: 'SIMULASI_DEMO'
          });
        }
      }
      setSeedSuccessNotice("Berhasil membuat data simulasi kehadiran hari ini!");
      setTimeout(() => setSeedSuccessNotice(null), 4000);
    } catch (err) {
      console.error(err);
      setSeedSuccessNotice("Gagal membuat data simulasi.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isConnected={isConnected}
        totalStudents={students.length}
        todayRecordsCount={todayRecords.length}
        onOpenInstallModal={() => setShowInstallModal(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {seedSuccessNotice && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs font-bold flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{seedSuccessNotice}</span>
            </div>
            <button 
              onClick={() => setSeedSuccessNotice(null)} 
              className="text-xs hover:underline cursor-pointer"
            >
              Tutup
            </button>
          </div>
        )}

        {isInitializing ? (
          <div className="p-16 text-center bg-white rounded-3xl border border-slate-200 shadow-sm max-w-md mx-auto my-12">
            <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <h3 className="text-base font-bold text-slate-800">Menghubungkan ke Firebase Firestore...</h3>
            <p className="text-xs text-slate-500 mt-1">
              Memuat data presensi dan master data 479 siswa SMP Negeri 1 Kalipare
            </p>
          </div>
        ) : (
          <>
            {activeTab === 'scan' && (
              <QRScannerTab
                students={students}
                records={records}
                onRecordAdded={() => {}}
              />
            )}

            {activeTab === 'manual' && (
              <AbsenManualTab
                students={students}
                records={records}
                onAttendanceSaved={() => {}}
              />
            )}

            {activeTab === 'cards' && (
              <StudentQRCardsTab students={students} />
            )}

            {activeTab === 'dashboard' && (
              <DashboardTab
                students={students}
                records={records}
              />
            )}

            {activeTab === 'rekap' && (
              <RekapitulasiTab
                students={students}
                records={records}
              />
            )}

            {activeTab === 'gas' && (
              <GoogleAppsScriptTab students={students} />
            )}

            {activeTab === 'whatsapp' && (
              <WhatsAppGatewayTab students={students} records={records} />
            )}

            {activeTab === 'students' && (
              <StudentsListTab students={students} />
            )}
          </>
        )}
      </main>

      {/* Quick Simulation Banner (for convenience when testing empty days) */}
      {!isInitializing && todayRecords.length === 0 && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full mb-6 print:hidden">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200/80 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-blue-900 shadow-xs">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-5 h-5 text-amber-500 shrink-0" />
              <div>
                <span className="font-bold">Presensi Hari Ini Masih Kosong:</span> Anda dapat memindai kartu QR siswa secara langsung menggunakan kamera, atau klik tombol simulasi berikut untuk menguji tampilan dashboard dan unduh rekapitulasi.
              </div>
            </div>
            <button
              onClick={handleSeedSampleAttendance}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs transition-colors whitespace-nowrap cursor-pointer shrink-0"
            >
              Simulasi Presensi Hari Ini
            </button>
          </div>
        </div>
      )}

      {/* School Footer */}
      <footer className="print:hidden bg-white border-t border-slate-200 py-6 text-slate-500 text-xs mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <School className="w-4 h-4 text-blue-900" />
            <span className="font-bold text-slate-800">SMP NEGERI 1 KALIPARE</span>
            <span>&bull;</span>
            <span>Kabupaten Malang, Jawa Timur</span>
          </div>
          <div className="flex items-center gap-2 text-slate-400">
            <span>Sistem Presensi QR Code &bull; Terhubung ke Firebase Firestore</span>
          </div>
        </div>
      </footer>

      {/* Android Install & APK Modal */}
      <AndroidInstallModal
        isOpen={showInstallModal}
        onClose={() => setShowInstallModal(false)}
      />

      {/* PWA Offline Indicator */}
      <OfflineIndicator />
    </div>
  );
}
