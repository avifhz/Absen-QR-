import {
  collection,
  doc,
  setDoc,
  getDocs,
  onSnapshot,
  query,
  where,
  deleteDoc,
  writeBatch,
  runTransaction
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { 
  Student, 
  INITIAL_STUDENTS, 
  AttendanceRecord, 
  AttendanceType,
  isStudentEligibleForActivity 
} from '../data/studentsData';

export interface AttendanceStats {
  totalStudents: number;
  masukHadir: number;
  masukTerlambat: number;
  pulangHadir: number;
  dhuhurHadir: number;
  jumatHadir: number;
  keputrianHadir: number;
  izinSakitAlpa: number;
}

export function getTodayDateStr(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getCurrentTimeStr(): string {
  const now = new Date();
  return now.toTimeString().split(' ')[0]; // HH:mm:ss
}

// Format date into Indonesian standard format: "Senin, 17 November 2026"
export function formatIndoDate(dateStr: string): string {
  try {
    const [year, month, day] = dateStr.split('-').map(Number);
    const d = new Date(year, month - 1, day);
    return d.toLocaleDateString('id-ID', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  } catch {
    return dateStr;
  }
}

// Sync/Seed students from initial dataset to Firestore
export async function seedStudentsIfEmpty(): Promise<number> {
  const studentsColPath = 'students';
  try {
    const snapshot = await getDocs(collection(db, studentsColPath));
    if (snapshot.size >= 400) {
      return snapshot.size;
    }

    // Batch seed in chunks of 450 (Firestore limit is 500 per batch)
    const chunkSize = 400;
    for (let i = 0; i < INITIAL_STUDENTS.length; i += chunkSize) {
      const batch = writeBatch(db);
      const chunk = INITIAL_STUDENTS.slice(i, i + chunkSize);
      for (const st of chunk) {
        const ref = doc(db, studentsColPath, st.id);
        batch.set(ref, {
          nis: st.nis,
          name: st.name,
          gender: st.gender,
          className: st.className,
          exemptReligious: Boolean(st.exemptReligious),
          createdAt: new Date().toISOString()
        }, { merge: true });
      }
      await batch.commit();
    }
    return INITIAL_STUDENTS.length;
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.WRITE, studentsColPath);
    } catch (e) {
      console.warn("Firestore seed notice:", e);
    }
    return 0;
  }
}

// Record student attendance (Multi-HP atomic transaction safe)
export async function submitAttendance({
  student,
  type,
  overrideStatus,
  notes,
  method = 'QR_SCAN',
  dateOverride,
  bypassScheduleCheck = false
}: {
  student: Student;
  type: AttendanceType;
  overrideStatus?: 'hadir' | 'terlambat' | 'izin' | 'sakit' | 'alpa' | 'haid';
  notes?: string;
  method?: string;
  dateOverride?: string;
  bypassScheduleCheck?: boolean;
}): Promise<{ success: boolean; alreadyExists?: boolean; message: string; record?: AttendanceRecord }> {
  // Check religious exemption and eligibility
  const check = isStudentEligibleForActivity(student, type, bypassScheduleCheck);
  if (!check.eligible) {
    return {
      success: false,
      message: check.reason || 'Siswa tidak memenuhi kriteria untuk absensi ini.'
    };
  }

  const date = dateOverride || getTodayDateStr();
  const timeStr = getCurrentTimeStr();
  const timestamp = new Date().toISOString();
  const recordId = `${student.id}_${date}_${type}`;

  // Auto calculate status if not explicitly overridden
  let status: 'hadir' | 'terlambat' | 'izin' | 'sakit' | 'alpa' | 'haid' | 'dikecualikan' = overrideStatus || 'hadir';
  if (!overrideStatus) {
    if (type === 'masuk') {
      // Batas 06:45 WIB: scan melebihi 06:45 otomatis terdata terlambat
      const [hours, minutes] = timeStr.split(':').map(Number);
      if (hours > 6 || (hours === 6 && minutes > 45)) {
        status = 'terlambat';
      } else {
        status = 'hadir';
      }
    }
  }

  const record: AttendanceRecord = {
    id: recordId,
    recordId,
    studentNis: student.nis,
    studentName: student.name,
    className: student.className,
    gender: student.gender,
    date,
    type,
    status,
    timestamp,
    timeStr,
    notes: notes || '',
    method
  };

  const attendancePath = 'attendance';
  try {
    const docRef = doc(db, attendancePath, recordId);

    // If normal QR scan (no explicit status override), use atomic transaction
    // so concurrent scans from multiple teachers' phones never overwrite each other
    if (!overrideStatus) {
      try {
        const txResult = await runTransaction(db, async (tx) => {
          const existingSnap = await tx.get(docRef);
          if (existingSnap.exists()) {
            return {
              alreadyExists: true,
              existing: existingSnap.data() as AttendanceRecord
            };
          }
          tx.set(docRef, record, { merge: true });
          return {
            alreadyExists: false,
            existing: record
          };
        });

        if (txResult.alreadyExists) {
          return {
            success: false,
            alreadyExists: true,
            message: `${student.name} SUDAH ABSEN ${type.toUpperCase()} oleh perangkat guru lain pada pukul ${txResult.existing.timeStr} WIB (${txResult.existing.status.toUpperCase()}).`,
            record: txResult.existing
          };
        }

        return {
          success: true,
          message: `Presensi ${type.toUpperCase()} berhasil untuk ${student.name} (${status.toUpperCase()})`,
          record
        };
      } catch (txErr: unknown) {
        // Fallback to offline-capable queued setDoc if client is temporarily offline
        const errObj = txErr as { code?: string; message?: string };
        const msg = String(errObj?.code || errObj?.message || '').toLowerCase();
        if (msg.includes('unavailable') || msg.includes('offline') || (typeof navigator !== 'undefined' && !navigator.onLine)) {
          await setDoc(docRef, record, { merge: true });
          return {
            success: true,
            message: `Presensi ${type.toUpperCase()} tersimpan di antrean offline untuk ${student.name} (${status.toUpperCase()})`,
            record
          };
        }
        throw txErr;
      }
    }

    await setDoc(docRef, record, { merge: true });
    return {
      success: true,
      message: `Presensi ${type.toUpperCase()} berhasil untuk ${student.name} (${status.toUpperCase()})`,
      record
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, attendancePath);
    return {
      success: false,
      message: 'Gagal menyimpan absensi ke Firestore.'
    };
  }
}

// Delete attendance record
export async function deleteAttendanceRecord(recordId: string): Promise<boolean> {
  const path = 'attendance';
  try {
    await deleteDoc(doc(db, path, recordId));
    return true;
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
    return false;
  }
}

// Clean up religious attendance for non-Muslim students (Maximilianus, Jevanya, Diva)
export async function syncExemptionsAndCleanup(): Promise<void> {
  try {
    const exemptNisList = ['06708', '06861', '06460'];

    // 1. Ensure student docs in Firestore have full data and exemptReligious: true
    for (const nis of exemptNisList) {
      const studentData = INITIAL_STUDENTS.find(s => s.nis === nis);
      const studentRef = doc(db, 'students', nis);
      if (studentData) {
        await setDoc(studentRef, {
          nis: studentData.nis,
          name: studentData.name,
          gender: studentData.gender,
          className: studentData.className,
          exemptReligious: true
        }, { merge: true });
      } else {
        await setDoc(studentRef, {
          exemptReligious: true
        }, { merge: true });
      }
    }

    // 2. Query and delete any existing religious records for exempt students
    const attCol = collection(db, 'attendance');
    for (const nis of exemptNisList) {
      const q = query(attCol, where('studentNis', '==', nis));
      const snapshot = await getDocs(q);
      for (const d of snapshot.docs) {
        const data = d.data();
        if (data.type === 'dhuhur' || data.type === 'jumat' || data.type === 'keputrian') {
          await deleteDoc(d.ref);
        }
      }
    }
  } catch (err) {
    console.warn("syncExemptionsAndCleanup notice:", err);
  }
}

// Update student's parent WhatsApp phone number in Firestore
export async function updateStudentParentPhone(studentId: string, parentPhone: string): Promise<boolean> {
  const cleanPhone = parentPhone.trim();
  const studentsColPath = 'students';
  try {
    const ref = doc(db, studentsColPath, studentId);
    await setDoc(ref, { parentPhone: cleanPhone }, { merge: true });
    return true;
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.UPDATE, studentsColPath);
    } catch (e) {
      console.error("Failed to update parent phone:", e);
    }
    return false;
  }
}

// Bulk update parent phone numbers for easy testing
export async function bulkUpdateParentPhones(phone: string, className?: string): Promise<number> {
  const clean = phone.trim();
  const studentsColPath = 'students';
  try {
    const snapshot = await getDocs(collection(db, studentsColPath));
    let batch = writeBatch(db);
    let batchCount = 0;
    let totalUpdated = 0;

    for (const d of snapshot.docs) {
      const data = d.data();
      if (!className || className === 'ALL' || data.className === className) {
        batch.update(d.ref, { parentPhone: clean });
        batchCount++;
        totalUpdated++;
        if (batchCount >= 450) {
          await batch.commit();
          batch = writeBatch(db);
          batchCount = 0;
        }
      }
    }
    if (batchCount > 0) {
      await batch.commit();
    }
    return totalUpdated;
  } catch (err) {
    console.error("bulkUpdateParentPhones error:", err);
    return 0;
  }
}

// Clear parent phone numbers from students in Firestore (e.g. to remove test numbers)
export async function clearParentPhones(targetNumber?: string): Promise<number> {
  const studentsColPath = 'students';
  try {
    const snapshot = await getDocs(collection(db, studentsColPath));
    const targetClean = targetNumber ? targetNumber.replace(/\D/g, '') : '';
    let totalUpdated = 0;
    let batch = writeBatch(db);
    let batchCount = 0;

    for (const d of snapshot.docs) {
      const data = d.data();
      if (data.parentPhone && String(data.parentPhone).trim().length > 0) {
        const existingClean = String(data.parentPhone).replace(/\D/g, '');
        // Clear if target matches or contains user's numbers (8139152310 / 82139152310) or targetClean
        const shouldClear = !targetClean || 
          existingClean.includes('8139152310') || 
          existingClean.includes('82139152310') ||
          existingClean === targetClean;

        if (shouldClear) {
          batch.update(d.ref, { parentPhone: '' });
          batchCount++;
          totalUpdated++;

          if (batchCount >= 450) {
            await batch.commit();
            batch = writeBatch(db);
            batchCount = 0;
          }
        }
      }
    }

    if (batchCount > 0) {
      await batch.commit();
    }
    return totalUpdated;
  } catch (err) {
    console.error("clearParentPhones error:", err);
    return 0;
  }
}
