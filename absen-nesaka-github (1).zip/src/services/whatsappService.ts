import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { AttendanceRecord, Student } from '../data/studentsData';

export type WhatsAppProvider = 'fonnte' | 'wablas' | 'custom' | 'wame';

export interface WhatsAppConfig {
  enabled: boolean;
  autoSendOnScan: boolean;
  provider: WhatsAppProvider;
  apiKey: string; // Fonnte token (diambil dari FONNTE_TOKEN server atau input guru)
  senderNumber: string;

  // Nomor WhatsApp Guru & Notifikasi Guru (Sesuai spesifikasi prompt)
  teacherPhone: string;
  teacherNotificationEnabled: boolean;
  notifyParentEnabled: boolean;

  fallbackPhone?: string; // Nomor uji coba cadangan
  autoOpenIfNoGateway?: boolean;
  customEndpoint?: string;

  // Template Pesan
  templateMasuk: string;
  templatePulang: string;
  templateDhuhur: string;
  templateJumat: string;
  templateKeputrian: string;
}

export const DEFAULT_WHATSAPP_CONFIG: WhatsAppConfig = {
  enabled: true,
  autoSendOnScan: true,
  provider: 'fonnte',
  apiKey: '',
  senderNumber: '',
  teacherPhone: '',
  teacherNotificationEnabled: true,
  notifyParentEnabled: true,
  fallbackPhone: '',
  autoOpenIfNoGateway: false,
  customEndpoint: 'https://api.fonnte.com/send',
  templateMasuk: 
`📢 *INFORMASI PRESENSI MASUK - SMPN 1 KALIPARE*

Yth. Bapak/Ibu Wali Murid dari:
👤 *Nama:* {nama}
🏫 *Kelas:* {kelas}
🔢 *NIS:* {nis}
📅 *Tanggal:* {tanggal}
⏰ *Pukul:* {waktu} WIB
📌 *Sesi:* Presensi Masuk Sekolah
📊 *Status:* *{status}*

_Ananda telah hadir di sekolah. Terima kasih atas kerja sama Bapak/Ibu dalam menjaga kedisiplinan belajar ananda._

— *SMP Negeri 1 Kalipare*`,

  templatePulang:
`📢 *INFORMASI PRESENSI PULANG - SMPN 1 KALIPARE*

Yth. Bapak/Ibu Wali Murid dari:
👤 *Nama:* {nama}
🏫 *Kelas:* {kelas}
📅 *Tanggal:* {tanggal}
⏰ *Pukul:* {waktu} WIB
📌 *Sesi:* Presensi Kepulangan Siswa
📊 *Status:* *{status}*

_Ananda telah selesai mengikuti kegiatan belajar di sekolah dan bersiap kembali ke rumah. Semoga selamat sampai tujuan._

— *SMP Negeri 1 Kalipare*`,

  templateDhuhur:
`🕌 *PRESENSI SHOLAT DHUHUR BERJAMAAH - SMPN 1 KALIPARE*

Yth. Bapak/Ibu Wali Murid dari:
👤 *Nama:* {nama}
🏫 *Kelas:* {kelas}
📅 *Tanggal:* {tanggal}
⏰ *Pukul:* {waktu} WIB
📌 *Kegiatan:* Sholat Dhuhur Berjamaah di Masjid Sekolah
✅ *Status:* *{status}*

_Alhamdulillah ananda telah melaksanakan ibadah Sholat Dhuhur Berjamaah bersama guru dan teman-teman._

— *SMP Negeri 1 Kalipare*`,

  templateJumat:
`🕌 *PRESENSI SHOLAT JUMAT BERJAMAAH - SMPN 1 KALIPARE*

Yth. Bapak/Ibu Wali Murid dari:
👤 *Nama:* {nama} (Siswa Putra)
🏫 *Kelas:* {kelas}
📅 *Tanggal:* {tanggal}
⏰ *Pukul:* {waktu} WIB
📌 *Kegiatan:* Sholat Jumat Berjamaah di Masjid Sekolah
✅ *Status:* *{status}*

— *SMP Negeri 1 Kalipare*`,

  templateKeputrian:
`🌸 *PRESENSI KEPUTRIAN HARI JUMAT - SMPN 1 KALIPARE*

Yth. Bapak/Ibu Wali Murid dari:
👤 *Nama:* {nama} (Siswi Putri)
🏫 *Kelas:* {kelas}
📅 *Tanggal:* {tanggal}
⏰ *Pukul:* {waktu} WIB
📌 *Kegiatan:* Bimbingan Ibadah & Keputrian
✅ *Status:* *{status}*

— *SMP Negeri 1 Kalipare*`
};

const STORAGE_KEY = 'nesaka_whatsapp_config';
const LOGS_STORAGE_KEY = 'nesaka_wa_delivery_logs';
const NOTIFICATION_HISTORY_KEY = 'nesaka_wa_sent_attendance_ids';

export interface WhatsAppDeliveryLog {
  id: string;
  timestamp: string;
  studentName: string;
  studentNis: string;
  className: string;
  phone: string;
  type: string;
  recipientRole?: 'guru' | 'wali_murid' | 'uji_coba' | 'rekap';
  status: 'sent' | 'failed' | 'manual_opened';
  message: string;
  responseMsg?: string;
}

export interface FonnteConnectionStatus {
  configured: boolean;
  connected: boolean;
  device_status?: string;
  device?: string;
  name?: string;
  message: string;
  maskedToken?: string;
}

// Format nomor HP ke standar internasional Indonesia (628xxx)
export function sanitizePhoneNumber(phone: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '62' + cleaned.substring(1);
  } else if (cleaned.startsWith('8')) {
    cleaned = '628' + cleaned.substring(1);
  }
  return cleaned;
}

// Memeriksa status koneksi Fonnte secara server-side dengan fallback client-side
export async function checkFonnteStatus(customToken?: string): Promise<FonnteConnectionStatus> {
  const queryParam = customToken && customToken.trim() ? `?token=${encodeURIComponent(customToken.trim())}` : '';

  // 1. Coba periksa via server proxy resmi /api/whatsapp/status
  try {
    const res = await fetch(`/api/whatsapp/status${queryParam}`);
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      const data = await res.json();
      return data;
    }
  } catch (err) {
    console.warn("Pemeriksaan status via server proxy belum siap, mencoba cek langsung ke Fonnte:", err);
  }

  // 2. Fallback: Cek langsung ke API Fonnte jika token tersedia (Fonnte mendukung CORS)
  const token = (customToken || '').trim();
  if (token) {
    try {
      const directRes = await fetch('https://api.fonnte.com/device', {
        method: 'POST',
        headers: { 'Authorization': token }
      });
      const data = await directRes.json().catch(() => ({}));
      if (directRes.ok && data.status === true) {
        const isConnect = String(data.device_status || '').toLowerCase() === 'connect';
        return {
          configured: true,
          connected: isConnect,
          device_status: data.device_status || 'connected',
          device: data.device || '',
          name: data.name || '',
          message: isConnect 
            ? 'Perangkat WhatsApp Guru terhubung & siap kirim.' 
            : 'Perangkat Fonnte terdaftar namun belum terhubung (QR belum di-scan di fonnte.com).',
          maskedToken: token.length > 6 ? `${token.substring(0, 3)}••••••••${token.slice(-3)}` : '••••••'
        };
      } else {
        return {
          configured: true,
          connected: false,
          device_status: 'disconnected',
          message: data.reason || 'Token Fonnte tidak valid atau perangkat terputus.',
          maskedToken: token.length > 6 ? `${token.substring(0, 3)}••••••••${token.slice(-3)}` : '••••••'
        };
      }
    } catch (directErr: any) {
      console.warn("Direct device check notice:", directErr);
    }
  }

  return {
    configured: false,
    connected: false,
    device_status: 'unconfigured',
    message: 'Token Fonnte belum tersambung. Masukkan token Anda pada kolom di bawah lalu klik Simpan Pengaturan.',
    maskedToken: ''
  };
}

// Simpan token ke sisi server
export async function saveFonnteServerToken(token: string): Promise<boolean> {
  try {
    const res = await fetch('/api/whatsapp/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: token.trim() })
    });
    return res.ok;
  } catch {
    return false;
  }
}

// Mekanisme Pencegah Pengiriman Ganda (Idempotency)
export function isAttendanceNotificationSent(recordId: string): boolean {
  try {
    const raw = sessionStorage.getItem(NOTIFICATION_HISTORY_KEY) || localStorage.getItem(NOTIFICATION_HISTORY_KEY);
    if (!raw) return false;
    const ids: string[] = JSON.parse(raw);
    return ids.includes(recordId);
  } catch {
    return false;
  }
}

export function markAttendanceNotificationSent(recordId: string): void {
  try {
    const raw = sessionStorage.getItem(NOTIFICATION_HISTORY_KEY) || localStorage.getItem(NOTIFICATION_HISTORY_KEY);
    let ids: string[] = raw ? JSON.parse(raw) : [];
    if (!ids.includes(recordId)) {
      ids.push(recordId);
      if (ids.length > 500) ids = ids.slice(-500);
      const str = JSON.stringify(ids);
      sessionStorage.setItem(NOTIFICATION_HISTORY_KEY, str);
      localStorage.setItem(NOTIFICATION_HISTORY_KEY, str);
    }
  } catch (err) {
    console.warn("Gagal menyimpan riwayat deduplikasi notifikasi:", err);
  }
}

// Format pesan notifikasi untuk Guru sesuai spesifikasi prompt:
// 📚 ABSENSI SISWA
// SMP NEGERI 1 KALIPARE
// 
// Nama: [Nama Siswa]
// Kelas: [Kelas]
// Tanggal: [Tanggal]
// Jam: [Jam]
// Status: HADIR
// 
// Data berhasil tersimpan dalam database absensi.
export function formatTeacherAttendanceMessage(
  record: AttendanceRecord, 
  student: Student
): string {
  const statusStr = 
    record.status === 'hadir' ? 'HADIR' :
    record.status === 'terlambat' ? 'TERLAMBAT' :
    record.status === 'izin' ? 'IZIN' :
    record.status === 'sakit' ? 'SAKIT' :
    record.status === 'haid' ? 'HAID' :
    record.status === 'alpa' ? 'ALPA' : 'HADIR';

  const jamStr = record.timeStr || new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

  return `📚 ABSENSI SISWA
SMP NEGERI 1 KALIPARE

Nama: ${student.name}
Kelas: ${student.className}
Tanggal: ${record.date}
Jam: ${jamStr}
Status: ${statusStr}

Data berhasil tersimpan dalam database absensi.`;
}

// Format Rekapitulasi Otomatis sesuai spesifikasi prompt:
// - Tanggal absensi
// - Nama kelas
// - Jumlah siswa hadir
// - Jumlah siswa izin
// - Jumlah siswa sakit
// - Jumlah siswa tanpa keterangan
// - Daftar siswa yang belum melakukan absensi
export function formatAttendanceRecapMessage(params: {
  date: string;
  className: string;
  activityType: string;
  totalStudents: number;
  hadirCount: number;
  izinCount: number;
  sakitCount: number;
  alpaCount: number;
  unattendedStudents: { name: string; nis: string }[];
}): string {
  const typeLabel = 
    params.activityType === 'masuk' ? 'Presensi Masuk Sekolah' :
    params.activityType === 'pulang' ? 'Presensi Kepulangan' :
    params.activityType === 'dhuhur' ? 'Sholat Dhuhur Berjamaah' :
    params.activityType === 'jumat' ? 'Sholat Jumat Berjamaah' : 'Bimbingan Keputrian';

  let listUnattended = '';
  if (params.unattendedStudents.length === 0) {
    listUnattended = 'Alhamdulillah semua siswa telah hadir & melakukan absensi.';
  } else {
    listUnattended = params.unattendedStudents
      .slice(0, 35)
      .map((s, idx) => `${idx + 1}. ${s.name} (${s.nis})`)
      .join('\n');
    if (params.unattendedStudents.length > 35) {
      listUnattended += `\n... dan ${params.unattendedStudents.length - 35} siswa lainnya.`;
    }
  }

  return `📊 REKAPITULASI ABSENSI SISWA
SMP NEGERI 1 KALIPARE

📅 Tanggal: ${params.date}
🏫 Kelas: ${params.className}
📌 Sesi: ${typeLabel}

📈 RINGKASAN KEHADIRAN:
- Total Siswa: ${params.totalStudents}
- Hadir: ${params.hadirCount} Siswa
- Izin: ${params.izinCount} Siswa
- Sakit: ${params.sakitCount} Siswa
- Tanpa Keterangan / Belum Absen: ${params.alpaCount} Siswa

📋 DAFTAR SISWA BELUM MELAKUKAN ABSENSI:
${listUnattended}

Data direkap otomatis dari Database Presensi Firebase SMPN 1 Kalipare.`;
}

// Muat konfigurasi dari Firestore atau LocalStorage
export async function loadWhatsAppConfig(): Promise<WhatsAppConfig> {
  try {
    const settingRef = doc(db, 'settings', 'whatsapp');
    const snap = await getDoc(settingRef);
    if (snap.exists()) {
      const data = snap.data() as Partial<WhatsAppConfig>;
      const merged = { ...DEFAULT_WHATSAPP_CONFIG, ...data };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
      return merged;
    }
  } catch (err) {
    console.warn("Tidak dapat membaca config WA dari Firestore, fallback ke local:", err);
  }

  const local = localStorage.getItem(STORAGE_KEY);
  if (local) {
    try {
      return { ...DEFAULT_WHATSAPP_CONFIG, ...JSON.parse(local) };
    } catch {
      // fallback
    }
  }
  return DEFAULT_WHATSAPP_CONFIG;
}

// Simpan konfigurasi ke Firestore dan LocalStorage
export async function saveWhatsAppConfig(config: WhatsAppConfig): Promise<boolean> {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
    const settingRef = doc(db, 'settings', 'whatsapp');
    await setDoc(settingRef, config, { merge: true });

    // Jika ada token yang diisi di UI, sinkronkan ke server-side memory
    if (config.apiKey && config.apiKey.trim()) {
      await saveFonnteServerToken(config.apiKey.trim());
    }

    return true;
  } catch (err) {
    console.error("Gagal menyimpan konfigurasi WhatsApp ke Firestore:", err);
    return false;
  }
}

// Render dynamic tags di template
export function renderWhatsAppMessage(
  template: string,
  record: AttendanceRecord,
  student: Student
): string {
  const statusLabel = 
    record.status === 'hadir' ? 'HADIR (Tepat Waktu)' :
    record.status === 'terlambat' ? 'TERLAMBAT' :
    record.status === 'izin' ? 'IZIN' :
    record.status === 'sakit' ? 'SAKIT' :
    record.status === 'haid' ? 'HAID (Berhalangan Sholat)' :
    record.status === 'alpa' ? 'ALPA (Tanpa Keterangan)' :
    record.status.toUpperCase();

  const typeLabel = 
    record.type === 'masuk' ? 'Presensi Masuk Sekolah' :
    record.type === 'pulang' ? 'Presensi Kepulangan' :
    record.type === 'dhuhur' ? 'Sholat Dhuhur Berjamaah' :
    record.type === 'jumat' ? 'Sholat Jumat Berjamaah' : 'Bimbingan Keputrian';

  return template
    .replace(/\{nama\}/g, student.name)
    .replace(/\{nis\}/g, student.nis)
    .replace(/\{kelas\}/g, student.className)
    .replace(/\{tanggal\}/g, record.date)
    .replace(/\{waktu\}/g, record.timeStr || new Date().toLocaleTimeString('id-ID'))
    .replace(/\{kegiatan\}/g, typeLabel)
    .replace(/\{jenis\}/g, typeLabel)
    .replace(/\{status\}/g, statusLabel)
    .replace(/\{keterangan\}/g, record.notes || '-');
}

// Ambil template berdasarkan sesi absensi
export function getTemplateForType(config: WhatsAppConfig, type: string): string {
  switch (type) {
    case 'masuk': return config.templateMasuk;
    case 'pulang': return config.templatePulang;
    case 'dhuhur': return config.templateDhuhur;
    case 'jumat': return config.templateJumat;
    case 'keputrian': return config.templateKeputrian;
    default: return config.templateMasuk;
  }
}

// Generate wa.me Link
export function generateWaMeLink(phone: string, text: string): string {
  const cleanPhone = sanitizePhoneNumber(phone);
  const encoded = encodeURIComponent(text);
  return `https://wa.me/${cleanPhone}?text=${encoded}`;
}

// Kirim pesan WhatsApp melalui Fonnte Gateway via Server-side Proxy
export async function sendWhatsAppNotification(
  phone: string,
  message: string,
  config?: WhatsAppConfig,
  metadata?: { 
    studentName?: string; 
    studentNis?: string; 
    className?: string; 
    type?: string;
    recipientRole?: 'guru' | 'wali_murid' | 'uji_coba' | 'rekap';
    recordId?: string;
    delay?: string;
  }
): Promise<{ success: boolean; message: string }> {
  const target = sanitizePhoneNumber(phone);
  if (!target || target.length < 9) {
    return { success: false, message: 'Nomor WhatsApp tidak valid atau kosong (contoh: 081234567890).' };
  }

  try {
    let isSuccess = false;
    let resJson: any = {};

    // 1. Kirim melalui server-side proxy resmi /api/whatsapp/send
    try {
      const proxyRes = await fetch('/api/whatsapp/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          target,
          message,
          apiKey: config?.apiKey || undefined,
          recordId: metadata?.recordId,
          delay: metadata?.delay
        })
      });

      const contentType = proxyRes.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        resJson = await proxyRes.json().catch(() => ({}));
        isSuccess = proxyRes.ok && (resJson.status === true || resJson.success === true);
      }
    } catch (proxyErr) {
      console.warn("Proxy send error, mencoba fallback langsung ke API Fonnte:", proxyErr);
    }

    // 2. Fallback kirim langsung ke Fonnte jika server proxy tidak merespon JSON dan token diisi
    if (!isSuccess && config?.apiKey && config.apiKey.trim()) {
      try {
        const formData = new FormData();
        formData.append('target', target);
        formData.append('message', message);
        formData.append('countryCode', '62');
        if (metadata?.delay) {
          formData.append('delay', metadata.delay);
        }

        const directRes = await fetch('https://api.fonnte.com/send', {
          method: 'POST',
          headers: { 'Authorization': config.apiKey.trim() },
          body: formData
        });

        const directData = await directRes.json().catch(() => ({}));
        if (directRes.ok && (directData.status === true || directData.status === 'true' || directData.status === 'success')) {
          isSuccess = true;
          resJson = directData;
        } else if (directData && (directData.reason || directData.message)) {
          resJson = directData;
        }
      } catch (directErr) {
        console.warn("Direct Fonnte send fallback notice:", directErr);
      }
    }

    const resultMessage = isSuccess
      ? (resJson.message || `Notifikasi WhatsApp berhasil dikirim ke nomor ${target}`)
      : (resJson.reason || resJson.message || 'Gagal mengirim melalui Fonnte');

    // Catat riwayat pengiriman
    logWhatsAppDelivery({
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toLocaleString('id-ID'),
      studentName: metadata?.studentName || '-',
      studentNis: metadata?.studentNis || '-',
      className: metadata?.className || '-',
      phone: target,
      type: metadata?.type || 'presensi',
      recipientRole: metadata?.recipientRole || 'guru',
      status: isSuccess ? 'sent' : 'failed',
      message,
      responseMsg: resultMessage
    });

    return {
      success: isSuccess,
      message: resultMessage
    };
  } catch (err: any) {
    const errorMsg = 'Koneksi Fonnte Gateway error: ' + (err.message || String(err));
    logWhatsAppDelivery({
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toLocaleString('id-ID'),
      studentName: metadata?.studentName || '-',
      studentNis: metadata?.studentNis || '-',
      className: metadata?.className || '-',
      phone: target,
      type: metadata?.type || 'presensi',
      recipientRole: metadata?.recipientRole || 'guru',
      status: 'failed',
      message,
      responseMsg: errorMsg
    });

    return { success: false, message: errorMsg };
  }
}

// Log Pengiriman WhatsApp
export function getWhatsAppDeliveryLogs(): WhatsAppDeliveryLog[] {
  try {
    const raw = localStorage.getItem(LOGS_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function logWhatsAppDelivery(entry: WhatsAppDeliveryLog) {
  try {
    const current = getWhatsAppDeliveryLogs();
    const updated = [entry, ...current].slice(0, 100);
    localStorage.setItem(LOGS_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn("Gagal mencatat log pengiriman WA:", err);
  }
}

export function clearWhatsAppDeliveryLogs(): void {
  try {
    localStorage.removeItem(LOGS_STORAGE_KEY);
  } catch {}
}
