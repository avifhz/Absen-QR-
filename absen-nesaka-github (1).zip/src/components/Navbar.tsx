import React, { useState, useEffect } from 'react';
import { 
  QrCode, 
  Scan, 
  BarChart3, 
  FileSpreadsheet, 
  Users, 
  Clock, 
  Database,
  School,
  ClipboardCheck,
  FileCode,
  MessageCircle,
  Smartphone,
  Download,
  FolderArchive,
  Loader2
} from 'lucide-react';

export type AppTab = 'scan' | 'manual' | 'cards' | 'dashboard' | 'rekap' | 'students' | 'gas' | 'whatsapp';

interface NavbarProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  isConnected: boolean;
  totalStudents: number;
  todayRecordsCount: number;
  onOpenInstallModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isConnected,
  totalStudents,
  todayRecordsCount,
  onOpenInstallModal
}) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [dateStr, setDateStr] = useState<string>('');
  const [downloadingZip, setDownloadingZip] = useState<boolean>(false);
  const [zipError, setZipError] = useState<string | null>(null);

  const handleDownloadZip = async () => {
    if (downloadingZip) return;
    setDownloadingZip(true);
    setZipError(null);
    try {
      const urls = [
        `/api/download/github-source.zip?t=${Date.now()}`,
        `/absen-nesaka-github.zip?t=${Date.now()}`
      ];
      let validBlob: Blob | null = null;

      for (const url of urls) {
        const res = await fetch(url, { cache: 'no-store' });
        const contentType = (res.headers.get('content-type') || '').toLowerCase();
        if (res.ok && !contentType.includes('text/html')) {
          const blob = await res.blob();
          const headerBytes = new Uint8Array(await blob.slice(0, 2).arrayBuffer());
          // Verify ZIP magic bytes 'PK' (0x50, 0x4B)
          if (headerBytes.length === 2 && headerBytes[0] === 0x50 && headerBytes[1] === 0x4b) {
            validBlob = blob;
            break;
          }
        }
      }

      if (!validBlob) {
        setZipError('Gagal memverifikasi arsip ZIP.');
        return;
      }

      const objectUrl = URL.createObjectURL(validBlob);
      const link = document.createElement('a');
      link.href = objectUrl;
      link.download = 'absen-nesaka-github.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
    } catch {
      setZipError('Koneksi gagal saat mengunduh ZIP.');
    } finally {
      setDownloadingZip(false);
    }
  };

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('id-ID', { hour12: false }) + ' WIB');
      setDateStr(now.toLocaleDateString('id-ID', { 
        weekday: 'short', 
        day: 'numeric', 
        month: 'short', 
        year: 'numeric' 
      }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  interface NavItem {
    id: AppTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }

  const navItems: NavItem[] = [
    { id: 'scan', label: 'Scan QR Presensi', icon: Scan, badge: todayRecordsCount > 0 ? `${todayRecordsCount} scan` : undefined },
    { id: 'manual', label: 'Absen Manual', icon: ClipboardCheck },
    { id: 'cards', label: 'Cetak Kartu QR', icon: QrCode },
    { id: 'dashboard', label: 'Dashboard Live', icon: BarChart3 },
    { id: 'rekap', label: 'Rekapitulasi & Unduh', icon: FileSpreadsheet },
    { id: 'whatsapp', label: 'Pengaturan WhatsApp', icon: MessageCircle, badge: 'Fonnte' },
    { id: 'gas', label: 'Script Google Sheets', icon: FileCode, badge: 'Code.gs' },
    { id: 'students', label: 'Data Siswa', icon: Users, badge: `${totalStudents}` },
  ];

  return (
    <header className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white shadow-lg sticky top-0 z-40">
      {/* Top Bar with School Info & Real-time Clock */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4 border-b border-blue-800/60">
        <div className="flex items-center space-x-3.5">
          <img 
            src="/assets/aistudio/logo_nesaka-removebg-preview_ee9f6ab8.png" 
            alt="Logo SMP Negeri 1 Kalipare" 
            className="w-14 h-14 sm:w-16 sm:h-16 object-contain shrink-0 drop-shadow-md select-none transition-transform hover:scale-105"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-lg sm:text-xl tracking-tight text-white flex items-center gap-2">
                SMP NEGERI 1 KALIPARE
              </h1>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded text-xs font-semibold bg-blue-700/80 text-blue-100 border border-blue-500/50">
                Kab. Malang
              </span>
            </div>
            <p className="text-xs text-blue-200/90 font-medium">
              Sistem Presensi QR Code Siswa &bull; Masuk, Pulang, Dhuhur, Jumat &amp; Keputrian
            </p>
          </div>
        </div>

        {/* Live Clock, Firebase Status, Unduh APK & Install Modal Button */}
        <div className="flex items-center gap-2 sm:gap-2.5 ml-auto">
          <a
            href="/Absen_Nesaka.apk"
            download="Absen_Nesaka.apk"
            className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white px-3 py-1.5 rounded-lg border border-emerald-400/40 text-xs font-bold shadow-md transition-all cursor-pointer hover:scale-105 active:scale-95 shrink-0"
            title="Download file Absen_Nesaka.apk langsung ke perangkat"
          >
            <Download className="w-3.5 h-3.5 text-white animate-bounce" />
            <span>Unduh .APK</span>
            <span className="hidden sm:inline-block px-1 py-0.2 rounded text-[9px] bg-emerald-800 text-emerald-100 uppercase">2.8MB</span>
          </a>

          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={downloadingZip}
            className="flex items-center gap-1.5 bg-gradient-to-r from-slate-700 to-slate-800 hover:from-slate-600 hover:to-slate-700 disabled:opacity-60 text-white px-3 py-1.5 rounded-lg border border-slate-500/50 text-xs font-bold shadow-md transition-all cursor-pointer hover:scale-105 active:scale-95 shrink-0"
            title={zipError || 'Download paket kode sumber (.ZIP) siap ekstrak & upload ke GitHub'}
          >
            {downloadingZip ? (
              <Loader2 className="w-3.5 h-3.5 text-amber-300 animate-spin" />
            ) : (
              <FolderArchive className="w-3.5 h-3.5 text-amber-300" />
            )}
            <span>{downloadingZip ? 'Mengunduh...' : zipError ? 'Coba Lagi .ZIP' : 'Unduh .ZIP GitHub'}</span>
          </button>

          {onOpenInstallModal && (
            <button
              onClick={onOpenInstallModal}
              className="flex items-center gap-1.5 bg-blue-700 hover:bg-blue-600 text-white px-3 py-1.5 rounded-lg border border-blue-500/50 text-xs font-bold shadow-md transition-all cursor-pointer hover:scale-105 active:scale-95 shrink-0"
              title="Panduan Pasang Aplikasi di HP Android & QR Code"
            >
              <Smartphone className="w-3.5 h-3.5 text-amber-300" />
              <span className="hidden sm:inline">Panduan</span>
              <span>Install</span>
            </button>
          )}

          <div className="hidden md:flex items-center gap-2 bg-blue-950/60 px-3 py-1.5 rounded-lg border border-blue-700/50 text-xs">
            <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
            <span className="text-blue-100 font-medium">{dateStr}</span>
            <span className="text-amber-300 font-mono font-bold">{timeStr}</span>
          </div>

          <div className="flex items-center gap-2 bg-blue-950/70 px-3 py-1.5 rounded-lg border border-blue-700/50">
            <Database className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-xs text-blue-200 hidden sm:inline">Firebase Firestore</span>
            <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1 animate-ping"></span>
              Real-time
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2 no-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-amber-400 text-slate-950 shadow-md font-bold'
                    : 'text-blue-100 hover:bg-blue-800/60 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-blue-300'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`ml-1 px-1.5 py-0.5 rounded-full text-[11px] font-bold ${
                      isActive
                        ? 'bg-slate-900 text-amber-300'
                        : 'bg-blue-800 text-blue-200'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
