import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Download, 
  CheckCircle2, 
  ExternalLink, 
  X, 
  Share2, 
  QrCode, 
  ShieldCheck, 
  Sparkles, 
  HelpCircle,
  Copy,
  Check,
  Layers,
  ArrowRight
} from 'lucide-react';
import QRCode from 'qrcode';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [appUrl, setAppUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [installSuccess, setInstallSuccess] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'install' | 'qrcode' | 'standalone'>('install');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const currentUrl = window.location.origin;
      setAppUrl(currentUrl);

      QRCode.toDataURL(currentUrl, {
        width: 260,
        margin: 2,
        color: {
          dark: '#1e3a8a',
          light: '#ffffff'
        }
      }).then(setQrCodeDataUrl).catch(console.error);
    }
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      setInstallSuccess(true);
    }
  };

  const handleCopyUrl = () => {
    if (appUrl) {
      navigator.clipboard.writeText(appUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const pwabuilderUrl = `https://www.pwabuilder.com?url=${encodeURIComponent(appUrl)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Modal */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white p-6 relative">
          <button 
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white p-2 shadow-lg shrink-0 flex items-center justify-center">
              <img 
                src="/assets/aistudio/logo_nesaka-removebg-preview_ee9f6ab8.png" 
                alt="Logo Nesaka" 
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-400 text-slate-950 flex items-center gap-1">
                  <Smartphone className="w-3.5 h-3.5" />
                  Android APK &amp; PWA
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/30 text-emerald-300 border border-emerald-400/30">
                  Semua Versi Android
                </span>
              </div>
              <h2 className="text-xl font-black text-white mt-1">
                Absen Nesaka SMPN 1 Kalipare
              </h2>
              <p className="text-xs text-blue-200">
                Pasang aplikasi absensi di HP Android guru tanpa batasan versi (Android 5 sampai 15+).
              </p>
            </div>
          </div>

          {/* Sub Navigation */}
          <div className="flex space-x-1 mt-5 bg-white/10 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('install')}
              className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer text-center ${
                activeTab === 'install' 
                  ? 'bg-white text-blue-950 shadow-sm' 
                  : 'text-blue-200 hover:text-white'
              }`}
            >
              1. Pasang di HP
            </button>
            <button
              onClick={() => setActiveTab('qrcode')}
              className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer text-center ${
                activeTab === 'qrcode' 
                  ? 'bg-white text-blue-950 shadow-sm' 
                  : 'text-blue-200 hover:text-white'
              }`}
            >
              2. Scan dari Laptop
            </button>
            <button
              onClick={() => setActiveTab('standalone')}
              className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer text-center ${
                activeTab === 'standalone' 
                  ? 'bg-white text-blue-950 shadow-sm' 
                  : 'text-blue-200 hover:text-white'
              }`}
            >
              3. Paket APK File
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5">
          {/* Tab 1: Pasang & Unduh APK */}
          {activeTab === 'install' && (
            <div className="space-y-4">
              {/* DIRECT APK DOWNLOAD BOX */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 via-teal-50 to-green-50 border-2 border-emerald-300 shadow-sm space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shrink-0">
                      <Download className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-extrabold text-emerald-950">
                          File Absen_Nesaka.apk
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-200 text-emerald-800">
                          2.8 MB
                        </span>
                      </div>
                      <p className="text-xs text-emerald-700">
                        File paket aplikasi Android siap diunduh dan dipasang di HP.
                      </p>
                    </div>
                  </div>
                </div>

                <a
                  href="/Absen_Nesaka.apk"
                  download="Absen_Nesaka.apk"
                  className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer hover:scale-[1.01] active:scale-[0.99]"
                >
                  <Download className="w-4 h-4 animate-bounce" />
                  <span>Unduh File Absen_Nesaka.apk</span>
                </a>

                <div className="text-[11px] text-emerald-800/90 bg-white/70 p-2.5 rounded-xl border border-emerald-200 space-y-1">
                  <span className="font-bold block">💡 Cara Install File APK:</span>
                  <div>1. Ketuk tombol <strong>Unduh File Absen_Nesaka.apk</strong> di atas.</div>
                  <div>2. Buka notifikasi download / folder <strong>Download</strong> di HP Anda.</div>
                  <div>3. Ketuk file <code>Absen_Nesaka.apk</code> lalu pilih <strong>Install</strong>.</div>
                  <div>4. Jika HP meminta konfirmasi, pilih <em>"Tetap Install"</em> atau izinkan dari browser.</div>
                </div>
              </div>

              {/* Notification Banner if already installed */}
              {isInstalled ? (
                <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-blue-900 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-bold">Aplikasi Telah Terpasang di HP Ini!</h4>
                    <p className="text-xs text-blue-700 mt-0.5">
                      Absen Nesaka sudah berjalan sebagai aplikasi Android terpasang. Anda dapat membukanya langsung dari ikon di layar utama HP.
                    </p>
                  </div>
                </div>
              ) : installSuccess ? (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-bold">Instalasi Berhasil Dimulai!</h4>
                    <p className="text-xs text-emerald-700 mt-0.5">
                      Ikon aplikasi <strong>Absen Nesaka</strong> sedang ditambahkan ke layar depan dan daftar aplikasi HP Anda.
                    </p>
                  </div>
                </div>
              ) : isInstallable ? (
                <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 space-y-3">
                  <div className="flex items-start gap-3">
                    <Sparkles className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-bold text-blue-950">
                        Opsi Alternatif: Pasang Cepat 1-Klik (WebAPK)
                      </h4>
                      <p className="text-xs text-blue-700 mt-0.5">
                        Tanpa perlu unduh file 2.8 MB, langsung terpasang di layar utama Android dalam 3 detik tanpa peringatan Play Protect.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handleInstallClick}
                    className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs shadow-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Smartphone className="w-4 h-4" />
                    <span>Pasang Cepat 1-Klik ke HP</span>
                  </button>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-blue-600" />
                    Pasang Cepat Melalui Browser HP
                  </h4>
                  <ol className="text-xs text-slate-600 space-y-2 ml-1">
                    <li className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 font-bold flex items-center justify-center shrink-0 text-[11px]">1</span>
                      <span>Buka web ini di Google Chrome / Browser HP Android Anda.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 font-bold flex items-center justify-center shrink-0 text-[11px]">2</span>
                      <span>Ketuk tanda <strong>Titik Tiga (⋮)</strong> di pojok kanan atas browser.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 font-bold flex items-center justify-center shrink-0 text-[11px]">3</span>
                      <span>Pilih <strong>"Pasang Aplikasi" (Install App)</strong> atau <strong>"Tambahkan ke Layar Utama"</strong>.</span>
                    </li>
                  </ol>
                </div>
              )}

              {/* iOS Guide if on Apple device */}
              {isIOS && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-950">
                  <h4 className="text-xs font-bold flex items-center gap-2">
                    <Share2 className="w-4 h-4 text-amber-700" />
                    Untuk Pengguna iPhone / iPad:
                  </h4>
                  <p className="text-xs text-amber-800 mt-1">
                    Buka di Safari &rarr; Ketuk tombol <strong>Share</strong> (kotak panah ke atas) &rarr; Gulir ke bawah dan pilih <strong>"Add to Home Screen"</strong>.
                  </p>
                </div>
              )}

              {/* Features of Android Version */}
              <div className="grid grid-cols-2 gap-2.5 pt-2">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-[11px] font-bold text-slate-700">Aman &amp; Tanpa Play Protect Error</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="text-[11px] font-bold text-slate-700">Scan QR Kamera Cepat &amp; Stabil</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2.5">
                  <Layers className="w-4 h-4 text-blue-600 shrink-0" />
                  <span className="text-[11px] font-bold text-slate-700">Ukuran Ringan (&lt; 2 MB)</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                  <span className="text-[11px] font-bold text-slate-700">Update Otomatis Saat Dibuka</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'qrcode' && (
            <div className="text-center space-y-4">
              <p className="text-xs text-slate-600">
                Arahkan kamera HP Android Anda ke QR Code di bawah untuk langsung membuka &amp; memasang aplikasi di HP:
              </p>
              
              <div className="inline-block p-4 bg-white rounded-2xl border-2 border-dashed border-blue-300 shadow-inner">
                {qrCodeDataUrl ? (
                  <img 
                    src={qrCodeDataUrl} 
                    alt="QR Code Buka Aplikasi di HP" 
                    className="w-52 h-52 mx-auto rounded-xl"
                  />
                ) : (
                  <div className="w-52 h-52 flex items-center justify-center bg-slate-100 rounded-xl">
                    <QrCode className="w-12 h-12 text-slate-400 animate-pulse" />
                  </div>
                )}
              </div>

              {/* URL & Copy button */}
              <div className="flex items-center gap-2 max-w-md mx-auto">
                <input 
                  type="text" 
                  readOnly 
                  value={appUrl} 
                  className="flex-1 px-3 py-2 text-xs bg-slate-100 border border-slate-200 rounded-xl text-slate-700 font-mono truncate"
                />
                <button
                  onClick={handleCopyUrl}
                  className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Tersalin' : 'Salin URL'}</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'standalone' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200">
                <h4 className="text-xs font-bold text-indigo-950 flex items-center gap-2 mb-1">
                  <Download className="w-4 h-4 text-indigo-600" />
                  Generate File .APK / .AAB Standalone (PWABuilder)
                </h4>
                <p className="text-xs text-indigo-800 leading-relaxed">
                  Aplikasi ini telah memenuhi seluruh standar <strong>Google WebAPK &amp; Trusted Web Activity (TWA)</strong> resmi. Anda dapat mengunduh paket binary <code>.apk</code> mandiri untuk didistribusikan lewat WhatsApp atau diunggah ke Google Play Store melalui PWABuilder.
                </p>
              </div>

              <div className="space-y-2">
                <a
                  href={pwabuilderUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs shadow-md flex items-center justify-center gap-2 transition-all"
                >
                  <span>Buka PWABuilder untuk Download .APK</span>
                  <ExternalLink className="w-4 h-4" />
                </a>

                <p className="text-[11px] text-slate-500 text-center">
                  Cukup klik <strong>"Package for Stores" &rarr; "Android"</strong> di PWABuilder untuk menghasilkan file <code>Absen_Nesaka.apk</code> siap install.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="font-bold text-slate-800">Spesifikasi Paket Android:</div>
                <ul className="text-slate-600 space-y-1 text-[11px]">
                  <li>&bull; <strong>Nama Aplikasi:</strong> Absen Nesaka SMPN 1 Kalipare</li>
                  <li>&bull; <strong>Package ID:</strong> <code>id.sch.smpn1kalipare.absen</code></li>
                  <li>&bull; <strong>Versi Target:</strong> Android 5.0 (Lollipop) hingga Android 15+</li>
                  <li>&bull; <strong>Izin Diperlukan:</strong> Kamera (untuk Scanner QR Code)</li>
                  <li>&bull; <strong>Database:</strong> Firebase Firestore Cloud Sync</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Footer Modal */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 flex items-center justify-between">
          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Versi Mobile 2.0 (Android WebAPK Ready)</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
