import React, { useState, useEffect, useRef } from 'react';
import { 
  Camera, 
  CameraOff, 
  Search, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  User, 
  Volume2, 
  VolumeX, 
  Sparkles,
  ArrowRight,
  ShieldAlert,
  LogIn,
  LogOut,
  Sun,
  Moon,
  HeartHandshake,
  Trash2,
  Lock,
  Unlock,
  Radio,
  Usb,
  Upload,
  MessageCircle,
  Phone,
  Smartphone,
  Zap
} from 'lucide-react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import confetti from 'canvas-confetti';
import { 
  Student, 
  AttendanceRecord, 
  AttendanceType, 
  ATTENDANCE_TYPES,
  isStudentEligibleForActivity,
  isFridayPrayerTimeWindow,
  getScheduleValidity
} from '../data/studentsData';
import { submitAttendance, deleteAttendanceRecord, getTodayDateStr, updateStudentParentPhone } from '../services/attendanceService';
import { playChimeSound } from '../utils/audio';
import { 
  loadWhatsAppConfig, 
  saveWhatsAppConfig,
  sendWhatsAppNotification, 
  generateWaMeLink, 
  renderWhatsAppMessage, 
  getTemplateForType, 
  WhatsAppConfig, 
  DEFAULT_WHATSAPP_CONFIG,
  formatTeacherAttendanceMessage,
  isAttendanceNotificationSent,
  markAttendanceNotificationSent
} from '../services/whatsappService';

interface QRScannerTabProps {
  students: Student[];
  records: AttendanceRecord[];
  onRecordAdded?: () => void;
}

export const QRScannerTab: React.FC<QRScannerTabProps> = ({
  students,
  records,
  onRecordAdded
}) => {
  const [selectedType, setSelectedType] = useState<AttendanceType>('masuk');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scannerError, setScannerError] = useState<string | null>(null);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [allowScheduleOverride, setAllowScheduleOverride] = useState<boolean>(false);
  const allowFridayOverride = allowScheduleOverride;
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [matchedStudents, setMatchedStudents] = useState<Student[]>([]);
  const [selectedStudentForManual, setSelectedStudentForManual] = useState<Student | null>(null);
  const [manualStatus, setManualStatus] = useState<'hadir' | 'terlambat' | 'izin' | 'sakit' | 'alpa' | 'haid'>('hadir');
  const [manualNotes, setManualNotes] = useState<string>('');
  const [dhuhurFemaleMode, setDhuhurFemaleMode] = useState<'hadir' | 'haid'>('hadir');
  const [usbScannerNotice, setUsbScannerNotice] = useState<string | null>(null);
  const [waConfig, setWaConfig] = useState<WhatsAppConfig>(DEFAULT_WHATSAPP_CONFIG);
  const [hasServerToken, setHasServerToken] = useState<boolean>(false);
  const [quickPhoneInput, setQuickPhoneInput] = useState<string>('');
  const [quickTokenInput, setQuickTokenInput] = useState<string>('');
  const [isSavingPhone, setIsSavingPhone] = useState<boolean>(false);
  const [deviceScanCount, setDeviceScanCount] = useState<number>(0);

  useEffect(() => {
    loadWhatsAppConfig().then(setWaConfig).catch(console.warn);
    fetch('/api/whatsapp/config')
      .then(res => res.json())
      .then(data => {
        if (data && data.hasToken) setHasServerToken(true);
      })
      .catch(() => {});
  }, []);

  // Hardware USB RFID / Barcode Scanner Buffer
  const barcodeBufferRef = useRef<string>('');
  const lastKeyTimeRef = useRef<number>(0);

  // Flash result feedback card
  const [lastScanResult, setLastScanResult] = useState<{
    status: 'success' | 'warning' | 'error';
    student?: Student;
    message: string;
    record?: AttendanceRecord;
    waSentNotice?: string;
  } | null>(null);

  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const isProcessingRef = useRef<boolean>(false);
  const lastScannedRef = useRef<{ code: string; time: number }>({ code: '', time: 0 });
  const processDecodedTextRef = useRef<(text: string, scanMethod?: string) => Promise<void>>(async () => {});

  // Global listener for USB Barcode / 2D QR Scanner gun & USB RFID Reader (HID keyboard devices)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing normally in a textarea or text input
      const target = e.target as HTMLElement;
      const isInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA';

      const now = Date.now();
      const diff = now - lastKeyTimeRef.current;
      lastKeyTimeRef.current = now;

      if (e.key === 'Enter') {
        if (barcodeBufferRef.current.length >= 3) {
          const scanned = barcodeBufferRef.current.trim();
          barcodeBufferRef.current = '';
          setUsbScannerNotice(`Data diterima dari Alat Scanner PC: ${scanned}`);
          setTimeout(() => setUsbScannerNotice(null), 3000);
          processDecodedTextRef.current(scanned, 'USB_RFID_SCANNER');
          if (!isInput) e.preventDefault();
        }
        barcodeBufferRef.current = '';
        return;
      }

      // Scanner sends keystrokes with very small delay (< 60ms)
      if (e.key.length === 1) {
        if (diff > 250 && isInput) {
          barcodeBufferRef.current = e.key;
        } else {
          barcodeBufferRef.current += e.key;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filter students for manual search
  useEffect(() => {
    if (!searchQuery.trim()) {
      setMatchedStudents([]);
      return;
    }
    const q = searchQuery.toLowerCase().trim();
    const matches = students.filter(s => 
      s.nis.toLowerCase().includes(q) || 
      s.name.toLowerCase().includes(q) ||
      s.className.toLowerCase().includes(q)
    ).slice(0, 8);
    setMatchedStudents(matches);
  }, [searchQuery, students]);

  // Clean up scanner on unmount
  useEffect(() => {
    return () => {
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        html5QrCodeRef.current.stop().catch(console.error);
      }
    };
  }, []);

  const handleStartScanner = async () => {
    setScannerError(null);

    // If dhuhur is outside hours, do not allow start
    if (selectedType === 'dhuhur') {
      const dhuhurCheck = getScheduleValidity('dhuhur');
      if (!dhuhurCheck.isValid) {
        setScannerError(dhuhurCheck.reason || 'Presensi Sholat Dhuhur Berjamaah terkunci total di luar pukul 11:50 - 12:30 WIB.');
        return;
      }
    }

    try {
      if (!html5QrCodeRef.current) {
        html5QrCodeRef.current = new Html5Qrcode("qr-reader", {
          formatsToSupport: [
            Html5QrcodeSupportedFormats.QR_CODE,
            Html5QrcodeSupportedFormats.CODE_128,
            Html5QrcodeSupportedFormats.CODE_39,
            Html5QrcodeSupportedFormats.EAN_13,
            Html5QrcodeSupportedFormats.UPC_A,
            Html5QrcodeSupportedFormats.CODABAR,
            Html5QrcodeSupportedFormats.ITF
          ],
          verbose: false
        });
      }

      // Try camera detection on mobile HP
      let cameraConfig: any = { facingMode: { ideal: "environment" } };
      try {
        const cameras = await Html5Qrcode.getCameras();
        if (cameras && cameras.length > 0) {
          // Prefer back/rear camera on mobile
          const backCam = cameras.find(c => 
            c.label.toLowerCase().includes('back') || 
            c.label.toLowerCase().includes('rear') || 
            c.label.toLowerCase().includes('environment') ||
            c.label.toLowerCase().includes('belakang')
          );
          cameraConfig = backCam ? { deviceId: { exact: backCam.id } } : { facingMode: "environment" };
        }
      } catch (camErr) {
        console.warn("Camera enumeration notice:", camErr);
      }

      await html5QrCodeRef.current.start(
        cameraConfig,
        {
          fps: 15,
          qrbox: (viewfinderWidth, viewfinderHeight) => {
            const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
            return {
              width: Math.floor(minEdge * 0.75),
              height: Math.floor(minEdge * 0.75),
            };
          },
          aspectRatio: 1.0,
        },
        async (decodedText) => {
          const now = Date.now();
          const cleanCode = decodedText.trim();
          // Ignore the exact same QR held in front of lens within 3s,
          // while allowing different students to scan rapidly (450ms queue cooldown)
          if (lastScannedRef.current.code === cleanCode && now - lastScannedRef.current.time < 3000) {
            return;
          }
          if (isProcessingRef.current) return;
          isProcessingRef.current = true;
          lastScannedRef.current = { code: cleanCode, time: now };
          try {
            await processDecodedTextRef.current(decodedText);
          } finally {
            setTimeout(() => {
              isProcessingRef.current = false;
            }, 450);
          }
        },
        () => {}
      );
      setIsScanning(true);
    } catch (err: unknown) {
      console.error("Camera start error:", err);
      const errMsg = err instanceof Error ? err.message : String(err);
      setScannerError("Gagal membuka kamera: " + errMsg + ". Pastikan izin kamera telah diizinkan pada browser HP Anda.");
      setIsScanning(false);
    }
  };

  const handleStopScanner = async () => {
    if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
      try {
        await html5QrCodeRef.current.stop();
        setIsScanning(false);
      } catch (err) {
        console.error("Failed to stop scanner", err);
      }
    } else {
      setIsScanning(false);
    }
  };

  const processDecodedText = async (text: string, scanMethod: string = 'QR_SCAN') => {
    const rawVal = text.trim();
    // Student QR may contain NIS directly or JSON: { nis: "06460" } or URL or prefix
    let targetNis = rawVal;
    if (rawVal.startsWith('{') && rawVal.endsWith('}')) {
      try {
        const parsed = JSON.parse(rawVal);
        if (parsed.nis) targetNis = String(parsed.nis);
      } catch {}
    } else if (rawVal.includes(':')) {
      const parts = rawVal.split(':');
      targetNis = parts[parts.length - 1];
    }

    // Find student in master database
    const student = students.find(s => s.nis === targetNis || s.id === targetNis);
    if (!student) {
      if (soundEnabled) playChimeSound('error');
      setLastScanResult({
        status: 'error',
        message: `Pemindai (${scanMethod === 'USB_RFID_SCANNER' ? 'Alat USB/RFID' : 'Kamera'}): Kartu / Kode [${rawVal}] tidak terdaftar di database SMP Negeri 1 Kalipare.`
      });
      return;
    }

    // Special mode: Sholat Dhuhur siswi haid
    if (selectedType === 'dhuhur' && dhuhurFemaleMode === 'haid') {
      if (student.gender !== 'P') {
        if (soundEnabled) playChimeSound('warning');
        setLastScanResult({
          status: 'warning',
          student,
          message: `Mode Khusus Haid aktif: Siswa ${student.name} adalah laki-laki (L). Keterangan Haid hanya berlaku untuk siswi perempuan.`
        });
        return;
      }
      await executeAttendance(student, scanMethod, 'haid', 'Berhalangan / Haid');
      return;
    }

    await executeAttendance(student, scanMethod);
  };

  const executeAttendance = async (
    student: Student, 
    method: string,
    overrideStatus?: 'hadir' | 'terlambat' | 'izin' | 'sakit' | 'alpa' | 'haid',
    notes?: string
  ) => {
    // 1. Check eligibility (Religious exemption, Friday 11:15 - 12:00 schedule, or Gender)
    const check = isStudentEligibleForActivity(student, selectedType, allowFridayOverride);
    if (!check.eligible) {
      if (soundEnabled) playChimeSound('warning');
      setLastScanResult({
        status: 'warning',
        student,
        message: check.reason || 'Siswa tidak memenuhi kriteria absen kegiatan ini.'
      });
      return;
    }

    // 2. Check if already scanned today for this type
    const today = getTodayDateStr();
    const existing = records.find(r => 
      r.studentNis === student.nis && 
      r.date === today && 
      r.type === selectedType
    );

    if (existing && !overrideStatus) {
      if (soundEnabled) playChimeSound('warning');
      setLastScanResult({
        status: 'warning',
        student,
        message: `${student.name} SUDAH ABSEN ${selectedType.toUpperCase()} hari ini pada pukul ${existing.timeStr} WIB (${existing.status.toUpperCase()}).`,
        record: existing
      });
      return;
    }

    // 3. Submit attendance
    const res = await submitAttendance({
      student,
      type: selectedType,
      overrideStatus,
      notes,
      method,
      bypassScheduleCheck: allowFridayOverride
    });

    if (res.success && res.record) {
      setDeviceScanCount((c) => c + 1);
      if (soundEnabled) playChimeSound('bell');
      confetti({
        particleCount: 40,
        spread: 55,
        origin: { y: 0.6 }
      });

      // Automated WhatsApp Gateway dispatch (Notifikasi Guru & Orang Tua)
      let initialWaNotice: string | undefined;
      const recordId = res.record.recordId;

      if (waConfig.enabled && waConfig.autoSendOnScan) {
        // Cek Pencegahan Pesan Ganda (Idempotency)
        if (!isAttendanceNotificationSent(recordId)) {
          markAttendanceNotificationSent(recordId);

          // 1. NOTIFIKASI WHATSAPP GURU (Wajib sesuai spesifikasi Fonnte)
          if (waConfig.teacherNotificationEnabled && waConfig.teacherPhone && waConfig.teacherPhone.trim()) {
            const teacherMsg = formatTeacherAttendanceMessage(res.record, student);
            sendWhatsAppNotification(waConfig.teacherPhone, teacherMsg, waConfig, {
              studentName: student.name,
              studentNis: student.nis,
              className: student.className,
              type: res.record.type,
              recipientRole: 'guru',
              recordId,
              delay: '1-3'
            }).then((waRes) => {
              setLastScanResult((prev) => prev ? {
                ...prev,
                waSentNotice: waRes.success
                  ? `✅ WhatsApp otomatis terkirim ke Guru (${waConfig.teacherPhone})`
                  : `⚠️ Gagal kirim WA Guru: ${waRes.message}`
              } : null);
            }).catch((err) => {
              setLastScanResult((prev) => prev ? { 
                ...prev, 
                waSentNotice: `⚠️ Koneksi WA Guru error: ${err.message}` 
              } : null);
            });
            initialWaNotice = `⏳ Mengirim notifikasi WhatsApp ke Guru (${waConfig.teacherPhone})...`;
          } else if (!waConfig.teacherPhone) {
            initialWaNotice = `ℹ️ Belum ada nomor WhatsApp Guru. Masukkan nomor guru di menu Pengaturan WhatsApp.`;
          }

          // 2. NOTIFIKASI WHATSAPP WALI MURID (Jika diaktifkan & nomor tersedia)
          const targetParentPhone = student.parentPhone || waConfig.fallbackPhone;
          if (waConfig.notifyParentEnabled && targetParentPhone) {
            const tmpl = getTemplateForType(waConfig, res.record.type);
            const parentMsg = renderWhatsAppMessage(tmpl, res.record, student);

            sendWhatsAppNotification(targetParentPhone, parentMsg, waConfig, {
              studentName: student.name,
              studentNis: student.nis,
              className: student.className,
              type: res.record.type,
              recipientRole: 'wali_murid',
              recordId,
              delay: '1-3'
            }).then((waParentRes) => {
              if (waParentRes.success) {
                setLastScanResult((prev) => prev ? {
                  ...prev,
                  waSentNotice: prev.waSentNotice 
                    ? `${prev.waSentNotice} & Wali Murid (${targetParentPhone})` 
                    : `✅ WhatsApp terkirim ke Wali Murid (${targetParentPhone})`
                } : null);
              }
            });
          }
        } else {
          initialWaNotice = `ℹ️ Notifikasi presensi untuk transaksi ini sudah dikirim sebelumnya (mencegah duplikasi).`;
        }
      }

      setLastScanResult({
        status: 'success',
        student,
        message: res.message,
        record: res.record,
        waSentNotice: initialWaNotice
      });

      // Clear manual selections
      setSelectedStudentForManual(null);
      setSearchQuery('');
      setManualNotes('');

      if (onRecordAdded) onRecordAdded();
    } else if (res.alreadyExists) {
      if (soundEnabled) playChimeSound('warning');
      setLastScanResult({
        status: 'warning',
        student,
        message: res.message,
        record: res.record
      });
    } else {
      if (soundEnabled) playChimeSound('error');
      setLastScanResult({
        status: 'error',
        student,
        message: res.message
      });
    }
  };

  // Always keep ref pointing to latest processDecodedText so active camera never reads stale state
  processDecodedTextRef.current = processDecodedText;

  const getAttendanceIcon = (type: AttendanceType) => {
    switch (type) {
      case 'masuk': return <LogIn className="w-5 h-5 text-emerald-600" />;
      case 'pulang': return <LogOut className="w-5 h-5 text-blue-600" />;
      case 'dhuhur': return <Sun className="w-5 h-5 text-amber-500" />;
      case 'jumat': return <Moon className="w-5 h-5 text-indigo-600" />;
      case 'keputrian': return <HeartHandshake className="w-5 h-5 text-rose-500" />;
    }
  };

  const todayStr = getTodayDateStr();
  const todayRecords = records.filter(r => r.date === todayStr);
  const currentCategoryTodayRecords = todayRecords.filter(r => r.type === selectedType);

  return (
    <div className="space-y-6">
      {/* Attendance Category Selector */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              Pilih Sesi Kegiatan Absensi
            </h2>
            <p className="text-xs text-slate-500">
              Pilih kategori absensi yang sedang berlangsung di sekolah
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                soundEnabled 
                  ? 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100' 
                  : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-600" /> : <VolumeX className="w-4 h-4" />}
              <span>{soundEnabled ? 'Suara Aktif' : 'Suara Mati'}</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
          {ATTENDANCE_TYPES.map((type) => {
            const isSelected = selectedType === type.id;
            const countForType = todayRecords.filter(r => r.type === type.id).length;
            return (
              <button
                key={type.id}
                onClick={() => {
                  setSelectedType(type.id);
                  setLastScanResult(null);
                }}
                className={`relative flex flex-col p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/70 shadow-sm ring-2 ring-blue-500/20'
                    : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-white shadow-xs' : 'bg-slate-100'}`}>
                    {getAttendanceIcon(type.id)}
                  </div>
                  <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded-full ${
                    isSelected ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {countForType} hadir
                  </span>
                </div>
                <span className="font-bold text-xs sm:text-sm text-slate-900 leading-snug">
                  {type.label}
                </span>
                <span className="text-[10px] text-slate-500 mt-0.5">
                  {type.desc}
                </span>
              </button>
            );
          })}
        </div>

        {/* Schedule Validity Status Notice: Senin-Jumat, Dhuhur Senin-Kamis, Jumat Khusus Jumat, Sabtu/Minggu Libur */}
        {(() => {
          const check = getScheduleValidity(selectedType);
          if (check.isValid && !allowScheduleOverride) return null;

          return (
            <div className={`mt-3.5 p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
              allowScheduleOverride
                ? 'bg-purple-50 border-purple-300 text-purple-950'
                : 'bg-amber-50 border-amber-300 text-amber-950'
            }`}>
              <div className="flex items-start gap-2.5">
                {allowScheduleOverride ? (
                  <Unlock className="w-5 h-5 text-purple-600 shrink-0 mt-0.5" />
                ) : (
                  <Lock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                )}
                <div>
                  <div className="font-extrabold flex items-center gap-1.5">
                    <span>
                      {check.isWeekend
                        ? `Pemberitahuan: Hari ${check.dayName} (Siswa Libur Akhir Pekan)`
                        : selectedType === 'dhuhur'
                        ? 'Jadwal Sholat Dhuhur Berjamaah: Senin s/d Kamis (11:50 - 12:30 WIB)'
                        : selectedType === 'jumat' || selectedType === 'keputrian'
                        ? 'Jadwal Khusus: Hari Jumat Pukul 11:15 - 12:30 WIB'
                        : 'Jadwal Sekolah: Hari Senin s/d Jumat'}
                    </span>
                    {allowScheduleOverride && selectedType !== 'dhuhur' && (
                      <span className="px-1.5 py-0.2 bg-purple-200 text-purple-900 rounded text-[10px] font-bold">
                        Override Guru Aktif
                      </span>
                    )}
                    {selectedType === 'dhuhur' && (
                      <span className="px-1.5 py-0.2 bg-rose-200 text-rose-900 rounded text-[10px] font-bold">
                        Terkunci Total &bull; Tanpa Buka Paksa
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] mt-0.5">
                    {allowScheduleOverride && selectedType !== 'dhuhur'
                      ? `Sesi ${selectedType.toUpperCase()} dibuka paksa dengan izin guru. Anda dapat memindai presensi di luar jadwal operasional normal.`
                      : check.reason}
                  </p>
                </div>
              </div>

              {selectedType !== 'dhuhur' && (
                <button
                  type="button"
                  onClick={() => setAllowScheduleOverride(!allowScheduleOverride)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer whitespace-nowrap self-end sm:self-center ${
                    allowScheduleOverride
                      ? 'bg-purple-600 text-white border-purple-700 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  {allowScheduleOverride ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                  <span>{allowScheduleOverride ? 'Kunci Kembali' : 'Buka Paksa Sesi (Override Guru)'}</span>
                </button>
              )}
            </div>
          );
        })()}

        {/* Special Exemption Reminder Note */}
        <div className="mt-3.5 bg-amber-50/90 border border-amber-200 rounded-xl p-3 flex items-start gap-2.5 text-xs text-amber-900">
          <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">Ketentuan Khusus Siswa Non-Muslim:</span> Sesuai arahan sekolah, siswa atas nama <strong className="font-bold">Maximilianus Wahyu Galih Pradana (7 Kutai)</strong>, <strong className="font-bold">Diva Widiana (7 Mataram)</strong>, dan <strong className="font-bold">Jevanya Anastasya Blegur (9 Mataram)</strong> hanya dicatat pada Absen Masuk dan Pulang. Absen Sholat Dhuhur, Sholat Jumat, dan Keputrian untuk tiga siswa tersebut otomatis dikosongi / dikecualikan.
          </div>
        </div>

        {/* Sholat Dhuhur: Special Haid Mode for Female Students */}
        {selectedType === 'dhuhur' && (
          <div className="mt-3.5 bg-pink-50/90 border border-pink-200 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-pink-950 shadow-2xs">
            <div className="flex items-start gap-2.5">
              <div className="p-2 rounded-lg bg-pink-200 text-pink-900 mt-0.5">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="font-extrabold flex items-center gap-1.5 text-pink-900">
                  <span>Presensi Sholat Dhuhur: Keterangan Berhalangan (Haid)</span>
                  <span className="px-1.5 py-0.2 bg-pink-200 text-pink-900 rounded text-[10px] font-bold">
                    Khusus Siswi P
                  </span>
                </div>
                <p className="text-[11px] text-pink-800 mt-0.5">
                  Gunakan tombol di samping untuk mengaktifkan mode scan Haid, atau ubah status siswi langsung dari hasil scan di bawah.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-pink-200 shadow-2xs self-end sm:self-center">
              <button
                type="button"
                onClick={() => setDhuhurFemaleMode('hadir')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  dhuhurFemaleMode === 'hadir'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Hadir Berjamaah
              </button>
              <button
                type="button"
                onClick={() => setDhuhurFemaleMode('haid')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  dhuhurFemaleMode === 'haid'
                    ? 'bg-pink-600 text-white shadow-xs'
                    : 'text-pink-700 hover:bg-pink-50'
                }`}
              >
                <span>🌸 Mode Catat Siswi Haid</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Quick Connect WhatsApp Gateway Banner */}
      {/* Quick Connect WhatsApp Gateway Banner */}
      {!(waConfig.apiKey.trim() || hasServerToken) ? (
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 text-white rounded-2xl p-4 shadow-sm border border-emerald-700/60 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-start sm:items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
              <MessageCircle className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h4 className="font-extrabold text-sm text-emerald-200">
                  WhatsApp Gateway Fonnte Belum Dihubungkan
                </h4>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  SERVER FONNTE
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Masukkan Token Fonnte Anda sekali saja di sini. Setiap kartu discan, notifikasi WhatsApp akan meluncur otomatis ke nomor Guru dan Wali Murid.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end md:self-center shrink-0">
            <input
              type="password"
              placeholder="Tempel Token Fonnte..."
              value={quickTokenInput}
              onChange={(e) => setQuickTokenInput(e.target.value)}
              className="px-3 py-1.5 text-xs bg-white text-slate-900 rounded-xl font-mono w-48 focus:ring-2 focus:ring-emerald-400"
            />
            <button
              onClick={async () => {
                if (!quickTokenInput.trim()) {
                  alert('Tempelkan Token Fonnte Anda terlebih dahulu!');
                  return;
                }
                const newCfg = { ...waConfig, apiKey: quickTokenInput.trim(), autoSendOnScan: true };
                await saveWhatsAppConfig(newCfg);
                setWaConfig(newCfg);
                setHasServerToken(true);
                setQuickTokenInput('');
                alert('Token Fonnte berhasil terhubung! Sekarang presensi akan langsung otomatis masuk ke WhatsApp Guru & Wali Murid saat kartu discan.');
              }}
              className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs shadow-md whitespace-nowrap cursor-pointer transition-colors"
            >
              Hubungkan
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs text-emerald-950 shadow-2xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping shrink-0"></span>
            <span className="font-bold">Fonnte WhatsApp Gateway Terhubung:</span>
            <span className="text-slate-600">
              {waConfig.teacherNotificationEnabled && waConfig.teacherPhone
                ? `Notifikasi otomatis ke Guru (${waConfig.teacherPhone}) AKTIF.`
                : 'Notifikasi siap dikirim saat scan (atur nomor guru di Pengaturan WhatsApp).'}
            </span>
          </div>
          <span className="font-mono text-[11px] bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-lg border border-emerald-300">
            Fonnte Gateway ON
          </span>
        </div>
      )}

      {/* USB RFID & Barcode Scanner Hardware Integration Banner for PC */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3 border border-indigo-800/40">
        <div className="flex items-start sm:items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 shrink-0">
            <Radio className="w-5 h-5 animate-pulse" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900"></span>
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h4 className="font-extrabold text-sm text-white">
                Dukungan Pemindai PC: Alat USB RFID &amp; Barcode Scanner Gun
              </h4>
              <span className="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                PLUG &amp; PLAY SIAP
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Aplikasi ini <strong>bisa langsung digunakan di PC</strong> menggunakan alat pemindai barcode / QR gun USB maupun reader kartu RFID USB tanpa instal software tambahan. Tempelkan kartu atau tembak kode QR di PC, sistem otomatis menyimpan kehadiran secara real-time!
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end md:self-center shrink-0">
          <div className="px-3 py-1.5 rounded-xl bg-white/10 text-xs font-mono text-emerald-300 flex items-center gap-2 border border-white/10">
            <Usb className="w-3.5 h-3.5 text-emerald-400" />
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>Auto-Listen PC Aktif</span>
          </div>
        </div>
      </div>

      {/* Toast Notification when Hardware Scanner Input Arrives */}
      {usbScannerNotice && (
        <div className="p-3 bg-indigo-50 border border-indigo-300 rounded-xl text-indigo-950 font-bold text-xs flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-indigo-600" />
          <span>{usbScannerNotice}</span>
        </div>
      )}

      {/* Main Scanner & Manual Input Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Camera QR Code Scanner */}
        <div className="lg:col-span-7 bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-blue-100 text-blue-800">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                    Pemindai Kamera QR Siswa
                  </h3>
                  <p className="text-xs text-slate-500">
                    Arahkan kartu QR siswa ke kamera untuk presensi kilat
                  </p>
                </div>
              </div>

              {isScanning ? (
                <button
                  onClick={handleStopScanner}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition-all shadow-sm cursor-pointer"
                >
                  <CameraOff className="w-4 h-4" />
                  <span>Matikan Kamera</span>
                </button>
              ) : (
                <button
                  onClick={handleStartScanner}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs sm:text-sm font-bold transition-all shadow-md cursor-pointer animate-pulse"
                >
                  <Camera className="w-4 h-4" />
                  <span>Aktifkan Kamera</span>
                </button>
              )}
            </div>

            {/* Video Reader Box */}
            <div className="relative bg-slate-950 rounded-xl overflow-hidden aspect-video sm:aspect-[4/3] flex items-center justify-center border-2 border-dashed border-slate-700">
              <div id="qr-reader" className="w-full h-full"></div>

              {!isScanning && (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-slate-900/90 text-white">
                  <div className="w-16 h-16 rounded-2xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center mb-3">
                    <Camera className="w-8 h-8 text-blue-400" />
                  </div>
                  <h4 className="font-bold text-sm sm:text-base mb-1">Kamera Siap Diaktifkan</h4>
                  <p className="text-xs text-slate-300 max-w-sm mb-4">
                    Izinkan akses kamera perangkat untuk memindai kartu presensi QR Code murid secara otomatis dan cepat.
                  </p>
                  <button
                    onClick={handleStartScanner}
                    className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs sm:text-sm font-bold rounded-lg shadow-lg cursor-pointer"
                  >
                    Mulai Scan QR Sekarang
                  </button>
                </div>
              )}
            </div>

            {scannerError && (
              <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{scannerError}</span>
              </div>
            )}
          </div>

          {/* Quick instructions & Multi-HP Concurrent Indicator */}
          <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              <span>Mode Scan Antrian Cepat Aktif &bull; Anti-Ganda Multi-HP</span>
            </span>
            <span className="inline-flex items-center gap-1.5 font-semibold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-lg border border-blue-200">
              <Smartphone className="w-3.5 h-3.5" />
              <span>Scan HP Ini: {deviceScanCount} siswa</span>
            </span>
          </div>
        </div>

        {/* Right: Quick Search by NIS/Name & Manual Input */}
        <div className="lg:col-span-5 bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 rounded-lg bg-indigo-100 text-indigo-800">
                <Search className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                  Cari Siswa Cepat (Tanpa Kamera)
                </h3>
                <p className="text-xs text-slate-500">
                  Ketik nomor NIS atau nama siswa untuk presensi langsung
                </p>
              </div>
            </div>

            {/* Search Input */}
            <div className="relative mb-3">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Ketik NIS (contoh: 06694) atau nama..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all font-medium"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600 font-bold"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Matched Autocomplete List */}
            {matchedStudents.length > 0 && (
              <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 max-h-48 overflow-y-auto mb-4 bg-slate-50/50 shadow-inner">
                {matchedStudents.map((st) => (
                  <button
                    key={st.id}
                    onClick={() => {
                      setSelectedStudentForManual(st);
                      setSearchQuery(st.name);
                      setMatchedStudents([]);
                    }}
                    className={`w-full p-2.5 text-left flex items-center justify-between hover:bg-blue-50 transition-colors cursor-pointer ${
                      selectedStudentForManual?.id === st.id ? 'bg-blue-100/70' : ''
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                        st.gender === 'L' ? 'bg-blue-200 text-blue-900' : 'bg-rose-200 text-rose-900'
                      }`}>
                        {st.gender}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                          {st.name}
                          {st.exemptReligious && (
                            <span className="text-[10px] px-1 py-0.2 bg-amber-200 text-amber-900 rounded font-bold">
                              Non-Muslim
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          NIS: {st.nis} &bull; {st.className}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                  </button>
                ))}
              </div>
            )}

            {/* Selected Student Card & Manual Submission */}
            {selectedStudentForManual ? (
              <div className="bg-blue-50/60 border border-blue-200 rounded-xl p-3.5 mb-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-blue-700" />
                    <span className="text-xs font-bold text-blue-900">Siswa Terpilih:</span>
                  </div>
                  <button
                    onClick={() => setSelectedStudentForManual(null)}
                    className="text-[11px] text-slate-500 hover:text-slate-800 underline font-medium cursor-pointer"
                  >
                    Batal
                  </button>
                </div>

                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">
                    {selectedStudentForManual.name}
                  </h4>
                  <p className="text-xs text-slate-600 font-mono mt-0.5">
                    NIS: {selectedStudentForManual.nis} &bull; Kelas: {selectedStudentForManual.className} ({selectedStudentForManual.gender === 'L' ? 'Laki-laki' : 'Perempuan'})
                  </p>
                  {selectedStudentForManual.exemptReligious && (
                    <p className="text-xs text-amber-800 font-semibold mt-1">
                      ⚠️ Status: Dikecualikan dari Ibadah Sholat &amp; Keputrian (Hanya Masuk &amp; Pulang).
                    </p>
                  )}
                </div>

                {/* Status Selection: Hadir / Terlambat / Izin / Sakit / Alpa */}
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">
                    Status Kehadiran:
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                    {[
                      { id: 'hadir', label: 'Hadir', color: 'bg-emerald-600' },
                      { id: 'terlambat', label: 'Terlambat', color: 'bg-amber-600' },
                      { id: 'izin', label: 'Izin', color: 'bg-indigo-600' },
                      { id: 'sakit', label: 'Sakit', color: 'bg-violet-600' },
                      { id: 'alpa', label: 'Alpa', color: 'bg-rose-600' },
                      ...(selectedType === 'dhuhur' && selectedStudentForManual.gender === 'P'
                        ? [{ id: 'haid', label: 'Haid', color: 'bg-pink-600' }]
                        : []
                      )
                    ].map((st) => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => setManualStatus(st.id as any)}
                        className={`py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                          manualStatus === st.id
                            ? `${st.color} text-white shadow-xs`
                            : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {st.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Optional Note */}
                <div>
                  <input
                    type="text"
                    placeholder="Catatan khusus (misal: Surat Dokter / Dispensasi)..."
                    value={manualNotes}
                    onChange={(e) => setManualNotes(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <button
                  onClick={() => executeAttendance(selectedStudentForManual, 'MANUAL_INPUT', manualStatus, manualNotes)}
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Simpan Presensi {selectedType.toUpperCase()}</span>
                </button>
              </div>
            ) : (
              <div className="p-5 border border-dashed border-slate-200 rounded-xl text-center bg-slate-50/60 mb-4">
                <p className="text-xs text-slate-500">
                  Pencarian siswa aktif di atas. Ketik untuk memilih siswa secara manual jika kartu QR tertinggal atau basah.
                </p>
              </div>
            )}
          </div>

          {/* Quick Summary of Current Session across all concurrent phones */}
          <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200/80 space-y-2">
            <div className="text-xs text-slate-600 flex items-center justify-between">
              <span className="font-semibold">Total Sesi {selectedType.toUpperCase()} (Semua HP):</span>
              <span className="font-extrabold text-slate-900 text-sm font-mono">
                {currentCategoryTodayRecords.length} / {students.length} Siswa
              </span>
            </div>
            <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-600 to-emerald-500 transition-all duration-300"
                style={{
                  width: `${students.length > 0 ? Math.min(100, Math.round((currentCategoryTodayRecords.length / students.length) * 100)) : 0}%`
                }}
              />
            </div>
            <div className="text-[11px] text-slate-500 flex items-center justify-between">
              <span>Sinkronisasi Multi-HP Real-Time</span>
              <span className="font-bold text-emerald-700">
                {students.length > 0 ? Math.round((currentCategoryTodayRecords.length / students.length) * 100) : 0}% Tercatat
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Instant Flash Feedback Banner */}
      {lastScanResult && (
        <div
          className={`p-4 rounded-2xl border shadow-md transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
            lastScanResult.status === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
              : lastScanResult.status === 'warning'
              ? 'bg-amber-50 border-amber-300 text-amber-950'
              : 'bg-rose-50 border-rose-300 text-rose-950'
          }`}
        >
          <div className="flex items-start gap-3">
            {lastScanResult.status === 'success' ? (
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
            ) : lastScanResult.status === 'warning' ? (
              <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
            )}
            <div>
              <div className="font-extrabold text-sm sm:text-base">
                {lastScanResult.student ? `${lastScanResult.student.name} (${lastScanResult.student.className})` : 'Pemberitahuan Presensi'}
              </div>
              <p className="text-xs sm:text-sm mt-0.5">
                {lastScanResult.message}
              </p>
              {lastScanResult.record && (
                <div className="mt-1 flex flex-wrap gap-2 text-[11px] font-mono items-center">
                  <span className="bg-white/80 px-2 py-0.5 rounded border">
                    Waktu: {lastScanResult.record.timeStr} WIB
                  </span>
                  <span className="bg-white/80 px-2 py-0.5 rounded border capitalize">
                    Status: {lastScanResult.record.status}
                  </span>
                  <span className="bg-white/80 px-2 py-0.5 rounded border">
                    Metode: {lastScanResult.record.method || 'QR'}
                  </span>
                  {lastScanResult.waSentNotice && (
                    <span className="bg-emerald-100 text-emerald-800 font-sans font-bold px-2 py-0.5 rounded border border-emerald-300 flex items-center gap-1">
                      <MessageCircle className="w-3 h-3 text-emerald-700" />
                      {lastScanResult.waSentNotice}
                    </span>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-end sm:self-center">
            {/* If student has parent phone registered */}
            {lastScanResult.student?.parentPhone && lastScanResult.record && (
              <a
                href={generateWaMeLink(
                  lastScanResult.student.parentPhone,
                  renderWhatsAppMessage(
                    getTemplateForType(waConfig, lastScanResult.record.type),
                    lastScanResult.record,
                    lastScanResult.student
                  )
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-md flex items-center gap-2 transition-all"
                title="Buka chat WhatsApp wali murid sekarang"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Kirim WA ke Wali Murid ({lastScanResult.student.parentPhone})</span>
              </a>
            )}

            {/* If student DOES NOT have parent phone registered yet -> Quick input in place */}
            {!lastScanResult.student?.parentPhone && lastScanResult.record && (
              <div className="bg-amber-100/90 border border-amber-300 p-2 rounded-xl flex flex-wrap items-center gap-2 text-xs">
                <span className="font-bold text-amber-950 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-amber-800" />
                  No WA Ortu:
                </span>
                <input
                  type="tel"
                  placeholder="Contoh: 081234567890"
                  value={quickPhoneInput}
                  onChange={(e) => setQuickPhoneInput(e.target.value)}
                  className="px-2.5 py-1 text-xs bg-white border border-amber-300 rounded-lg font-mono w-40 focus:ring-2 focus:ring-amber-500"
                  onKeyDown={async (e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      const clean = quickPhoneInput.trim();
                      if (!clean) return;
                      setIsSavingPhone(true);
                      await updateStudentParentPhone(lastScanResult.student!.id, clean);
                      lastScanResult.student!.parentPhone = clean;
                      setIsSavingPhone(false);
                      setQuickPhoneInput('');
                      
                      const tmpl = getTemplateForType(waConfig, lastScanResult.record!.type);
                      const waText = renderWhatsAppMessage(tmpl, lastScanResult.record!, lastScanResult.student!);
                      if (waConfig.apiKey.trim()) {
                        const sendRes = await sendWhatsAppNotification(clean, waText, waConfig);
                        setLastScanResult(prev => prev ? { ...prev, waSentNotice: sendRes.message } : null);
                      } else {
                        window.open(generateWaMeLink(clean, waText), '_blank');
                      }
                    }
                  }}
                />
                <button
                  type="button"
                  disabled={isSavingPhone}
                  onClick={async () => {
                    const clean = quickPhoneInput.trim();
                    if (!clean) {
                      alert('Masukkan nomor WhatsApp wali murid terlebih dahulu!');
                      return;
                    }
                    setIsSavingPhone(true);
                    await updateStudentParentPhone(lastScanResult.student!.id, clean);
                    lastScanResult.student!.parentPhone = clean;
                    setIsSavingPhone(false);
                    setQuickPhoneInput('');

                    const tmpl = getTemplateForType(waConfig, lastScanResult.record!.type);
                    const waText = renderWhatsAppMessage(tmpl, lastScanResult.record!, lastScanResult.student!);
                    if (waConfig.apiKey.trim()) {
                      const sendRes = await sendWhatsAppNotification(clean, waText, waConfig);
                      setLastScanResult(prev => prev ? { ...prev, waSentNotice: sendRes.message } : null);
                    } else {
                      window.open(generateWaMeLink(clean, waText), '_blank');
                    }
                  }}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-xs flex items-center gap-1 transition-all disabled:opacity-50 cursor-pointer"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>{isSavingPhone ? 'Menyimpan...' : 'Simpan & Kirim WA'}</span>
                </button>
              </div>
            )}

            {selectedType === 'dhuhur' && lastScanResult.student?.gender === 'P' && (
              <button
                type="button"
                onClick={() => {
                  if (lastScanResult.student) {
                    const nextStatus = lastScanResult.record?.status === 'haid' ? 'hadir' : 'haid';
                    executeAttendance(
                      lastScanResult.student,
                      'MANUAL_INPUT',
                      nextStatus,
                      nextStatus === 'haid' ? 'Berhalangan / Haid' : undefined
                    );
                  }
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold shadow-xs cursor-pointer transition-all flex items-center gap-1.5 ${
                  lastScanResult.record?.status === 'haid'
                    ? 'bg-amber-600 hover:bg-amber-700 text-white'
                    : 'bg-pink-600 hover:bg-pink-700 text-white'
                }`}
              >
                <span>🌸 {lastScanResult.record?.status === 'haid' ? 'Kembalikan ke HADIR' : 'Ubah ke Status HAID'}</span>
              </button>
            )}

            <button
              onClick={() => setLastScanResult(null)}
              className="px-3 py-1 bg-white/80 hover:bg-white text-xs font-bold rounded-lg border shadow-xs cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      {/* Real-time Feed: Recent Presensi Today */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              Riwayat Presensi Masuk &amp; Kegiatan Hari Ini ({todayRecords.length} Scan)
            </h3>
          </div>
          <span className="text-xs text-slate-500">
            Tersimpan permanen di Firebase Firestore
          </span>
        </div>

        {todayRecords.length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-xs">
            Belum ada data presensi hari ini. Silakan scan kartu QR siswa atau gunakan pencarian manual.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">Waktu</th>
                  <th className="py-2.5 px-3 font-semibold">NIS</th>
                  <th className="py-2.5 px-3 font-semibold">Nama Siswa</th>
                  <th className="py-2.5 px-3 font-semibold">Kelas</th>
                  <th className="py-2.5 px-3 font-semibold">Kegiatan</th>
                  <th className="py-2.5 px-3 font-semibold">Status</th>
                  <th className="py-2.5 px-3 font-semibold text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {todayRecords.slice().reverse().slice(0, 10).map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2 px-3 font-mono font-medium text-slate-700">
                      {r.timeStr}
                    </td>
                    <td className="py-2 px-3 font-mono text-slate-600">
                      {r.studentNis}
                    </td>
                    <td className="py-2 px-3 font-bold text-slate-900">
                      {r.studentName}
                    </td>
                    <td className="py-2 px-3 text-slate-600">
                      {r.className}
                    </td>
                    <td className="py-2 px-3">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 capitalize">
                        {r.type}
                      </span>
                    </td>
                    <td className="py-2 px-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        r.status === 'hadir' 
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : r.status === 'terlambat'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                      }`}>
                        {r.status}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {(() => {
                          const student = students.find(s => s.nis === r.studentNis);
                          if (!student?.parentPhone) return null;
                          const waText = renderWhatsAppMessage(getTemplateForType(waConfig, r.type), r, student);
                          const waUrl = generateWaMeLink(student.parentPhone, waText);
                          return (
                            <a
                              href={waUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-emerald-600 hover:text-emerald-700 p-1 rounded-md hover:bg-emerald-50 transition-colors"
                              title={`Kirim WA ke Orang Tua (${student.parentPhone})`}
                            >
                              <MessageCircle className="w-3.5 h-3.5 inline" />
                            </a>
                          );
                        })()}
                        <button
                          onClick={async () => {
                            if (confirm(`Hapus catatan presensi untuk ${r.studentName}?`)) {
                              await deleteAttendanceRecord(r.id);
                            }
                          }}
                          title="Hapus data salah scan"
                          className="text-slate-400 hover:text-rose-600 transition-colors cursor-pointer p-1 rounded-md hover:bg-rose-50"
                        >
                          <Trash2 className="w-3.5 h-3.5 inline" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
