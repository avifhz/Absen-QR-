import React, { useState } from 'react';
import { 
  FileCode, 
  Code2, 
  Copy, 
  Check, 
  Download, 
  ExternalLink, 
  BookOpen, 
  Play, 
  HelpCircle, 
  FileSpreadsheet, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight,
  ShieldCheck,
  Layers,
  FileCheck
} from 'lucide-react';
import { Student } from '../data/studentsData';
import { generateCodeGs, generateIndexHtml } from '../utils/gasTemplates';

interface GoogleAppsScriptTabProps {
  students: Student[];
}

export const GoogleAppsScriptTab: React.FC<GoogleAppsScriptTabProps> = ({ students }) => {
  const [subTab, setSubTab] = useState<'codegs' | 'indexhtml' | 'tutorial' | 'preview'>('codegs');
  const [copiedCodeGs, setCopiedCodeGs] = useState(false);
  const [copiedIndexHtml, setCopiedIndexHtml] = useState(false);

  const codeGsContent = generateCodeGs(students);
  const indexHtmlContent = generateIndexHtml(students);

  const handleCopy = (type: 'codegs' | 'indexhtml') => {
    const textToCopy = type === 'codegs' ? codeGsContent : indexHtmlContent;
    navigator.clipboard.writeText(textToCopy).then(() => {
      if (type === 'codegs') {
        setCopiedCodeGs(true);
        setTimeout(() => setCopiedCodeGs(false), 2500);
      } else {
        setCopiedIndexHtml(true);
        setTimeout(() => setCopiedIndexHtml(false), 2500);
      }
    });
  };

  const handleDownload = (filename: string, content: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header Info Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white rounded-2xl shadow-md p-6 border border-emerald-700/40">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center gap-1.5">
                <FileSpreadsheet className="w-3.5 h-3.5" />
                Versi Google Apps Script &amp; Google Spreadsheet
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/20 text-blue-300 border border-blue-400/30">
                Data Tetap Aman di Firebase
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
              Generator Kode Google Apps Script (Code.gs &amp; Index.html)
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100/90 mt-1 max-w-3xl leading-relaxed">
              Anda dapat mengoperasikan presensi ini secara paralel: versi web Firebase tetap aktif tanpa perubahan, dan versi Google Apps Script kini tersimpan ganda ke <b>Google Spreadsheet &amp; Firebase Firestore</b>, pemindai barcode/QR kamera HP telah diperbaiki mendukung barcode 1D, serta tombol unduh rekapan Excel (.xlsx) dan PDF resmi bebas hambatan sandbox.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={() => handleDownload('Code.gs', codeGsContent, 'text/javascript')}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-white/10 hover:bg-white/20 text-white border border-white/20 shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-300" />
              <span>Unduh Code.gs</span>
            </button>
            <button
              onClick={() => handleDownload('Index.html', indexHtmlContent, 'text/html')}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Unduh Index.html</span>
            </button>
          </div>
        </div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-5 border-t border-emerald-800/60 text-xs">
          <div className="flex items-center gap-2 text-emerald-200">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>479 Master Siswa Lengkap</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Pengecualian Non-Muslim Aktif</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-200">
            <FileCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Unduh Excel &amp; PDF Tetap Aktif</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-200">
            <Layers className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Dukungan RFID &amp; Barcode USB</span>
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="bg-white rounded-2xl shadow-xs border border-slate-200 p-2">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSubTab('codegs')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              subTab === 'codegs'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>1. Kode Code.gs (Backend Spreadsheet)</span>
          </button>

          <button
            onClick={() => setSubTab('indexhtml')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              subTab === 'indexhtml'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>2. Kode Index.html (Frontend Web App)</span>
          </button>

          <button
            onClick={() => setSubTab('tutorial')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              subTab === 'tutorial'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>3. Panduan Pemasangan (Langkah demi Langkah)</span>
          </button>

          <button
            onClick={() => setSubTab('preview')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              subTab === 'preview'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Play className="w-4 h-4" />
            <span>4. Uji Coba Simulator Web App</span>
          </button>
        </div>
      </div>

      {/* ================= TAB 1: CODE.GS ================= */}
      {subTab === 'codegs' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 sm:p-5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <FileCode className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-800 text-sm sm:text-base">File: Code.gs</h3>
                <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-slate-200 text-slate-700 font-semibold">
                  Google Apps Script
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Salin seluruh kode ini ke file <code>Code.gs</code> di editor Apps Script Google Spreadsheet Anda.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleCopy('codegs')}
                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer ${
                  copiedCodeGs
                    ? 'bg-emerald-600 text-white'
                    : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                }`}
              >
                {copiedCodeGs ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCodeGs ? 'Berhasil Disalin!' : 'Salin Kode Code.gs'}</span>
              </button>
              <button
                onClick={() => handleDownload('Code.gs', codeGsContent, 'text/javascript')}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Unduh File</span>
              </button>
            </div>
          </div>

          {/* Code Display Area */}
          <div className="relative">
            <pre className="p-4 sm:p-6 bg-slate-950 text-slate-200 font-mono text-xs overflow-x-auto max-h-[600px] leading-relaxed selection:bg-emerald-700">
              <code>{codeGsContent}</code>
            </pre>
          </div>
        </div>
      )}

      {/* ================= TAB 2: INDEX.HTML ================= */}
      {subTab === 'indexhtml' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 sm:p-5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <Code2 className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-800 text-sm sm:text-base">File: Index.html</h3>
                <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-slate-200 text-slate-700 font-semibold">
                  HTML5 + Tailwind CDN + SheetJS + jsPDF
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Buat file HTML baru di Apps Script dengan nama <code>Index</code>, lalu paste seluruh isi kode ini.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleCopy('indexhtml')}
                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer ${
                  copiedIndexHtml
                    ? 'bg-blue-600 text-white'
                    : 'bg-blue-700 hover:bg-blue-800 text-white'
                }`}
              >
                {copiedIndexHtml ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedIndexHtml ? 'Berhasil Disalin!' : 'Salin Kode Index.html'}</span>
              </button>
              <button
                onClick={() => handleDownload('Index.html', indexHtmlContent, 'text/html')}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Unduh File</span>
              </button>
            </div>
          </div>

          {/* Code Display Area */}
          <div className="relative">
            <pre className="p-4 sm:p-6 bg-slate-950 text-slate-200 font-mono text-xs overflow-x-auto max-h-[600px] leading-relaxed selection:bg-blue-700">
              <code>{indexHtmlContent}</code>
            </pre>
          </div>
        </div>
      )}

      {/* ================= TAB 3: TUTORIAL PEMASANGAN ================= */}
      {subTab === 'tutorial' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h3 className="text-lg font-black text-slate-800">
              Panduan Lengkap Pemasangan di Google Spreadsheet (5 Menit Selesai)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Ikuti langkah-langkah mudah di bawah ini untuk membuat sistem presensi web berbasis Google Spreadsheet.
            </p>
          </div>

          <div className="space-y-4">
            {/* Step 1 */}
            <div className="flex gap-4 p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
                1
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-sm text-slate-800">Buat File Google Spreadsheet Baru</h4>
                <p className="text-xs text-slate-600">
                  Buka Google Drive (<a href="https://sheets.new" target="_blank" rel="noreferrer" className="text-emerald-700 font-semibold underline">sheets.new</a>) dan buat spreadsheet baru. Beri judul misalnya <b>"Presensi Siswa SMPN 1 Kalipare"</b>.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-4 p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
                2
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-sm text-slate-800">Buka Editor Google Apps Script</h4>
                <p className="text-xs text-slate-600">
                  Di menu atas spreadsheet, klik menu <b>Ekstensi</b> &gt; <b>Apps Script</b>. Jendela editor skrip Google akan terbuka di tab baru.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-4 p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
                3
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-sm text-slate-800">Pasang Kode Code.gs</h4>
                <p className="text-xs text-slate-600">
                  Hapus semua kode bawaan di file <code>Code.gs</code>, kemudian paste seluruh isi kode dari tab <b>1. Kode Code.gs</b> di atas. Tekan <code>Ctrl + S</code> untuk menyimpan.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex gap-4 p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
                4
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-sm text-slate-800">Buat File Index.html</h4>
                <p className="text-xs text-slate-600">
                  Di sisi kiri editor, klik tanda tambah (<b>+</b>) di sebelah tulisan <i>File</i> &gt; pilih <b>HTML</b>. Beri nama persis <b><code>Index</code></b> (tanpa menulis .html). Hapus isinya, lalu paste kode dari tab <b>2. Kode Index.html</b> di atas. Tekan <code>Ctrl + S</code> untuk menyimpan.
                </p>
              </div>
            </div>

            {/* Step 5 */}
            <div className="flex gap-4 p-4 rounded-xl border border-emerald-200 bg-emerald-50/40">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
                5
              </div>
              <div className="space-y-2">
                <h4 className="font-bold text-sm text-emerald-950">Terapkan Sebagai Aplikasi Web (Deploy as Web App)</h4>
                <p className="text-xs text-slate-600">
                  Klik tombol biru <b>Terapkan (Deploy)</b> di pojok kanan atas &gt; pilih <b>Deployment baru (New deployment)</b>:
                </p>
                <ul className="text-xs text-slate-700 list-disc pl-5 space-y-1">
                  <li>Pilih jenis (ikon roda gigi): <b>Aplikasi Web (Web app)</b></li>
                  <li>Deskripsi: <i>Presensi Nesaka v1.0</i></li>
                  <li>Jalankan sebagai (Execute as): <b>Saya (email akun Anda)</b></li>
                  <li>Yang memiliki akses (Who has access): <b>Siapa saja (Anyone)</b> agar guru atau alat scan di PC sekolah bisa mengakses tanpa kendala login</li>
                  <li>Klik <b>Terapkan (Deploy)</b> dan berikan izin otorisasi spreadsheet jika diminta.</li>
                </ul>
              </div>
            </div>

            {/* Step 6 */}
            <div className="flex gap-4 p-4 rounded-xl border border-blue-200 bg-blue-50/40">
              <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
                6
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-sm text-blue-950">Buka URL Web App &amp; Selesai!</h4>
                <p className="text-xs text-slate-600">
                  Salin URL Aplikasi Web yang diberikan oleh Google. Buka di browser PC atau HP Anda. Sistem presensi siap digunakan memindai QR siswa, absen manual, dan mengunduh rekapan Excel / PDF resmi!
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 4: SIMULATOR / PREVIEW ================= */}
      {subTab === 'preview' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-800 text-sm sm:text-base flex items-center gap-2">
                <Play className="w-4 h-4 text-emerald-600" />
                Simulator Tampilan Web App Google Apps Script
              </h3>
              <p className="text-xs text-slate-500">
                Berikut adalah simulasi langsung dari antarmuka Web App versi Google Apps Script yang dihasilkan oleh <code>Index.html</code>.
              </p>
            </div>
            <button
              onClick={() => {
                const blob = new Blob([indexHtmlContent], { type: 'text/html' });
                const url = URL.createObjectURL(blob);
                window.open(url, '_blank');
              }}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Buka di Tab Baru Penuh</span>
            </button>
          </div>

          <div className="rounded-xl border border-slate-300 overflow-hidden shadow-inner bg-slate-900">
            <iframe
              srcDoc={indexHtmlContent}
              title="Simulator Web App Google Apps Script"
              className="w-full h-[650px] border-0 bg-slate-100"
              sandbox="allow-scripts allow-modals allow-same-origin allow-downloads"
            />
          </div>
        </div>
      )}
    </div>
  );
};
