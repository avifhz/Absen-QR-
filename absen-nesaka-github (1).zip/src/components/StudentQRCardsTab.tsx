import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { 
  Printer, 
  Download, 
  Search, 
  Filter, 
  School, 
  User, 
  Layers,
  Sparkles,
  QrCode
} from 'lucide-react';
import { Student, SCHOOL_CLASSES } from '../data/studentsData';

interface StudentQRCardsTabProps {
  students: Student[];
}

export const StudentQRCardsTab: React.FC<StudentQRCardsTabProps> = ({ students }) => {
  const [selectedClass, setSelectedClass] = useState<string>('7 Kutai');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [qrCodeUrls, setQrCodeUrls] = useState<Record<string, string>>({});
  const [isGenerating, setIsGenerating] = useState<boolean>(true);

  // Filter students based on selected class and search query
  const filteredStudents = students.filter(st => {
    const matchesClass = selectedClass === 'ALL' || st.className === selectedClass;
    const matchesQuery = !searchQuery.trim() || 
      st.nis.toLowerCase().includes(searchQuery.toLowerCase()) ||
      st.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesClass && matchesQuery;
  });

  // Generate QR Code data URLs
  useEffect(() => {
    let isCancelled = false;
    const generateCodes = async () => {
      setIsGenerating(true);
      const newUrls: Record<string, string> = {};

      for (const st of filteredStudents) {
        if (isCancelled) return;
        try {
          // Payload contains plain NIS for ultra-fast scanning
          const url = await QRCode.toDataURL(st.nis, {
            errorCorrectionLevel: 'M',
            margin: 1,
            width: 220,
            color: {
              dark: '#0f172a',
              light: '#ffffff'
            }
          });
          newUrls[st.id] = url;
        } catch (err) {
          console.error("Failed to generate QR for", st.nis, err);
        }
      }

      if (!isCancelled) {
        setQrCodeUrls(newUrls);
        setIsGenerating(false);
      }
    };

    generateCodes();

    return () => {
      isCancelled = true;
    };
  }, [filteredStudents.length, selectedClass, searchQuery]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadSingleQR = (st: Student) => {
    const url = qrCodeUrls[st.id];
    if (!url) return;
    const a = document.createElement('a');
    a.href = url;
    a.download = `QR_${st.nis}_${st.name.replace(/\s+/g, '_')}.png`;
    a.click();
  };

  return (
    <div className="space-y-6">
      {/* Header & Filter Controls (Hidden in Print) */}
      <div className="print:hidden bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <QrCode className="w-5 h-5 text-blue-600" />
              Generator &amp; Cetak Kartu QR Presensi Siswa
            </h2>
            <p className="text-xs text-slate-500">
              Cetak kartu presensi siswa SMPN 1 Kalipare per kelas untuk dibagikan kepada siswa atau ditempel di buku presensi
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak Kartu ({filteredStudents.length} Siswa)</span>
            </button>
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-2 border-t border-slate-100">
          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Pilih Kelas:
            </label>
            <div className="relative">
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="w-full pl-3 pr-8 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
              >
                <option value="ALL">Semua Kelas (479 Siswa)</option>
                {SCHOOL_CLASSES.map(cls => (
                  <option key={cls} value={cls}>
                    Kelas {cls} ({students.filter(s => s.className === cls).length} Siswa)
                  </option>
                ))}
              </select>
              <Filter className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-2.5 pointer-events-none" />
            </div>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Cari Siswa:
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="Cari NIS atau nama siswa..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          <div className="flex items-end">
            <div className="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-xl p-2 w-full flex items-center justify-between">
              <span>Menampilkan:</span>
              <strong className="text-slate-900 font-mono font-bold">
                {filteredStudents.length} dari {students.length} Siswa
              </strong>
            </div>
          </div>
        </div>
      </div>

      {/* Printable Cards Grid */}
      {isGenerating ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200/80">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-xs font-bold text-slate-700">Menghasilkan Kode QR Presensi...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 print:grid-cols-2 print:gap-3">
          {filteredStudents.map((st) => {
            const qrUrl = qrCodeUrls[st.id];
            return (
              <div
                key={st.id}
                className="bg-white rounded-2xl border-2 border-slate-200 shadow-sm overflow-hidden flex flex-col justify-between hover:border-blue-400 transition-all print:border-slate-800 print:shadow-none print:break-inside-avoid"
              >
                {/* School Header Ribbon */}
                <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white p-2.5 flex items-center justify-between border-b border-blue-800">
                  <div className="flex items-center gap-1.5">
                    <img 
                      src="/assets/aistudio/logo_nesaka-removebg-preview_ee9f6ab8.png" 
                      alt="Logo Nesaka" 
                      className="w-5 h-5 object-contain"
                    />
                    <div>
                      <div className="text-[11px] font-extrabold tracking-tight leading-tight">
                        SMPN 1 KALIPARE
                      </div>
                      <div className="text-[9px] text-blue-200">
                        KARTU PRESENSI QR SISWA
                      </div>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 bg-amber-400 text-slate-950 rounded">
                    {st.className}
                  </span>
                </div>

                {/* Card Body */}
                <div className="p-3.5 flex flex-col items-center text-center space-y-2">
                  {/* Student Info */}
                  <div>
                    <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 line-clamp-1">
                      {st.name}
                    </h4>
                    <div className="flex items-center justify-center gap-2 mt-0.5 text-[11px] text-slate-600 font-mono">
                      <span>NIS: <strong className="text-slate-900">{st.nis}</strong></span>
                      <span>&bull;</span>
                      <span className="font-bold">{st.gender === 'L' ? 'Laki-laki (L)' : 'Perempuan (P)'}</span>
                    </div>
                  </div>

                  {/* High Quality QR Code Image */}
                  <div className="p-2 bg-white rounded-xl border border-slate-200 shadow-inner flex items-center justify-center">
                    {qrUrl ? (
                      <img
                        src={qrUrl}
                        alt={`QR Code ${st.nis}`}
                        className="w-32 h-32 object-contain"
                      />
                    ) : (
                      <div className="w-32 h-32 bg-slate-100 flex items-center justify-center text-[10px] text-slate-400">
                        Loading QR...
                      </div>
                    )}
                  </div>

                  {/* Special Exemption / Regular Badge */}
                  {st.exemptReligious ? (
                    <div className="w-full text-[10px] font-semibold text-amber-900 bg-amber-50 border border-amber-200 rounded-lg py-1 px-2">
                      ⚠️ Khusus: Masuk &amp; Pulang (Dikecualikan Sholat/Keputrian)
                    </div>
                  ) : (
                    <div className="w-full text-[10px] text-slate-500 bg-slate-50 rounded-lg py-1 px-2">
                      Tahun Pelajaran 2026/2027
                    </div>
                  )}
                </div>

                {/* Card Footer Actions (Hidden when printing) */}
                <div className="print:hidden p-2.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400 font-mono">
                    ID: {st.id}
                  </span>
                  <button
                    onClick={() => handleDownloadSingleQR(st)}
                    className="flex items-center gap-1 text-[11px] font-bold text-blue-700 hover:text-blue-900 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Unduh PNG</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
