import React, { useState } from 'react';
import { 
  Users, 
  LogIn, 
  LogOut, 
  Sun, 
  Moon, 
  HeartHandshake, 
  AlertCircle, 
  TrendingUp, 
  Clock, 
  Calendar,
  Sparkles,
  Award
} from 'lucide-react';
import { Student, AttendanceRecord, SCHOOL_CLASSES } from '../data/studentsData';
import { getTodayDateStr, formatIndoDate } from '../services/attendanceService';

interface DashboardTabProps {
  students: Student[];
  records: AttendanceRecord[];
}

export const DashboardTab: React.FC<DashboardTabProps> = ({ students, records }) => {
  const [targetDate, setTargetDate] = useState<string>(getTodayDateStr());
  const [selectedClass, setSelectedClass] = useState<string>('ALL');

  // Filter records by date and class
  const filteredRecords = records.filter(r => {
    const matchesDate = r.date === targetDate;
    const matchesClass = selectedClass === 'ALL' || r.className === selectedClass;
    return matchesDate && matchesClass;
  });

  const relevantStudents = students.filter(s => 
    selectedClass === 'ALL' || s.className === selectedClass
  );

  const totalRelevantStudents = relevantStudents.length;

  // Calculate statistics
  const masukRecords = filteredRecords.filter(r => r.type === 'masuk');
  const masukHadir = masukRecords.filter(r => r.status === 'hadir').length;
  const masukTerlambat = masukRecords.filter(r => r.status === 'terlambat').length;
  const totalMasuk = masukHadir + masukTerlambat;

  const pulangHadir = filteredRecords.filter(r => r.type === 'pulang' && (r.status === 'hadir' || r.status === 'terlambat')).length;
  const dhuhurHadir = filteredRecords.filter(r => r.type === 'dhuhur' && (r.status === 'hadir' || r.status === 'terlambat')).length;
  const dhuhurHaid = filteredRecords.filter(r => r.type === 'dhuhur' && r.status === 'haid').length;
  const jumatHadir = filteredRecords.filter(r => r.type === 'jumat' && (r.status === 'hadir' || r.status === 'terlambat')).length;
  const keputrianHadir = filteredRecords.filter(r => r.type === 'keputrian' && (r.status === 'hadir' || r.status === 'terlambat')).length;

  // Eligible students for Jumat and Keputrian
  const eligibleJumatStudents = relevantStudents.filter(s => s.gender === 'L' && !s.exemptReligious).length;
  const eligibleKeputrianStudents = relevantStudents.filter(s => s.gender === 'P' && !s.exemptReligious).length;
  const eligibleDhuhurStudents = relevantStudents.filter(s => !s.exemptReligious).length;

  // Attendance rate
  const attendanceRate = totalRelevantStudents > 0 
    ? Math.round((totalMasuk / totalRelevantStudents) * 100) 
    : 0;

  // On-time discipline rate among those present
  const onTimeRate = totalMasuk > 0 
    ? Math.round((masukHadir / totalMasuk) * 100) 
    : 100;

  return (
    <div className="space-y-6">
      {/* Date & Class Controls */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              Dashboard Rekapitulasi Real-Time
            </h2>
            <span className="px-2 py-0.5 rounded text-xs font-bold bg-blue-100 text-blue-800">
              SMPN 1 Kalipare
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Pantau kehadiran, kedisiplinan dan keaktifan ibadah siswa secara langsung
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
            <Calendar className="w-4 h-4 text-slate-500" />
            <input
              type="date"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              className="text-xs font-bold text-slate-800 bg-transparent focus:outline-none cursor-pointer"
            />
          </div>

          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="text-xs font-bold text-slate-800 bg-transparent focus:outline-none cursor-pointer"
            >
              <option value="ALL">Semua Kelas ({students.length} Siswa)</option>
              {SCHOOL_CLASSES.map(cls => (
                <option key={cls} value={cls}>Kelas {cls}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Primary KPI Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* Total Siswa */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold">Total Siswa</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-black text-slate-900 font-mono">
              {totalRelevantStudents}
            </div>
            <span className="text-[11px] text-slate-500">Terdaftar</span>
          </div>
          <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
            <div className="bg-blue-600 h-full w-full"></div>
          </div>
        </div>

        {/* Absen Masuk */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-emerald-600">
            <span className="text-xs font-semibold text-slate-700">Masuk Pagi</span>
            <LogIn className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-black text-emerald-700 font-mono">
              {totalMasuk}
            </div>
            <div className="flex items-center justify-between text-[11px] mt-0.5">
              <span className="text-emerald-700 font-bold">{masukHadir} tepat <span className="text-amber-600 font-medium">({masukTerlambat} telat)</span></span>
              <span className="text-rose-600 font-semibold">({Math.max(0, totalRelevantStudents - totalMasuk)} Alpa)</span>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
            <div 
              className="bg-emerald-500 h-full"
              style={{ width: `${attendanceRate}%` }}
            ></div>
          </div>
        </div>

        {/* Absen Pulang */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-blue-600">
            <span className="text-xs font-semibold text-slate-700">Pulang Sore</span>
            <LogOut className="w-4 h-4 text-blue-600" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-black text-blue-700 font-mono">
              {pulangHadir}
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-0.5">
              <span>{pulangHadir}/{totalRelevantStudents} terdata</span>
              <span className="text-slate-400">({Math.max(0, totalRelevantStudents - pulangHadir)} belum)</span>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
            <div 
              className="bg-blue-500 h-full"
              style={{ width: `${totalRelevantStudents > 0 ? (pulangHadir / totalRelevantStudents) * 100 : 0}%` }}
            ></div>
          </div>
        </div>

        {/* Sholat Dhuhur */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-amber-600">
            <span className="text-xs font-semibold text-slate-700">Sholat Dhuhur</span>
            <Sun className="w-4 h-4 text-amber-500" />
          </div>
          <div className="my-2">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-amber-700 font-mono">
                {dhuhurHadir}
              </span>
              {dhuhurHaid > 0 && (
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-pink-100 text-pink-800">
                  +{dhuhurHaid} Haid
                </span>
              )}
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-0.5">
              <span>{dhuhurHadir + dhuhurHaid}/{eligibleDhuhurStudents} terdata</span>
              <span className="text-rose-600 font-semibold">({Math.max(0, eligibleDhuhurStudents - dhuhurHadir - dhuhurHaid)} Alpa)</span>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
            <div 
              className="bg-amber-500 h-full"
              style={{ width: `${eligibleDhuhurStudents > 0 ? ((dhuhurHadir + dhuhurHaid) / eligibleDhuhurStudents) * 100 : 0}%` }}
            ></div>
          </div>
        </div>

        {/* Sholat Jumat (L) */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-indigo-600">
            <span className="text-xs font-semibold text-slate-700">Jumatan (L)</span>
            <Moon className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-black text-indigo-700 font-mono">
              {jumatHadir}
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span>{jumatHadir}/{eligibleJumatStudents} L</span>
              <span className="text-rose-600 font-semibold">({Math.max(0, eligibleJumatStudents - jumatHadir)} Alpa)</span>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
            <div 
              className="bg-indigo-500 h-full"
              style={{ width: `${eligibleJumatStudents > 0 ? (jumatHadir / eligibleJumatStudents) * 100 : 0}%` }}
            ></div>
          </div>
        </div>

        {/* Keputrian (P) */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-rose-600">
            <span className="text-xs font-semibold text-slate-700">Keputrian (P)</span>
            <HeartHandshake className="w-4 h-4 text-rose-500" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-black text-rose-700 font-mono">
              {keputrianHadir}
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span>{keputrianHadir}/{eligibleKeputrianStudents} P</span>
              <span className="text-rose-600 font-semibold">({Math.max(0, eligibleKeputrianStudents - keputrianHadir)} Alpa)</span>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
            <div 
              className="bg-rose-500 h-full"
              style={{ width: `${eligibleKeputrianStudents > 0 ? (keputrianHadir / eligibleKeputrianStudents) * 100 : 0}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Discipline & Class Comparison Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Discipline & Punctuality Gauges */}
        <div className="lg:col-span-5 bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 space-y-4">
          <h3 className="font-bold text-slate-900 text-sm sm:text-base flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500" />
            Indeks Kedisiplinan Siswa
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-4 text-center">
              <span className="text-xs font-bold text-emerald-900">Tingkat Kehadiran</span>
              <div className="text-3xl font-black text-emerald-700 my-1 font-mono">
                {attendanceRate}%
              </div>
              <p className="text-[11px] text-emerald-800">
                {totalMasuk} dari {totalRelevantStudents} Siswa Hadir
              </p>
            </div>

            <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-4 text-center">
              <span className="text-xs font-bold text-blue-900">Ketepatan Waktu</span>
              <div className="text-3xl font-black text-blue-700 my-1 font-mono">
                {onTimeRate}%
              </div>
              <p className="text-[11px] text-blue-800">
                Hadir sebelum 06:45 WIB
              </p>
            </div>
          </div>

          {/* Quick Insights List */}
          <div className="bg-slate-50 rounded-xl p-3.5 space-y-2 border border-slate-100 text-xs">
            <div className="flex items-center justify-between text-slate-700">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                Tepat Waktu Masuk:
              </span>
              <strong className="font-mono">{masukHadir} siswa ({totalMasuk > 0 ? Math.round((masukHadir/totalMasuk)*100) : 0}%)</strong>
            </div>
            <div className="flex items-center justify-between text-slate-700">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                Terlambat Masuk:
              </span>
              <strong className="font-mono text-amber-700">{masukTerlambat} siswa</strong>
            </div>
            <div className="flex items-center justify-between text-slate-700">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                Belum Terdata:
              </span>
              <strong className="font-mono text-rose-700">{Math.max(0, totalRelevantStudents - totalMasuk)} siswa</strong>
            </div>
          </div>

          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900">
            <strong>Catatan Petugas:</strong> Tanggal yang dipilih adalah <span className="font-bold underline">{formatIndoDate(targetDate)}</span>. Data diperbarui secara real-time dari Firestore setiap ada scan baru.
          </div>
        </div>

        {/* Right: Per-Class Attendance Comparison Bars */}
        <div className="lg:col-span-7 bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                Perbandingan Kehadiran Antar Kelas ({formatIndoDate(targetDate)})
              </h3>
              <p className="text-xs text-slate-500">
                Persentase siswa masuk tiap kelas (Kelas 7, 8, dan 9)
              </p>
            </div>
          </div>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
            {SCHOOL_CLASSES.map((cls) => {
              const classStudents = students.filter(s => s.className === cls);
              const totalInClass = classStudents.length;
              const classMasukRecords = records.filter(r => 
                r.date === targetDate && 
                r.className === cls && 
                r.type === 'masuk'
              );
              const countPresent = classMasukRecords.length;
              const percent = totalInClass > 0 ? Math.round((countPresent / totalInClass) * 100) : 0;

              return (
                <div key={cls} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-800">
                      Kelas {cls}
                    </span>
                    <span className="font-mono text-slate-500 text-[11px]">
                      {countPresent}/{totalInClass} ({percent}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden flex">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        percent >= 90 
                          ? 'bg-emerald-500' 
                          : percent >= 70 
                          ? 'bg-blue-500' 
                          : percent > 0 
                          ? 'bg-amber-500' 
                          : 'bg-slate-300'
                      }`}
                      style={{ width: `${percent}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
