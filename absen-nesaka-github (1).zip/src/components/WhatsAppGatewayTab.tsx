import React, { useState, useEffect } from 'react';
import { 
  MessageCircle, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  Save, 
  Settings2, 
  Smartphone, 
  Key, 
  ToggleLeft, 
  ToggleRight, 
  Sparkles, 
  RotateCcw,
  ExternalLink,
  HelpCircle,
  Eye,
  EyeOff,
  History,
  FileText,
  UserCheck,
  RefreshCw,
  PhoneCall,
  Calendar,
  Check,
  Trash2,
  Share2
} from 'lucide-react';
import { 
  WhatsAppConfig, 
  DEFAULT_WHATSAPP_CONFIG, 
  loadWhatsAppConfig, 
  saveWhatsAppConfig, 
  sendWhatsAppNotification,
  getWhatsAppDeliveryLogs,
  clearWhatsAppDeliveryLogs,
  WhatsAppDeliveryLog,
  checkFonnteStatus,
  FonnteConnectionStatus,
  formatTeacherAttendanceMessage,
  formatAttendanceRecapMessage,
  sanitizePhoneNumber
} from '../services/whatsappService';
import { Student, AttendanceRecord, SCHOOL_CLASSES } from '../data/studentsData';
import { getTodayDateStr } from '../services/attendanceService';

interface WhatsAppGatewayTabProps {
  students: Student[];
  records?: AttendanceRecord[];
}

export const WhatsAppGatewayTab: React.FC<WhatsAppGatewayTabProps> = ({ 
  students, 
  records = [] 
}) => {
  const [config, setConfig] = useState<WhatsAppConfig>(DEFAULT_WHATSAPP_CONFIG);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [showApiKey, setShowApiKey] = useState<boolean>(false);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);

  // Active sub-navigation
  const [activeSubTab, setActiveSubTab] = useState<'pengaturan' | 'rekap' | 'template' | 'riwayat'>('pengaturan');

  // Connection status state
  const [fonnteStatus, setFonnteStatus] = useState<FonnteConnectionStatus | null>(null);
  const [isCheckingStatus, setIsCheckingStatus] = useState<boolean>(false);

  // Test sender state
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  // Delivery logs state
  const [logs, setLogs] = useState<WhatsAppDeliveryLog[]>([]);

  // Recap sender state
  const todayStr = getTodayDateStr();
  const [recapDate, setRecapDate] = useState<string>(todayStr);
  const [recapClass, setRecapClass] = useState<string>('7 Kutai');
  const [recapType, setRecapType] = useState<string>('masuk');
  const [isSendingRecap, setIsSendingRecap] = useState<boolean>(false);
  const [recapResult, setRecapResult] = useState<{ success: boolean; message: string } | null>(null);

  // Active template editor tab
  const [activeTemplateTab, setActiveTemplateTab] = useState<'masuk' | 'pulang' | 'dhuhur' | 'jumat' | 'keputrian'>('masuk');

  useEffect(() => {
    loadWhatsAppConfig().then((cfg) => {
      setConfig(cfg);
      setIsLoading(false);
      handleRefreshConnectionStatus(cfg.apiKey);
    });
    setLogs(getWhatsAppDeliveryLogs());
  }, []);

  const handleRefreshConnectionStatus = async (overrideToken?: string) => {
    setIsCheckingStatus(true);
    try {
      const tokenToTest = overrideToken !== undefined ? overrideToken : config.apiKey;
      const status = await checkFonnteStatus(tokenToTest);
      setFonnteStatus(status);
    } catch {
      setFonnteStatus({
        configured: false,
        connected: false,
        message: 'Gagal memeriksa status koneksi Fonnte.'
      });
    } finally {
      setIsCheckingStatus(false);
    }
  };

  const handleSaveConfig = async () => {
    setIsSaving(true);
    const ok = await saveWhatsAppConfig(config);
    setIsSaving(false);
    if (ok) {
      setSaveStatus('Pengaturan WhatsApp Gateway berhasil disimpan ke Firebase Firestore!');
      handleRefreshConnectionStatus(config.apiKey);
    } else {
      setSaveStatus('Gagal menyimpan konfigurasi ke Firebase.');
    }
    setTimeout(() => setSaveStatus(null), 4000);
  };

  // Kirim Pesan Uji Coba ke Nomor Guru
  const handleSendTestToTeacher = async () => {
    if (!config.teacherPhone || !config.teacherPhone.trim()) {
      alert('Silakan masukkan Nomor WhatsApp Guru terlebih dahulu pada kolom pengaturan!');
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    const testTime = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    const testMsg = `📚 ABSENSI SISWA
SMP NEGERI 1 KALIPARE

Nama: ADIB ZAKI PRATAMA (Uji Coba Sistem)
Kelas: 7 Kutai
Tanggal: ${todayStr}
Jam: ${testTime} WIB
Status: HADIR

Data berhasil tersimpan dalam database absensi.
(Pesan tes verifikasi Fonnte WhatsApp Gateway)`;

    const res = await sendWhatsAppNotification(
      config.teacherPhone,
      testMsg,
      config,
      {
        studentName: 'ADIB ZAKI PRATAMA',
        studentNis: '06694',
        className: '7 Kutai',
        type: 'test_guru',
        recipientRole: 'guru'
      }
    );

    setIsTesting(false);
    setTestResult(res);
    setLogs(getWhatsAppDeliveryLogs());
  };

  // Hitung Data Rekapitulasi Berdasarkan Tanggal & Kelas Terpilih
  const targetStudents = recapClass === 'ALL'
    ? students
    : students.filter(s => s.className === recapClass);

  const filteredRecords = records.filter(r => 
    r.date === recapDate && 
    r.type === recapType &&
    (recapClass === 'ALL' || r.className === recapClass)
  );

  const hadirRecords = filteredRecords.filter(r => r.status === 'hadir' || r.status === 'terlambat');
  const izinRecords = filteredRecords.filter(r => r.status === 'izin');
  const sakitRecords = filteredRecords.filter(r => r.status === 'sakit');

  const attendedNisSet = new Set(filteredRecords.map(r => r.studentNis));
  const unattendedStudents = targetStudents
    .filter(s => !attendedNisSet.has(s.nis))
    .map(s => ({ name: s.name, nis: s.nis }));

  const generatedRecapText = formatAttendanceRecapMessage({
    date: recapDate,
    className: recapClass === 'ALL' ? 'Semua Kelas (SMPN 1 Kalipare)' : `Kelas ${recapClass}`,
    activityType: recapType,
    totalStudents: targetStudents.length,
    hadirCount: hadirRecords.length,
    izinCount: izinRecords.length,
    sakitCount: sakitRecords.length,
    alpaCount: unattendedStudents.length,
    unattendedStudents
  });

  // Kirim Rekapitulasi ke WhatsApp Guru
  const handleSendRecapToTeacher = async () => {
    if (!config.teacherPhone || !config.teacherPhone.trim()) {
      alert('Silakan masukkan Nomor WhatsApp Guru terlebih dahulu pada menu Pengaturan!');
      return;
    }

    setIsSendingRecap(true);
    setRecapResult(null);

    const res = await sendWhatsAppNotification(
      config.teacherPhone,
      generatedRecapText,
      config,
      {
        studentName: `Rekap ${recapClass}`,
        studentNis: '-',
        className: recapClass,
        type: `rekap_${recapType}`,
        recipientRole: 'rekap'
      }
    );

    setIsSendingRecap(false);
    setRecapResult(res);
    setLogs(getWhatsAppDeliveryLogs());
  };

  // Preview format guru
  const sampleStudent = students[0] || { name: 'ADIB ZAKI PRATAMA', nis: '06694', className: '7 Kutai' };
  const sampleTeacherMsg = formatTeacherAttendanceMessage(
    {
      id: 'demo',
      recordId: 'demo',
      studentNis: sampleStudent.nis,
      studentName: sampleStudent.name,
      className: sampleStudent.className,
      gender: 'L',
      date: todayStr,
      timeStr: '06:45:10',
      timestamp: new Date().toISOString(),
      type: 'masuk',
      status: 'hadir'
    },
    sampleStudent
  );

  return (
    <div className="space-y-6">
      {/* Toast Save Status */}
      {saveStatus && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2 shadow-xs animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{saveStatus}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-950 to-slate-900 text-white rounded-3xl p-6 shadow-md border border-emerald-700/50">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center shrink-0 text-emerald-300">
              <MessageCircle className="w-8 h-8" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl font-black tracking-tight">Fonnte WhatsApp Gateway</h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-400 text-slate-950">
                  Resmi: api.fonnte.com
                </span>
                {fonnteStatus?.connected ? (
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500 text-white flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span>
                    Perangkat Terhubung
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950">
                    {fonnteStatus?.configured ? 'Perangkat Belum Scan QR' : 'Belum Ada Token'}
                  </span>
                )}
              </div>
              <p className="text-xs text-emerald-100/80 mt-1 max-w-xl">
                Setiap kali siswa scan QR Code, sistem otomatis mengirimkan notifikasi ke Nomor WhatsApp Guru &amp; menyediakan pengiriman rekapitulasi kehadiran kelas.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleSaveConfig}
              disabled={isSaving}
              className="px-5 py-2.5 rounded-xl font-bold text-xs bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Menyimpan...' : 'Simpan Pengaturan'}</span>
            </button>
          </div>
        </div>

        {/* Sub-Tabs Navigation */}
        <div className="flex flex-wrap gap-2 pt-6 mt-6 border-t border-emerald-800/60">
          <button
            onClick={() => setActiveSubTab('pengaturan')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'pengaturan'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'bg-emerald-950/60 text-emerald-200 hover:bg-emerald-900/80'
            }`}
          >
            <Settings2 className="w-4 h-4" />
            <span>Pengaturan WhatsApp Guru</span>
          </button>

          <button
            onClick={() => setActiveSubTab('rekap')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'rekap'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'bg-emerald-950/60 text-emerald-200 hover:bg-emerald-900/80'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Rekapitulasi Otomatis via WA</span>
          </button>

          <button
            onClick={() => setActiveSubTab('template')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'template'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'bg-emerald-950/60 text-emerald-200 hover:bg-emerald-900/80'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Format Pesan &amp; Template</span>
          </button>

          <button
            onClick={() => {
              setActiveSubTab('riwayat');
              setLogs(getWhatsAppDeliveryLogs());
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'riwayat'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'bg-emerald-950/60 text-emerald-200 hover:bg-emerald-900/80'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Riwayat Pengiriman ({logs.length})</span>
          </button>
        </div>
      </div>

      {/* ============================================================ */}
      {/* SUB-TAB 1: PENGATURAN WHATSAPP GURU & STATUS FONNTE           */}
      {/* ============================================================ */}
      {activeSubTab === 'pengaturan' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left Column: Nomor WhatsApp Guru & Sakelar Notifikasi */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Form Nomor Guru & Otomatisasi */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 space-y-5">
              <div className="border-b border-slate-100 pb-3">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-emerald-600" />
                  Konfigurasi Nomor WhatsApp Guru &amp; Notifikasi Presensi
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Setiap kali siswa berhasil melakukan scan barcode, sistem otomatis mengirimkan pesan konfirmasi ke nomor guru ini.
                </p>
              </div>

              {/* Input Nomor Guru */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Nomor WhatsApp Guru / Petugas Piket:
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    value={config.teacherPhone}
                    onChange={(e) => setConfig({ ...config, teacherPhone: e.target.value })}
                    placeholder="Contoh: 081234567890 atau 6281234567890"
                    className="w-full pl-9 pr-3 py-2.5 text-xs font-mono font-semibold bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  <PhoneCall className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
                {fonnteStatus?.device && config.teacherPhone !== fonnteStatus.device && (
                  <button
                    type="button"
                    onClick={() => setConfig({ ...config, teacherPhone: fonnteStatus.device || '' })}
                    className="text-[11px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <span>📲 Gunakan Nomor Terhubung di Fonnte:</span>
                    <span className="font-mono">{fonnteStatus.device}</span>
                  </button>
                )}
                {config.teacherPhone && (
                  <p className="text-[11px] text-emerald-700 font-mono font-medium">
                    Standar Pengiriman: {sanitizePhoneNumber(config.teacherPhone)}
                  </p>
                )}
              </div>

              {/* Toggle Switches */}
              <div className="space-y-3 pt-2">
                {/* 1. Toggle Guru */}
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">
                      Notifikasi Otomatis ke Nomor Guru (Wajib)
                    </span>
                    <span className="text-[11px] text-slate-500 block leading-tight mt-0.5">
                      Kirim pesan langsung ke WhatsApp Guru setiap kali siswa berhasil scan QR / barcode.
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setConfig({ 
                      ...config, 
                      teacherNotificationEnabled: !config.teacherNotificationEnabled 
                    })}
                    className="text-emerald-600 focus:outline-none cursor-pointer"
                  >
                    {config.teacherNotificationEnabled ? (
                      <ToggleRight className="w-9 h-9 text-emerald-600 fill-emerald-100" />
                    ) : (
                      <ToggleLeft className="w-9 h-9 text-slate-400" />
                    )}
                  </button>
                </div>

                {/* 2. Toggle Wali Murid */}
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">
                      Notifikasi ke Wali Murid
                    </span>
                    <span className="text-[11px] text-slate-500 block leading-tight mt-0.5">
                      Jika siswa memiliki nomor orang tua di database, kirimkan juga pesan konfirmasi kehadiran ke orang tua.
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setConfig({ 
                      ...config, 
                      notifyParentEnabled: !config.notifyParentEnabled 
                    })}
                    className="text-emerald-600 focus:outline-none cursor-pointer"
                  >
                    {config.notifyParentEnabled ? (
                      <ToggleRight className="w-9 h-9 text-emerald-600 fill-emerald-100" />
                    ) : (
                      <ToggleLeft className="w-9 h-9 text-slate-400" />
                    )}
                  </button>
                </div>

                {/* 3. Master Auto-Send On Scan */}
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">
                      Kirim Otomatis Saat Scan (Zero-Click)
                    </span>
                    <span className="text-[11px] text-slate-500 block leading-tight mt-0.5">
                      Sistem langsung mengirim pesan di latar belakang tanpa menuntut konfirmasi klik dari petugas.
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setConfig({ 
                      ...config, 
                      autoSendOnScan: !config.autoSendOnScan 
                    })}
                    className="text-emerald-600 focus:outline-none cursor-pointer"
                  >
                    {config.autoSendOnScan ? (
                      <ToggleRight className="w-9 h-9 text-emerald-600 fill-emerald-100" />
                    ) : (
                      <ToggleLeft className="w-9 h-9 text-slate-400" />
                    )}
                  </button>
                </div>
              </div>

              {/* Action Buttons: Simpan & Test Kirim WhatsApp */}
              <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleSaveConfig}
                  disabled={isSaving}
                  className="px-5 py-2.5 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs flex items-center gap-2 cursor-pointer transition-colors disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSaving ? 'Menyimpan...' : 'Simpan Nomor Guru'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSendTestToTeacher}
                  disabled={isTesting || !config.teacherPhone}
                  className="px-5 py-2.5 rounded-xl font-bold text-xs bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-xs flex items-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{isTesting ? 'Mengirim Pesan Tes...' : 'TEST KIRIM WHATSAPP KE GURU'}</span>
                </button>
              </div>

              {/* Test Result Notice */}
              {testResult && (
                <div className={`p-3.5 rounded-xl text-xs font-bold flex items-center gap-2.5 border ${
                  testResult.success
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                    : 'bg-rose-50 border-rose-200 text-rose-900'
                }`}>
                  {testResult.success ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                  )}
                  <span>{testResult.message}</span>
                </div>
              )}
            </div>

            {/* Token Fonnte Configuration (Server Secret Isolated) */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 space-y-4">
              <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Key className="w-4 h-4 text-blue-600" />
                    Kunci Token API Fonnte (Server-Side)
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Token diambil dari environment variable <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-[11px] text-blue-700">FONNTE_TOKEN</code> di server.
                  </p>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                  Aman &amp; Terisolasi
                </span>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Ubah / Input Token Fonnte (Jika Belum Ada di Server Secret):
                </label>
                <div className="relative">
                  <input
                    type={showApiKey ? 'text' : 'password'}
                    value={config.apiKey}
                    onChange={(e) => setConfig({ ...config, apiKey: e.target.value })}
                    placeholder={fonnteStatus?.maskedToken ? `Token aktif: ${fonnteStatus.maskedToken}` : 'Tempel Token Fonnte dari akun fonnte.com...'}
                    className="w-full pl-3 pr-9 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                  >
                    {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Semua permintaan API Fonnte dieksekusi secara server-side melalui endpoint resmi <code className="font-mono text-emerald-700 font-bold">https://api.fonnte.com/send</code>. Token tidak pernah dibagikan kepada browser klien.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Status Koneksi Fonnte & Device Card */}
          <div className="space-y-6">
            
            {/* Status Koneksi Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <RefreshCw className={`w-4 h-4 text-emerald-600 ${isCheckingStatus ? 'animate-spin' : ''}`} />
                  Status Koneksi Fonnte
                </h3>
                <button
                  type="button"
                  onClick={() => handleRefreshConnectionStatus()}
                  disabled={isCheckingStatus}
                  className="text-xs font-bold text-emerald-600 hover:text-emerald-700 p-1 hover:bg-emerald-50 rounded-lg flex items-center gap-1 cursor-pointer"
                  title="Periksa Ulang Status Koneksi"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh</span>
                </button>
              </div>

              {/* Status Badge Indicator */}
              <div className={`p-4 rounded-xl border flex items-center gap-3 ${
                fonnteStatus?.connected
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                  : fonnteStatus?.configured
                  ? 'bg-amber-50 border-amber-200 text-amber-950'
                  : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}>
                <div className={`w-3.5 h-3.5 rounded-full shrink-0 ${
                  fonnteStatus?.connected 
                    ? 'bg-emerald-500 animate-pulse' 
                    : fonnteStatus?.configured 
                    ? 'bg-amber-500' 
                    : 'bg-slate-400'
                }`} />
                <div>
                  <div className="text-xs font-bold">
                    {fonnteStatus?.connected 
                      ? 'Fonnte Gateway Terhubung' 
                      : fonnteStatus?.configured 
                      ? 'Token Terdaftar (Perangkat Disconnect)' 
                      : 'Belum Terhubung'}
                  </div>
                  <div className="text-[11px] mt-0.5 leading-tight">
                    {fonnteStatus?.message || 'Memeriksa status perangkat...'}
                  </div>
                </div>
              </div>

              {/* Device Details */}
              <div className="space-y-2 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200 font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 text-[11px]">Token Server:</span>
                  <span className="font-bold text-slate-800">
                    {fonnteStatus?.maskedToken || 'Belum diisi'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 text-[11px]">Nama Perangkat:</span>
                  <span className="font-bold text-slate-800">
                    {fonnteStatus?.name || '-'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 text-[11px]">Nomor WhatsApp:</span>
                  <span className="font-bold text-slate-800">
                    {fonnteStatus?.device || '-'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 text-[11px]">Device Status:</span>
                  <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                    fonnteStatus?.connected ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {fonnteStatus?.device_status || 'unconnected'}
                  </span>
                </div>
              </div>

              {/* Cara Koneksi Fonnte */}
              <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-blue-900 space-y-1.5">
                <span className="font-bold block flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
                  Cara Menghubungkan WhatsApp Guru:
                </span>
                <ol className="text-[11px] text-slate-600 list-decimal pl-4 space-y-1">
                  <li>Buka website <b>fonnte.com</b> dan login akun.</li>
                  <li>Di menu <b>Device</b>, scan kode QR dengan WhatsApp Anda.</li>
                  <li>Salin <b>Token</b> dan tempelkan ke kolom token di samping.</li>
                </ol>
                <a
                  href="https://fonnte.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-600 hover:text-blue-800 mt-1"
                >
                  <span>Buka Website Fonnte</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            {/* Quick Stats Summary */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 space-y-3">
              <h3 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-600" />
                Ringkasan Siap Kirim
              </h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-600">Nomor WhatsApp Guru:</span>
                  <span className="font-mono font-bold text-slate-900">
                    {config.teacherPhone || 'Belum diisi'}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-600">Notifikasi Guru:</span>
                  <span className={`font-bold ${config.teacherNotificationEnabled ? 'text-emerald-600' : 'text-slate-400'}`}>
                    {config.teacherNotificationEnabled ? 'AKTIF' : 'NONAKTIF'}
                  </span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-600">Total Siswa Terdaftar:</span>
                  <span className="font-mono font-bold text-slate-900">{students.length} Siswa</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* SUB-TAB 2: REKAPITULASI OTOMATIS VIA WHATSAPP                */}
      {/* ============================================================ */}
      {activeSubTab === 'rekap' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Form Pengiriman Rekap */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 space-y-5">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-600" />
                Pengiriman Rekapitulasi Presensi ke WhatsApp Guru
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Pilih tanggal, kelas, dan sesi absensi untuk menyusun laporan rekapitulasi real-time dari Firebase Firestore dan mengirimkannya ke WhatsApp guru.
              </p>
            </div>

            {/* Filter Tanggal, Kelas & Sesi */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Pilih Tanggal:
                </label>
                <div className="relative">
                  <input
                    type="date"
                    value={recapDate}
                    onChange={(e) => setRecapDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Pilih Kelas:
                </label>
                <select
                  value={recapClass}
                  onChange={(e) => setRecapClass(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="ALL">Semua Kelas ({students.length} Siswa)</option>
                  {SCHOOL_CLASSES.map(cls => (
                    <option key={cls} value={cls}>
                      Kelas {cls} ({students.filter(s => s.className === cls).length} Siswa)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Sesi Presensi:
                </label>
                <select
                  value={recapType}
                  onChange={(e) => setRecapType(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="masuk">Presensi Masuk</option>
                  <option value="pulang">Presensi Pulang</option>
                  <option value="dhuhur">Sholat Dhuhur Berjamaah</option>
                  <option value="jumat">Sholat Jumat Berjamaah</option>
                  <option value="keputrian">Bimbingan Keputrian</option>
                </select>
              </div>
            </div>

            {/* Rekapitulasi Summary Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-bold text-slate-500 block">Total Siswa</span>
                <span className="text-lg font-black text-slate-900 font-mono">{targetStudents.length}</span>
              </div>
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                <span className="text-[10px] font-bold text-emerald-800 block">Hadir</span>
                <span className="text-lg font-black text-emerald-800 font-mono">{hadirRecords.length}</span>
              </div>
              <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
                <span className="text-[10px] font-bold text-blue-800 block">Izin / Sakit</span>
                <span className="text-lg font-black text-blue-800 font-mono">{izinRecords.length + sakitRecords.length}</span>
              </div>
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
                <span className="text-[10px] font-bold text-amber-800 block">Belum Absen</span>
                <span className="text-lg font-black text-amber-800 font-mono">{unattendedStudents.length}</span>
              </div>
            </div>

            {/* List Siswa Belum Absen */}
            {unattendedStudents.length > 0 && (
              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-xs space-y-1.5 max-h-36 overflow-y-auto">
                <span className="font-bold text-amber-900 block flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5" />
                  Daftar Siswa Belum Absen ({unattendedStudents.length} siswa):
                </span>
                <div className="text-[11px] text-slate-700 divide-y divide-amber-100">
                  {unattendedStudents.map((s, idx) => (
                    <div key={s.nis} className="py-0.5 flex justify-between">
                      <span>{idx + 1}. {s.name}</span>
                      <span className="font-mono text-slate-500">{s.nis}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action Kirim Rekap */}
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600">Nomor Tujuan Pengiriman:</span>
                <span className="font-mono font-bold text-slate-900">
                  {config.teacherPhone || 'Belum diatur'}
                </span>
              </div>

              <button
                type="button"
                onClick={handleSendRecapToTeacher}
                disabled={isSendingRecap || !config.teacherPhone}
                className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>
                  {isSendingRecap 
                    ? 'Sedang Mengirim Rekapitulasi via Fonnte...' 
                    : `KIRIM REKAP KE WHATSAPP GURU (${config.teacherPhone || 'Atur No HP Dahulu'})`}
                </span>
              </button>
            </div>

            {/* Rekap Result Notice */}
            {recapResult && (
              <div className={`p-3.5 rounded-xl text-xs font-bold flex items-center gap-2.5 border ${
                recapResult.success
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}>
                {recapResult.success ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                )}
                <span>{recapResult.message}</span>
              </div>
            )}
          </div>

          {/* Live Preview Pesan Rekap WhatsApp */}
          <div className="bg-slate-900 rounded-2xl p-6 text-white space-y-4 shadow-sm border border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></div>
                <h4 className="font-bold text-xs text-emerald-400">Preview Pesan WhatsApp Rekapitulasi</h4>
              </div>
              <span className="text-[10px] text-slate-400">Live Generated</span>
            </div>

            {/* Chat Bubble Container */}
            <div className="bg-[#0b141a] p-4 rounded-2xl border border-emerald-950 font-sans">
              <div className="bg-[#005c4b] text-[#e9edef] p-3.5 rounded-2xl text-xs leading-relaxed max-w-md shadow-md ml-auto whitespace-pre-wrap font-sans">
                {generatedRecapText}
                <div className="text-[10px] text-emerald-200/60 text-right mt-1.5 flex items-center justify-end gap-1 font-mono">
                  <span>{new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}</span>
                  <span>✓✓</span>
                </div>
              </div>
            </div>

            <p className="text-[11px] text-slate-400">
              Format ini dirancang khusus agar rapi dan mudah dibaca langsung dari layar HP guru maupun dibagikan ke grup wali kelas.
            </p>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* SUB-TAB 3: FORMAT & TEMPLATE PESAN                           */}
      {/* ============================================================ */}
      {activeSubTab === 'template' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Format Pesan Guru (Sesuai Spesifikasi Wajib Prompt) */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800">
                  WAJIB (PROMPT)
                </span>
                <h3 className="text-sm font-bold text-slate-900">
                  Format Notifikasi WhatsApp Guru
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Format standar yang dikirim otomatis ke nomor guru setiap siswa berhasil absen:
              </p>
            </div>

            {/* Bubble Preview Format Guru */}
            <div className="bg-slate-900 p-4 rounded-2xl text-white">
              <div className="bg-[#005c4b] text-[#e9edef] p-3.5 rounded-2xl text-xs leading-relaxed max-w-sm ml-auto whitespace-pre-wrap font-sans shadow-md">
                {sampleTeacherMsg}
                <div className="text-[10px] text-emerald-200/60 text-right mt-1.5 flex items-center justify-end gap-1 font-mono">
                  <span>06:45</span>
                  <span>✓✓</span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 space-y-1">
              <span className="font-bold block flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                Ketentuan Keamanan &amp; Integritas:
              </span>
              <ul className="text-[11px] text-slate-700 list-disc pl-4 space-y-0.5">
                <li>Pesan hanya dikirim <b>setelah data absensi berhasil tersimpan</b> di Firebase Firestore.</li>
                <li>Dilengkapi <b>mekanisme anti-duplikasi</b> (mencegah pesan ganda untuk 1 transaksi absensi).</li>
                <li>Tidak mengirim pesan apabila penyimpanan absensi gagal.</li>
              </ul>
            </div>
          </div>

          {/* Format Pesan Orang Tua Murid */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 space-y-4">
            <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Format Pesan untuk Wali Murid
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Template per sesi kehadiran siswa
                </p>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                Tersedia 5 Sesi
              </span>
            </div>

            {/* Sesi selector */}
            <div className="flex flex-wrap gap-1.5">
              {(['masuk', 'pulang', 'dhuhur', 'jumat', 'keputrian'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setActiveTemplateTab(tab)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all capitalize cursor-pointer ${
                    activeTemplateTab === tab
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {tab === 'dhuhur' ? 'Sholat Dhuhur' : tab === 'jumat' ? 'Sholat Jumat' : tab}
                </button>
              ))}
            </div>

            {/* Template editor */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 block">
                Isi Template ({activeTemplateTab.toUpperCase()}):
              </label>
              <textarea
                rows={9}
                value={
                  activeTemplateTab === 'masuk' ? config.templateMasuk :
                  activeTemplateTab === 'pulang' ? config.templatePulang :
                  activeTemplateTab === 'dhuhur' ? config.templateDhuhur :
                  activeTemplateTab === 'jumat' ? config.templateJumat : config.templateKeputrian
                }
                onChange={(e) => {
                  const val = e.target.value;
                  if (activeTemplateTab === 'masuk') setConfig({ ...config, templateMasuk: val });
                  else if (activeTemplateTab === 'pulang') setConfig({ ...config, templatePulang: val });
                  else if (activeTemplateTab === 'dhuhur') setConfig({ ...config, templateDhuhur: val });
                  else if (activeTemplateTab === 'jumat') setConfig({ ...config, templateJumat: val });
                  else setConfig({ ...config, templateKeputrian: val });
                }}
                className="w-full p-3 text-xs font-mono bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400 block">
                Tag dinamis: {'{nama}'}, {'{nis}'}, {'{kelas}'}, {'{tanggal}'}, {'{waktu}'}, {'{status}'}, {'{kegiatan}'}
              </span>
            </div>

            <button
              type="button"
              onClick={handleSaveConfig}
              className="px-4 py-2 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              Simpan Perubahan Template
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* SUB-TAB 4: RIWAYAT PENGIRIMAN PESAN (DELIVERY LOGS)          */}
      {/* ============================================================ */}
      {activeSubTab === 'riwayat' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <History className="w-4 h-4 text-emerald-600" />
                Riwayat Pengiriman Pesan WhatsApp (Fonnte API Logs)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Mencatat seluruh notifikasi yang dikirim ke Guru maupun Wali Murid beserta status keberhasilan API.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setLogs(getWhatsAppDeliveryLogs())}
                className="px-3 py-1.5 text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Refresh Log</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (confirm('Hapus seluruh riwayat pengiriman pesan?')) {
                    clearWhatsAppDeliveryLogs();
                    setLogs([]);
                  }
                }}
                className="px-3 py-1.5 text-xs font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Kosongkan Log</span>
              </button>
            </div>
          </div>

          {/* Tabel Log */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3 font-bold w-36">Waktu</th>
                  <th className="py-2.5 px-3 font-bold w-24">Penerima</th>
                  <th className="py-2.5 px-3 font-bold w-32">Nomor Tujuan</th>
                  <th className="py-2.5 px-3 font-bold">Siswa / Topik</th>
                  <th className="py-2.5 px-3 font-bold w-24 text-center">Status</th>
                  <th className="py-2.5 px-3 font-bold">Respons Fonnte</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {logs.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      Belum ada riwayat pengiriman pesan WhatsApp. Lakukan scan barcode atau kirim pesan tes untuk melihat log.
                    </td>
                  </tr>
                ) : (
                  logs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-2.5 px-3 text-slate-600 font-mono text-[11px]">
                        {log.timestamp}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.recipientRole === 'guru' ? 'bg-blue-100 text-blue-800' :
                          log.recipientRole === 'rekap' ? 'bg-purple-100 text-purple-800' :
                          log.recipientRole === 'uji_coba' ? 'bg-amber-100 text-amber-800' :
                          'bg-emerald-100 text-emerald-800'
                        }`}>
                          {log.recipientRole === 'guru' ? 'Guru' :
                           log.recipientRole === 'rekap' ? 'Rekap' :
                           log.recipientRole === 'uji_coba' ? 'Uji Coba' : 'Wali Murid'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono font-semibold text-slate-800">
                        {log.phone}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-slate-900">{log.studentName}</div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {log.className} {log.studentNis !== '-' && `• NIS: ${log.studentNis}`}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.status === 'sent' 
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}>
                          {log.status === 'sent' ? '✓ Terkirim' : '✕ Gagal'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 text-[11px]">
                        {log.responseMsg || '-'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
