import React, { useState, useMemo } from 'react';
import { 
  FileSpreadsheet, 
  FileText, 
  Download, 
  Calendar, 
  Filter, 
  Search, 
  CheckCircle, 
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { Student, AttendanceRecord, SCHOOL_CLASSES, AttendanceType } from '../data/studentsData';
import { getTodayDateStr, formatIndoDate } from '../services/attendanceService';
import { exportToExcel, exportToPDF } from '../utils/exportUtils';

interface RekapitulasiTabProps {
  students: Student[];
  records: AttendanceRecord[];
}

type PeriodMode = 'harian' | 'mingguan' | 'bulanan' | 'tengah_semester' | 'semester' | 'custom';

export const RekapitulasiTab: React.FC<RekapitulasiTabProps> = ({ students, records }) => {
  const todayStr = getTodayDateStr();

  const [periodMode, setPeriodMode] = useState<PeriodMode>('harian');
  const [singleDate, setSingleDate] = useState<string>(todayStr);
  const [startDate, setStartDate] = useState<string>(todayStr);
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [selectedClass, setSelectedClass] = useState<string>('ALL');
  const [selectedGender, setSelectedGender] = useState<'ALL' | 'L' | 'P'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSemester, setSelectedSemester] = useState<'smt1' | 'smt2'>('smt1');
  const [selectedTriwulan, setSelectedTriwulan] = useState<'triwulan1' | 'triwulan2' | 'triwulan3' | 'triwulan4'>('triwulan1');

  // Compute active date range based on periodMode
  const { effectiveStart, effectiveEnd, labelPeriode } = useMemo(() => {
    if (periodMode === 'harian') {
      return {
        effectiveStart: singleDate,
        effectiveEnd: singleDate,
        labelPeriode: formatIndoDate(singleDate)
      };
    }

    if (periodMode === 'mingguan') {
      const d = new Date();
      d.setDate(d.getDate() - 7);
      const start = d.toISOString().slice(0, 10);
      return {
        effectiveStart: start,
        effectiveEnd: todayStr,
        labelPeriode: `7 Hari Terakhir (${formatIndoDate(start)} s/d ${formatIndoDate(todayStr)})`
      };
    }

    if (periodMode === 'bulanan') {
      const now = new Date();
      const y = now.getFullYear();
      const m = String(now.getMonth() + 1).padStart(2, '0');
      const start = `${y}-${m}-01`;
      return {
        effectiveStart: start,
        effectiveEnd: todayStr,
        labelPeriode: `Bulan ${now.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' })}`
      };
    }

    if (periodMode === 'tengah_semester') {
      const y = new Date().getFullYear();
      if (selectedTriwulan === 'triwulan1') {
        return {
          effectiveStart: `${y}-07-01`,
          effectiveEnd: `${y}-09-30`,
          labelPeriode: `Tengah Semester 1 / STS Ganjil (Juli - September ${y})`
        };
      } else if (selectedTriwulan === 'triwulan2') {
        return {
          effectiveStart: `${y}-10-01`,
          effectiveEnd: `${y}-12-31`,
          labelPeriode: `Akhir Semester 1 / PAS Ganjil (Oktober - Desember ${y})`
        };
      } else if (selectedTriwulan === 'triwulan3') {
        return {
          effectiveStart: `${y}-01-01`,
          effectiveEnd: `${y}-03-31`,
          labelPeriode: `Tengah Semester 2 / STS Genap (Januari - Maret ${y})`
        };
      } else {
        return {
          effectiveStart: `${y}-04-01`,
          effectiveEnd: `${y}-06-30`,
          labelPeriode: `Akhir Semester 2 / PAT Genap (April - Juni ${y})`
        };
      }
    }

    if (periodMode === 'semester') {
      const y = new Date().getFullYear();
      if (selectedSemester === 'smt1') {
        return {
          effectiveStart: `${y}-07-01`,
          effectiveEnd: `${y}-12-31`,
          labelPeriode: `Semester Ganjil ${y}/${y + 1} (Juli - Des ${y})`
        };
      } else {
        return {
          effectiveStart: `${y}-01-01`,
          effectiveEnd: `${y}-06-30`,
          labelPeriode: `Semester Genap ${y} (Jan - Juni ${y})`
        };
      }
    }

    return {
      effectiveStart: startDate,
      effectiveEnd: endDate,
      labelPeriode: `${formatIndoDate(startDate)} s/d ${formatIndoDate(endDate)}`
    };
  }, [periodMode, singleDate, startDate, endDate, todayStr, selectedSemester, selectedTriwulan]);

  // Filter records within the date range
  const relevantRecords = useMemo(() => {
    return records.filter(r => r.date >= effectiveStart && r.date <= effectiveEnd);
  }, [records, effectiveStart, effectiveEnd]);

  // Filter students based on Class, Gender, and Query
  const filteredStudents = useMemo(() => {
    return students.filter(st => {
      const matchesClass = selectedClass === 'ALL' || st.className === selectedClass;
      const matchesGender = selectedGender === 'ALL' || st.gender === selectedGender;
      const matchesQuery = !searchQuery.trim() || 
        st.nis.toLowerCase().includes(searchQuery.toLowerCase()) ||
        st.name.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesClass && matchesGender && matchesQuery;
    });
  }, [students, selectedClass, selectedGender, searchQuery]);

  // Build attendance lookup for fast rendering
  const attendanceLookup = useMemo(() => {
    const map = new Map<string, AttendanceRecord[]>();
    for (const r of relevantRecords) {
      const key = `${r.studentNis}_${r.type}`;
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(r);
    }
    return map;
  }, [relevantRecords]);

  const getStudentStatusBadge = (st: Student, type: AttendanceType) => {
    // CRITICAL: Special rule for Jevanya and Diva Widiana
    if (st.exemptReligious && (type === 'dhuhur' || type === 'jumat' || type === 'keputrian')) {
      return (
        <span className="text-slate-400 font-mono font-bold" title="Dikecualikan (Non-Muslim)">
          -
        </span>
      );
    }

    // Gender check
    if (type === 'jumat' && st.gender !== 'L') {
      return <span className="text-slate-400 font-mono">-</span>;
    }
    if (type === 'keputrian' && st.gender !== 'P') {
      return <span className="text-slate-400 font-mono">-</span>;
    }

    const recs = attendanceLookup.get(`${st.nis}_${type}`);
    if (!recs || recs.length === 0) {
      return (
        <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
          Alpa
        </span>
      );
    }

    const latest = recs[recs.length - 1];
    if (periodMode === 'harian') {
      if (latest.status === 'hadir') {
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
            Hadir ({latest.timeStr.slice(0, 5)})
          </span>
        );
      }
      if (latest.status === 'terlambat') {
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900">
            Telat ({latest.timeStr.slice(0, 5)})
          </span>
        );
      }
      if (latest.status === 'haid') {
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-pink-100 text-pink-800 border border-pink-300">
            Haid
          </span>
        );
      }
      if (latest.status === 'izin' || latest.status === 'sakit') {
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800 capitalize">
            {latest.status}
          </span>
        );
      }
      if (latest.status === 'alpa') {
        return (
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
            Alpa
          </span>
        );
      }
    }

    // For multi-day period, show count with Haid breakdown if present
    const haidCount = recs.filter(r => r.status === 'haid').length;
    const hadirCount = recs.filter(r => r.status === 'hadir' || r.status === 'terlambat').length;
    if (haidCount > 0) {
      return (
        <span className="inline-flex items-center gap-1">
          {hadirCount > 0 && (
            <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-900 font-mono">
              {hadirCount}x Hadir
            </span>
          )}
          <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-pink-100 text-pink-800 border border-pink-200 font-mono">
            {haidCount}x Haid
          </span>
        </span>
      );
    }

    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-900 font-mono">
        {recs.length}x Hadir
      </span>
    );
  };

  const handleExportExcel = () => {
    exportToExcel({
      students: filteredStudents,
      records: relevantRecords,
      dateRangeStr: labelPeriode,
      className: selectedClass === 'ALL' ? 'Semua Kelas' : selectedClass
    });
  };

  const handleExportPDF = () => {
    exportToPDF({
      students: filteredStudents,
      records: relevantRecords,
      dateRangeStr: labelPeriode,
      className: selectedClass === 'ALL' ? 'Semua Kelas' : selectedClass
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Card: Period Filter & Export Action Buttons */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
              Rekapitulasi Kehadiran &amp; Laporan Kedisiplinan
            </h2>
            <p className="text-xs text-slate-500">
              Pilih periode rentang tanggal dan unduh dokumen resmi format PDF atau Excel (.xlsx)
            </p>
          </div>

          {/* Export Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleExportExcel}
              className="flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Unduh Excel (.xlsx)</span>
            </button>

            <button
              onClick={handleExportPDF}
              className="flex items-center gap-2 px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              <span>Unduh PDF Resmi</span>
            </button>
          </div>
        </div>

        {/* Period Preset Tabs: Harian, Mingguan, Bulanan, Tengah Semester (3 Bulan), Semesteran, Custom */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl w-fit">
          {[
            { id: 'harian', label: 'Harian' },
            { id: 'mingguan', label: 'Mingguan (7 Hari)' },
            { id: 'bulanan', label: 'Bulanan' },
            { id: 'tengah_semester', label: 'Tengah Semester (3 Bulan)' },
            { id: 'semester', label: 'Persemester (6 Bulan)' },
            { id: 'custom', label: 'Rentang Bebas' },
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => setPeriodMode(mode.id as PeriodMode)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                periodMode === mode.id
                  ? 'bg-white text-slate-950 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>

        {/* Date Controls depending on active preset */}
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60 flex flex-wrap items-center gap-3 text-xs">
          {periodMode === 'harian' && (
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-700">Pilih Tanggal:</span>
              <input
                type="date"
                value={singleDate}
                onChange={(e) => setSingleDate(e.target.value)}
                className="bg-white border border-slate-200 px-3 py-1.5 rounded-lg font-bold text-slate-800"
              />
            </div>
          )}

          {periodMode === 'tengah_semester' && (
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-700">Pilih Periode 3 Bulan:</span>
              <select
                value={selectedTriwulan}
                onChange={(e) => setSelectedTriwulan(e.target.value as any)}
                className="bg-white border border-slate-200 px-3 py-1.5 rounded-lg font-bold text-slate-800"
              >
                <option value="triwulan1">Triwulan 1: Juli - September (Tengah Smt 1 / STS)</option>
                <option value="triwulan2">Triwulan 2: Oktober - Desember (Akhir Smt 1 / PAS)</option>
                <option value="triwulan3">Triwulan 3: Januari - Maret (Tengah Smt 2 / STS)</option>
                <option value="triwulan4">Triwulan 4: April - Juni (Akhir Smt 2 / PAT)</option>
              </select>
            </div>
          )}

          {periodMode === 'semester' && (
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-700">Pilih Semester:</span>
              <select
                value={selectedSemester}
                onChange={(e) => setSelectedSemester(e.target.value as any)}
                className="bg-white border border-slate-200 px-3 py-1.5 rounded-lg font-bold text-slate-800"
              >
                <option value="smt1">Semester Ganjil (Juli - Desember)</option>
                <option value="smt2">Semester Genap (Januari - Juni)</option>
              </select>
            </div>
          )}

          {periodMode === 'custom' && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-bold text-slate-700">Dari:</span>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="bg-white border border-slate-200 px-3 py-1.5 rounded-lg font-bold text-slate-800"
              />
              <span className="font-bold text-slate-700">Sampai:</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="bg-white border border-slate-200 px-3 py-1.5 rounded-lg font-bold text-slate-800"
              />
            </div>
          )}

          <div className="ml-auto text-slate-600">
            Periode Aktif: <strong className="text-slate-900">{labelPeriode}</strong>
          </div>
        </div>

        {/* Secondary Filters: Class, Gender, Search */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-100">
          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Filter Kelas:
            </label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="ALL">Semua Kelas ({students.length} Siswa)</option>
              {SCHOOL_CLASSES.map(cls => (
                <option key={cls} value={cls}>Kelas {cls}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Filter Jenis Kelamin:
            </label>
            <select
              value={selectedGender}
              onChange={(e) => setSelectedGender(e.target.value as any)}
              className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="ALL">Semua (Laki-laki &amp; Perempuan)</option>
              <option value="L">Khusus Laki-laki (L)</option>
              <option value="P">Khusus Perempuan (P)</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Cari Nama atau NIS:
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="Cari nama siswa..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>
        </div>
      </div>

      {/* Special Rule Reminder Pill */}
      <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-3 flex items-center justify-between text-xs text-amber-900">
        <div className="flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
          <span>
            <strong>Catatan Aturan Khusus:</strong> Kolom Sholat Dhuhur, Sholat Jumat, dan Keputrian untuk <span className="font-bold underline">Maximilianus Wahyu Galih Pradana (7 Kutai)</span>, <span className="font-bold underline">Diva Widiana (7 Mataram)</span>, dan <span className="font-bold underline">Jevanya Anastasya Blegur (9 Mataram)</span> dikosongi / bernilai (-) sesuai dengan ketentuan siswa non-muslim.
          </span>
        </div>
        <span className="font-bold text-[11px] bg-white px-2 py-0.5 rounded border border-amber-300">
          Dikecualikan
        </span>
      </div>

      {/* Main Rekap Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-slate-900 text-sm">
              Tabel Rekapitulasi Siswa ({filteredStudents.length} Siswa Terdaftar)
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            {relevantRecords.length} Log Presensi Terdata
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3 font-bold w-12 text-center">No</th>
                <th className="py-2.5 px-3 font-bold w-20 text-center">NIS</th>
                <th className="py-2.5 px-3 font-bold">Nama Lengkap Siswa</th>
                <th className="py-2.5 px-3 font-bold w-14 text-center">L/P</th>
                <th className="py-2.5 px-3 font-bold w-24">Kelas</th>
                <th className="py-2.5 px-3 font-bold text-center">Masuk</th>
                <th className="py-2.5 px-3 font-bold text-center">Pulang</th>
                <th className="py-2.5 px-3 font-bold text-center">Dhuhur</th>
                <th className="py-2.5 px-3 font-bold text-center">Jumat (L)</th>
                <th className="py-2.5 px-3 font-bold text-center">Keputrian (P)</th>
                <th className="py-2.5 px-3 font-bold">Keterangan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-8 text-center text-slate-400">
                    Tidak ada data siswa yang cocok dengan filter.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((st, idx) => (
                  <tr 
                    key={st.id} 
                    className={`hover:bg-blue-50/40 transition-colors ${
                      st.exemptReligious ? 'bg-amber-50/20' : ''
                    }`}
                  >
                    <td className="py-2.5 px-3 text-center text-slate-500 font-mono">
                      {idx + 1}
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono font-medium text-slate-700">
                      {st.nis}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900">
                      {st.name}
                      {st.exemptReligious && (
                        <span className="ml-2 text-[10px] font-bold px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded">
                          Non-Muslim
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold">
                      <span className={st.gender === 'L' ? 'text-blue-700' : 'text-rose-700'}>
                        {st.gender}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 font-medium">
                      {st.className}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {getStudentStatusBadge(st, 'masuk')}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {getStudentStatusBadge(st, 'pulang')}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {getStudentStatusBadge(st, 'dhuhur')}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {getStudentStatusBadge(st, 'jumat')}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {getStudentStatusBadge(st, 'keputrian')}
                    </td>
                    <td className="py-2.5 px-3 text-[11px] text-slate-500">
                      {st.exemptReligious ? (
                        <span className="text-amber-800 font-medium">
                          Reguler (Sholat &amp; Keputrian Dikosongi)
                        </span>
                      ) : (
                        'Aktif'
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
