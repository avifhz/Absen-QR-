import React, { useState, useEffect, useMemo } from 'react';
import { 
  ClipboardCheck, 
  CheckCheck, 
  Calendar, 
  Clock, 
  Save, 
  Users, 
  AlertTriangle, 
  ShieldAlert, 
  Lock, 
  Unlock,
  CheckCircle2,
  LogIn,
  LogOut,
  Sun,
  Moon,
  HeartHandshake
} from 'lucide-react';
import { 
  Student, 
  AttendanceRecord, 
  AttendanceType, 
  ATTENDANCE_TYPES, 
  SCHOOL_CLASSES,
  isFridayPrayerTimeWindow,
  isStudentExemptFromReligious,
  getScheduleValidity
} from '../data/studentsData';
import { submitAttendance, getTodayDateStr, formatIndoDate } from '../services/attendanceService';
import { playChimeSound } from '../utils/audio';

interface AbsenManualTabProps {
  students: Student[];
  records: AttendanceRecord[];
  onAttendanceSaved?: () => void;
}

export const AbsenManualTab: React.FC<AbsenManualTabProps> = ({
  students,
  records,
  onAttendanceSaved
}) => {
  const [selectedClass, setSelectedClass] = useState<string>('7 Kutai');
  const [selectedType, setSelectedType] = useState<AttendanceType>('masuk');
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateStr());
  const [allowTeacherOverride, setAllowTeacherOverride] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Per-student attendance state in manual table: nis -> { status, notes }
  const [attendanceState, setAttendanceState] = useState<Record<string, {
    status: 'hadir' | 'terlambat' | 'izin' | 'sakit' | 'alpa' | 'haid';
    notes: string;
  }>>({});

  // Check schedule validity based on selected date and session type
  const scheduleCheck = useMemo(() => {
    if (selectedDate) {
      const [y, m, d] = selectedDate.split('-').map(Number);
      const target = new Date(y, m - 1, d, 12, 0, 0);
      return getScheduleValidity(selectedType, target);
    }
    return getScheduleValidity(selectedType);
  }, [selectedType, selectedDate]);

  const isScheduleLocked = !scheduleCheck.isValid && !allowTeacherOverride;

  // Filter students by selected class
  const classStudents = useMemo(() => {
    return students.filter(s => s.className === selectedClass);
  }, [students, selectedClass]);

  // Load existing records for this class, date, and type into state
  useEffect(() => {
    const existingMap: Record<string, { status: any; notes: string }> = {};

    for (const st of classStudents) {
      const rec = records.find(r => 
        r.studentNis === st.nis && 
        r.date === selectedDate && 
        r.type === selectedType
      );

      if (rec) {
        existingMap[st.nis] = {
          status: rec.status === 'dikecualikan' ? 'hadir' : rec.status,
          notes: rec.notes || ''
        };
      } else {
        // default status
        existingMap[st.nis] = {
          status: 'hadir',
          notes: ''
        };
      }
    }

    setAttendanceState(existingMap);
    setSaveSuccessMsg(null);
  }, [classStudents, selectedDate, selectedType, records]);

  // Quick action: Set all students to Hadir
  const handleMarkAllHadir = () => {
    const next: Record<string, { status: any; notes: string }> = {};
    for (const st of classStudents) {
      next[st.nis] = {
        status: 'hadir',
        notes: attendanceState[st.nis]?.notes || ''
      };
    }
    setAttendanceState(next);
  };

  // Change individual student status
  const handleSetStudentStatus = (nis: string, status: 'hadir' | 'terlambat' | 'izin' | 'sakit' | 'alpa' | 'haid') => {
    setAttendanceState(prev => ({
      ...prev,
      [nis]: {
        ...prev[nis],
        status
      }
    }));
  };

  // Change individual student notes
  const handleSetStudentNotes = (nis: string, notes: string) => {
    setAttendanceState(prev => ({
      ...prev,
      [nis]: {
        ...prev[nis],
        notes
      }
    }));
  };

  // Save manual attendance for the entire class to Firestore
  const handleSaveClassAttendance = async () => {
    if (selectedType === 'dhuhur') {
      const dhuhurCheck = getScheduleValidity('dhuhur');
      if (!dhuhurCheck.isValid) {
        alert(dhuhurCheck.reason || 'Presensi Sholat Dhuhur Berjamaah terkunci total di luar pukul 11:50 - 12:30 WIB.');
        return;
      }
    } else if (isScheduleLocked) {
      alert(`${scheduleCheck.reason || 'Sesi presensi di luar jadwal operasional.'} Aktifkan tombol 'Buka Paksa Sesi (Input Susulan Guru)' jika ingin input data susulan.`);
      return;
    }

    setIsSaving(true);
    let savedCount = 0;

    try {
      for (const st of classStudents) {
        // Skip religious attendance for exempted students (Jevanya and Diva Widiana)
        if (isStudentExemptFromReligious(st, selectedType)) {
          continue;
        }

        // Skip gender mismatch for Friday prayer / Keputrian
        if (selectedType === 'jumat' && st.gender !== 'L') continue;
        if (selectedType === 'keputrian' && st.gender !== 'P') continue;

        const studentData = attendanceState[st.nis] || { status: 'hadir', notes: '' };

        await submitAttendance({
          student: st,
          type: selectedType,
          overrideStatus: studentData.status,
          notes: studentData.notes,
          method: 'MANUAL_SHEET',
          dateOverride: selectedDate,
          bypassScheduleCheck: allowTeacherOverride
        });

        savedCount++;
      }

      playChimeSound('bell');
      setSaveSuccessMsg(`Berhasil menyimpan presensi ${selectedType.toUpperCase()} untuk ${savedCount} siswa Kelas ${selectedClass}!`);
      if (onAttendanceSaved) onAttendanceSaved();
      setTimeout(() => setSaveSuccessMsg(null), 5000);
    } catch (err) {
      console.error(err);
      alert("Terjadi kesalahan saat menyimpan presensi manual.");
    } finally {
      setIsSaving(false);
    }
  };

  const getTypeIcon = (type: AttendanceType) => {
    switch (type) {
      case 'masuk': return <LogIn className="w-4 h-4 text-emerald-600" />;
      case 'pulang': return <LogOut className="w-4 h-4 text-blue-600" />;
      case 'dhuhur': return <Sun className="w-4 h-4 text-amber-500" />;
      case 'jumat': return <Moon className="w-4 h-4 text-indigo-600" />;
      case 'keputrian': return <HeartHandshake className="w-4 h-4 text-rose-500" />;
    }
  };

  // Counts of current statuses in the manual sheet
  const summaryCounts = useMemo(() => {
    let hadir = 0, terlambat = 0, izin = 0, sakit = 0, alpa = 0, haid = 0;
    for (const st of classStudents) {
      if (isStudentExemptFromReligious(st, selectedType)) continue;
      if (selectedType === 'jumat' && st.gender !== 'L') continue;
      if (selectedType === 'keputrian' && st.gender !== 'P') continue;

      const curr = attendanceState[st.nis]?.status || 'hadir';
      if (curr === 'hadir') hadir++;
      else if (curr === 'terlambat') terlambat++;
      else if (curr === 'izin') izin++;
      else if (curr === 'sakit') sakit++;
      else if (curr === 'alpa') alpa++;
      else if (curr === 'haid') haid++;
    }
    return { hadir, terlambat, izin, sakit, alpa, haid };
  }, [classStudents, attendanceState, selectedType]);

  return (
    <div className="space-y-6">
      {/* Header & Controls Panel */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <ClipboardCheck className="w-5 h-5 text-blue-600" />
              Lembar Absensi Manual Per Kelas
            </h2>
            <p className="text-xs text-slate-500">
              Guru piket atau wali kelas dapat melakukan presensi checklist sekaligus untuk seluruh siswa dalam satu kelas
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleMarkAllHadir}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              <CheckCheck className="w-4 h-4 text-emerald-600" />
              <span>Tandai Semua Hadir</span>
            </button>

            <button
              onClick={handleSaveClassAttendance}
              disabled={isSaving}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Menyimpan...' : 'Simpan Absen Kelas'}</span>
            </button>
          </div>
        </div>

        {/* Filters: Class, Session Type, Date */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-100">
          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Pilih Kelas:
            </label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full px-3 py-2 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              {SCHOOL_CLASSES.map(cls => (
                <option key={cls} value={cls}>
                  Kelas {cls} ({students.filter(s => s.className === cls).length} Siswa)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Sesi Kegiatan:
            </label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value as AttendanceType)}
              className="w-full px-3 py-2 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              {ATTENDANCE_TYPES.map(t => (
                <option key={t.id} value={t.id}>
                  {t.label} ({t.desc})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Tanggal Presensi:
            </label>
            <div className="relative">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Schedule Validity Status Notice: Senin-Jumat, Dhuhur Senin-Kamis, Jumat Khusus Jumat, Sabtu/Minggu Libur */}
        {(!scheduleCheck.isValid || allowTeacherOverride) && (
          <div className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
            allowTeacherOverride
              ? 'bg-purple-50 border-purple-300 text-purple-950'
              : 'bg-amber-50 border-amber-300 text-amber-950'
          }`}>
            <div className="flex items-start gap-2.5">
              {allowTeacherOverride ? (
                <Unlock className="w-5 h-5 text-purple-600 shrink-0 mt-0.5" />
              ) : (
                <Lock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              )}
              <div>
                <div className="font-extrabold flex items-center gap-1.5">
                  <span>
                    {scheduleCheck.isWeekend
                      ? `Pemberitahuan: Hari ${scheduleCheck.dayName} (Siswa Libur Akhir Pekan)`
                      : selectedType === 'dhuhur'
                      ? 'Jadwal Sholat Dhuhur Berjamaah: Senin s/d Kamis (11:50 - 12:30 WIB)'
                      : selectedType === 'jumat' || selectedType === 'keputrian'
                      ? 'Jadwal Khusus: Hari Jumat Pukul 11:15 - 12:30 WIB'
                      : 'Jadwal Sekolah: Hari Senin s/d Jumat'}
                  </span>
                  {allowTeacherOverride && selectedType !== 'dhuhur' && (
                    <span className="px-1.5 py-0.2 bg-purple-200 text-purple-900 rounded text-[10px] font-bold">
                      Mode Susulan Guru Aktif
                    </span>
                  )}
                  {selectedType === 'dhuhur' && (
                    <span className="px-1.5 py-0.2 bg-rose-200 text-rose-900 rounded text-[10px] font-bold">
                      Terkunci Total &bull; Tanpa Buka Paksa
                    </span>
                  )}
                </div>
                <p className="text-[11px] mt-0.5">
                  {allowTeacherOverride && selectedType !== 'dhuhur'
                    ? `Sesi ${selectedType.toUpperCase()} dibuka paksa dengan izin guru. Anda dapat mengisi absensi lembar manual untuk data susulan.`
                    : scheduleCheck.reason}
                </p>
              </div>
            </div>

            {/* Teacher Override Toggle (Hidden for Dhuhur) */}
            {selectedType !== 'dhuhur' && (
              <button
                type="button"
                onClick={() => setAllowTeacherOverride(!allowTeacherOverride)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer whitespace-nowrap self-end sm:self-center ${
                  allowTeacherOverride
                    ? 'bg-purple-600 text-white border-purple-700 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                }`}
              >
                {allowTeacherOverride ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                <span>{allowTeacherOverride ? 'Kunci Jadwal Kembali' : 'Buka Paksa Sesi (Input Susulan Guru)'}</span>
              </button>
            )}
          </div>
        )}

        {/* Special Exemption Alert */}
        <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 flex items-start gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <strong>Ketentuan Khusus:</strong> Untuk <span className="font-bold underline">Maximilianus Wahyu Galih Pradana (7 Kutai)</span>, <span className="font-bold underline">Diva Widiana (7 Mataram)</span>, dan <span className="font-bold underline">Jevanya Anastasya Blegur (9 Mataram)</span>, opsi Sholat Dhuhur, Sholat Jumat, dan Keputrian otomatis <strong>dikosongi / dikecualikan</strong> sesuai ketentuan sekolah.
          </div>
        </div>

        {/* Quick Summary Pill Counters */}
        <div className="flex flex-wrap items-center gap-2 text-xs pt-1">
          <span className="font-bold text-slate-600">Ringkasan Sementara:</span>
          <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 font-bold">
            Hadir: {summaryCounts.hadir}
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-800 font-bold">
            Terlambat: {summaryCounts.terlambat}
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-blue-100 text-blue-800 font-bold">
            Izin: {summaryCounts.izin}
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-violet-100 text-violet-800 font-bold">
            Sakit: {summaryCounts.sakit}
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-rose-100 text-rose-800 font-bold">
            Alpa: {summaryCounts.alpa}
          </span>
          {selectedType === 'dhuhur' && (
            <span className="px-2.5 py-1 rounded-lg bg-pink-100 text-pink-800 font-bold border border-pink-200">
              Haid (Siswi): {summaryCounts.haid}
            </span>
          )}
        </div>
      </div>

      {/* Save Success Banner */}
      {saveSuccessMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl text-emerald-950 font-bold text-xs sm:text-sm flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span>{saveSuccessMsg}</span>
          </div>
          <button 
            onClick={() => setSaveSuccessMsg(null)}
            className="text-xs underline text-emerald-800 cursor-pointer"
          >
            Tutup
          </button>
        </div>
      )}

      {/* Students Checklist Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {getTypeIcon(selectedType)}
            <h3 className="font-bold text-slate-900 text-sm">
              Daftar Siswa Kelas {selectedClass} &bull; Sesi {selectedType.toUpperCase()} ({formatIndoDate(selectedDate)})
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            {classStudents.length} Siswa Terdaftar
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3 font-bold w-12 text-center">No</th>
                <th className="py-2.5 px-3 font-bold w-20 text-center">NIS</th>
                <th className="py-2.5 px-3 font-bold">Nama Siswa</th>
                <th className="py-2.5 px-3 font-bold w-14 text-center">L/P</th>
                <th className="py-2.5 px-3 font-bold text-center">Pilih Status Presensi</th>
                <th className="py-2.5 px-3 font-bold w-48">Keterangan / Alasan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {classStudents.map((st, idx) => {
                const isExempt = isStudentExemptFromReligious(st, selectedType);
                const isGenderMismatch = (selectedType === 'jumat' && st.gender !== 'L') || (selectedType === 'keputrian' && st.gender !== 'P');
                const currState = attendanceState[st.nis] || { status: 'hadir', notes: '' };

                return (
                  <tr 
                    key={st.id} 
                    className={`hover:bg-slate-50/70 transition-colors ${
                      isExempt ? 'bg-amber-50/20' : ''
                    }`}
                  >
                    <td className="py-2.5 px-3 text-center text-slate-500 font-mono">
                      {idx + 1}
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono font-bold text-slate-800">
                      {st.nis}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900">
                      <div className="flex items-center gap-1.5">
                        <span>{st.name}</span>
                        {st.exemptReligious && (
                          <span className="text-[10px] font-bold px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded">
                            Non-Muslim
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className={`font-bold px-2 py-0.5 rounded text-[10px] ${
                        st.gender === 'L' ? 'bg-blue-50 text-blue-700' : 'bg-rose-50 text-rose-700'
                      }`}>
                        {st.gender}
                      </span>
                    </td>

                    {/* Status Buttons */}
                    <td className="py-2.5 px-3">
                      {isExempt ? (
                        <div className="text-center py-1">
                          <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                            - Dikecualikan (Sholat &amp; Keputrian Dikosongi) -
                          </span>
                        </div>
                      ) : isGenderMismatch ? (
                        <div className="text-center py-1">
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-400">
                            Tidak wajib ({selectedType === 'jumat' ? 'Khusus L' : 'Khusus P'})
                          </span>
                        </div>
                      ) : (
                        <div className="flex flex-wrap items-center justify-center gap-1">
                          {[
                            { id: 'hadir', label: 'Hadir', activeColor: 'bg-emerald-600 text-white shadow-xs' },
                            { id: 'terlambat', label: 'Terlambat', activeColor: 'bg-amber-600 text-white shadow-xs' },
                            { id: 'izin', label: 'Izin', activeColor: 'bg-blue-600 text-white shadow-xs' },
                            { id: 'sakit', label: 'Sakit', activeColor: 'bg-violet-600 text-white shadow-xs' },
                            { id: 'alpa', label: 'Alpa', activeColor: 'bg-rose-600 text-white shadow-xs' },
                            ...(selectedType === 'dhuhur' && st.gender === 'P'
                              ? [{ id: 'haid', label: 'Haid', activeColor: 'bg-pink-600 text-white shadow-xs' }]
                              : []
                            ),
                          ].map(btn => (
                            <button
                              key={btn.id}
                              type="button"
                              onClick={() => handleSetStudentStatus(st.nis, btn.id as any)}
                              className={`px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                                currState.status === btn.id
                                  ? btn.activeColor
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              }`}
                            >
                              {btn.label}
                            </button>
                          ))}
                        </div>
                      )}
                    </td>

                    {/* Notes Input */}
                    <td className="py-2.5 px-3">
                      {!isExempt && !isGenderMismatch ? (
                        <input
                          type="text"
                          placeholder="Catatan..."
                          value={currState.notes}
                          onChange={(e) => handleSetStudentNotes(st.nis, e.target.value)}
                          className="w-full px-2 py-1 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium"
                        />
                      ) : (
                        <span className="text-slate-300 font-mono">-</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer Action */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-500">
            Pastikan data sudah sesuai sebelum menekan tombol simpan ke Firebase Firestore.
          </div>
          <button
            onClick={handleSaveClassAttendance}
            disabled={isSaving || (selectedType === 'dhuhur' && !scheduleCheck.isValid)}
            className="w-full sm:w-auto px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all cursor-pointer disabled:opacity-50 disabled:bg-slate-400 flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>
              {isSaving 
                ? 'Menyimpan ke Firestore...' 
                : (selectedType === 'dhuhur' && !scheduleCheck.isValid)
                ? 'Sesi Sholat Dhuhur Terkunci (11:50 - 12:30 WIB)'
                : `Simpan Presensi Kelas ${selectedClass}`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
