import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  UserCheck, 
  ShieldAlert, 
  GraduationCap, 
  Check, 
  Layers,
  Phone,
  MessageCircle,
  Edit2,
  Save,
  X,
  CheckCircle2,
  AlertCircle,
  Trash2
} from 'lucide-react';
import { Student, SCHOOL_CLASSES } from '../data/studentsData';
import { updateStudentParentPhone, clearParentPhones } from '../services/attendanceService';
import { generateWaMeLink } from '../services/whatsappService';

interface StudentsListTabProps {
  students: Student[];
}

export const StudentsListTab: React.FC<StudentsListTabProps> = ({ students }) => {
  const [selectedClass, setSelectedClass] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedGender, setSelectedGender] = useState<'ALL' | 'L' | 'P'>('ALL');
  const [waFilter, setWaFilter] = useState<'ALL' | 'HAS_WA' | 'NO_WA'>('ALL');

  // Inline editing state for parent phone
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [phoneInput, setPhoneInput] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [feedbackNotice, setFeedbackNotice] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const filteredStudents = students.filter(st => {
    const matchesClass = selectedClass === 'ALL' || st.className === selectedClass;
    const matchesGender = selectedGender === 'ALL' || st.gender === selectedGender;
    const matchesQuery = !searchQuery.trim() || 
      st.nis.toLowerCase().includes(searchQuery.toLowerCase()) ||
      st.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (st.parentPhone && st.parentPhone.includes(searchQuery.trim()));
    
    const hasWa = Boolean(st.parentPhone && st.parentPhone.trim().length >= 8);
    const matchesWa = 
      waFilter === 'ALL' ? true :
      waFilter === 'HAS_WA' ? hasWa : !hasWa;

    return matchesClass && matchesGender && matchesQuery && matchesWa;
  });

  const totalMale = students.filter(s => s.gender === 'L').length;
  const totalFemale = students.filter(s => s.gender === 'P').length;
  const totalWithWa = students.filter(s => s.parentPhone && s.parentPhone.trim().length >= 8).length;
  const totalWithoutWa = students.length - totalWithWa;

  const handleStartEdit = (student: Student) => {
    setEditingStudentId(student.id);
    setPhoneInput(student.parentPhone || '');
  };

  const handleCancelEdit = () => {
    setEditingStudentId(null);
    setPhoneInput('');
  };

  const handleSavePhone = async (studentId: string, studentName: string) => {
    setIsSaving(true);
    const cleanNumber = phoneInput.trim();
    const success = await updateStudentParentPhone(studentId, cleanNumber);
    setIsSaving(false);

    if (success) {
      setFeedbackNotice({
        type: 'success',
        message: `Nomor WhatsApp orang tua ${studentName} berhasil disimpan ke Firebase!`
      });
      setEditingStudentId(null);
    } else {
      setFeedbackNotice({
        type: 'error',
        message: `Gagal menyimpan nomor WhatsApp. Periksa koneksi internet.`
      });
    }

    setTimeout(() => {
      setFeedbackNotice(null);
    }, 4000);
  };

  const handleClearTestPhones = async () => {
    if (!confirm('Hapus seluruh nomor WhatsApp 628139152310 dari database siswa di Firebase Firestore?')) {
      return;
    }
    setIsSaving(true);
    const count = await clearParentPhones('628139152310');
    setIsSaving(false);
    setFeedbackNotice({
      type: 'success',
      message: `Berhasil menghapus nomor WhatsApp 628139152310 dari ${count} data siswa di Firebase Firestore!`
    });
    setTimeout(() => {
      setFeedbackNotice(null);
    }, 4000);
  };

  return (
    <div className="space-y-6">
      {/* Feedback Toast Notice */}
      {feedbackNotice && (
        <div className={`p-4 rounded-2xl flex items-center gap-3 border shadow-sm transition-all ${
          feedbackNotice.type === 'success' 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-900' 
            : 'bg-rose-50 border-rose-200 text-rose-900'
        }`}>
          {feedbackNotice.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          )}
          <span className="text-xs font-semibold">{feedbackNotice.message}</span>
          <button 
            onClick={() => setFeedbackNotice(null)} 
            className="ml-auto text-slate-400 hover:text-slate-600"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Stats Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Total Siswa</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {students.length}
          </div>
          <span className="text-[11px] text-slate-500">14 Rombongan Belajar</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-emerald-600 mb-2">
            <span className="text-xs font-semibold text-slate-700">Terhubung WhatsApp</span>
            <MessageCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-700 font-mono">
            {totalWithWa}
          </div>
          <span className="text-[11px] text-emerald-700 font-medium">Siap Terima Notifikasi</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-amber-600 mb-2">
            <span className="text-xs font-semibold text-slate-700">Belum Ada No WA</span>
            <Phone className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-amber-700 font-mono">
            {totalWithoutWa}
          </div>
          <span className="text-[11px] text-amber-800 font-medium">Perlu Diinputkan Guru</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-blue-600 mb-2">
            <span className="text-xs font-semibold text-slate-700">L / P &amp; Pengecualian</span>
            <GraduationCap className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-base font-bold text-slate-800 font-mono mt-1">
            {totalMale} L / {totalFemale} P
          </div>
          <span className="text-[11px] text-slate-500">3 Siswa Non-Muslim</span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 p-5 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-blue-600" />
              Master Data Siswa &amp; Nomor WhatsApp Orang Tua
            </h2>
            <p className="text-xs text-slate-500">
              Inputkan nomor WhatsApp orang tua/wali siswa untuk menerima notifikasi presensi otomatis atau kirim pesan 1-klik.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {students.some(s => s.parentPhone && (s.parentPhone.includes('8139152310') || s.parentPhone.includes('82139152310'))) && (
              <button
                onClick={handleClearTestPhones}
                disabled={isSaving}
                className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
                title="Hapus nomor WhatsApp 628139152310 dari seluruh data siswa"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus No. 628139152310 dari Siswa</span>
              </button>
            )}
            <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold rounded-xl shrink-0 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Tersimpan di Firebase Firestore
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-100">
          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Pilih Kelas:
            </label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="ALL">Semua Kelas ({students.length} Siswa)</option>
              {SCHOOL_CLASSES.map(cls => (
                <option key={cls} value={cls}>
                  Kelas {cls} ({students.filter(s => s.className === cls).length} Siswa)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Status No. WhatsApp:
            </label>
            <select
              value={waFilter}
              onChange={(e) => setWaFilter(e.target.value as any)}
              className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="ALL">Semua ({students.length})</option>
              <option value="HAS_WA">Sudah Ada No WA ({totalWithWa})</option>
              <option value="NO_WA">Belum Ada No WA ({totalWithoutWa})</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Jenis Kelamin:
            </label>
            <select
              value={selectedGender}
              onChange={(e) => setSelectedGender(e.target.value as any)}
              className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="ALL">Semua Gender</option>
              <option value="L">Laki-laki (L)</option>
              <option value="P">Perempuan (P)</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              Cari Siswa / No WA:
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="Nama, NIS, atau No HP..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>
        </div>
      </div>

      {/* Students Table with WhatsApp Column */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-bold text-slate-900 text-sm">
            Tabel Siswa ({filteredStudents.length} siswa ditampilkan)
          </h3>
          <span className="text-xs text-slate-500">
            SMP Negeri 1 Kalipare &bull; Klik ikon pensil untuk mengisi/mengubah No WA orang tua
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3 font-bold w-12 text-center">No</th>
                <th className="py-2.5 px-3 font-bold w-20 text-center">NIS</th>
                <th className="py-2.5 px-3 font-bold">Nama Siswa</th>
                <th className="py-2.5 px-3 font-bold w-16 text-center">L/P</th>
                <th className="py-2.5 px-3 font-bold w-24">Kelas</th>
                <th className="py-2.5 px-3 font-bold min-w-[240px]">
                  WhatsApp Orang Tua / Wali
                </th>
                <th className="py-2.5 px-3 font-bold text-center w-28">Aksi Cepat</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    Tidak ada siswa yang sesuai dengan filter pencarian.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((st, idx) => {
                  const isEditing = editingStudentId === st.id;
                  const hasPhone = Boolean(st.parentPhone && st.parentPhone.trim().length >= 8);
                  const waGreeting = `Yth. Bapak/Ibu Wali Murid dari ${st.name} (${st.className}), kami dari pihak SMP Negeri 1 Kalipare menginformasikan...`;
                  const waLink = hasPhone ? generateWaMeLink(st.parentPhone!, waGreeting) : '#';

                  return (
                    <tr key={st.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-2.5 px-3 text-center text-slate-500 font-mono">
                        {idx + 1}
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono font-bold text-slate-800">
                        {st.nis}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-slate-900">{st.name}</div>
                        {st.exemptReligious && (
                          <span className="inline-block px-1.5 py-0.2 rounded text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                            Non-Muslim (Masuk &amp; Pulang)
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`font-bold px-2 py-0.5 rounded text-[10px] ${
                          st.gender === 'L' ? 'bg-blue-50 text-blue-700' : 'bg-rose-50 text-rose-700'
                        }`}>
                          {st.gender === 'L' ? 'L' : 'P'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-700">
                        {st.className}
                      </td>

                      {/* WhatsApp Phone Number Column with Inline Edit */}
                      <td className="py-2.5 px-3">
                        {isEditing ? (
                          <div className="flex items-center gap-1.5">
                            <input
                              type="tel"
                              value={phoneInput}
                              onChange={(e) => setPhoneInput(e.target.value)}
                              placeholder="08123456789..."
                              autoFocus
                              className="px-2.5 py-1 text-xs border border-blue-400 rounded-lg focus:ring-2 focus:ring-blue-500 font-mono w-36 bg-blue-50/30"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleSavePhone(st.id, st.name);
                                if (e.key === 'Escape') handleCancelEdit();
                              }}
                            />
                            <button
                              onClick={() => handleSavePhone(st.id, st.name)}
                              disabled={isSaving}
                              className="p-1 rounded-md bg-emerald-600 text-white hover:bg-emerald-700 shadow-xs text-xs flex items-center justify-center disabled:opacity-50"
                              title="Simpan ke Firebase"
                            >
                              <Save className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={handleCancelEdit}
                              className="p-1 rounded-md bg-slate-200 text-slate-700 hover:bg-slate-300 text-xs"
                              title="Batal"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            {hasPhone ? (
                              <span className="font-mono font-semibold text-slate-800 bg-slate-100 px-2 py-0.5 rounded-lg border border-slate-200 text-xs flex items-center gap-1">
                                <Phone className="w-3 h-3 text-slate-500" />
                                {st.parentPhone}
                              </span>
                            ) : (
                              <span className="text-[11px] text-amber-600 font-medium italic flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" />
                                Belum diisi
                              </span>
                            )}
                            <button
                              onClick={() => handleStartEdit(st)}
                              className="p-1 rounded-md text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                              title="Edit Nomor WhatsApp Orang Tua"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>

                      {/* Direct WhatsApp Action */}
                      <td className="py-2.5 px-3 text-center">
                        {hasPhone ? (
                          <a
                            href={waLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold bg-emerald-500 hover:bg-emerald-600 text-white shadow-xs transition-colors"
                            title="Buka WhatsApp Chat Langsung"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>Kirim WA</span>
                          </a>
                        ) : (
                          <button
                            onClick={() => handleStartEdit(st)}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold text-slate-500 bg-slate-100 hover:bg-slate-200"
                          >
                            + Tambah No
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
