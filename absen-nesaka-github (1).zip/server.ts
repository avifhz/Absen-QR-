import express from 'express';
import dotenv from 'dotenv';
import fs from 'fs';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Server-side Fonnte token resolution (never exposed in plaintext to client)
let serverRuntimeFonnteToken = (process.env.FONNTE_TOKEN || '').trim();

function getEffectiveFonnteToken(clientProvidedKey?: string): string {
  if (process.env.FONNTE_TOKEN && process.env.FONNTE_TOKEN.trim()) {
    return process.env.FONNTE_TOKEN.trim();
  }
  if (serverRuntimeFonnteToken) {
    return serverRuntimeFonnteToken;
  }
  if (clientProvidedKey && clientProvidedKey.trim()) {
    serverRuntimeFonnteToken = clientProvidedKey.trim();
    return serverRuntimeFonnteToken;
  }
  return '';
}

function maskToken(token: string): string {
  if (!token) return '';
  if (token.length <= 6) return '••••••';
  return `${token.substring(0, 3)}••••••••${token.slice(-3)}`;
}

function cleanPhone(phone: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '62' + cleaned.substring(1);
  } else if (cleaned.startsWith('8')) {
    cleaned = '628' + cleaned.substring(1);
  }
  return cleaned;
}

// 1. GET /api/whatsapp/status
app.get('/api/whatsapp/status', async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  const queryToken = typeof req.query.token === 'string' ? req.query.token.trim() : undefined;
  const token = getEffectiveFonnteToken(queryToken);

  if (!token) {
    return res.status(200).json({
      configured: false,
      connected: false,
      status: 'unconfigured',
      message: 'Token Fonnte belum dikonfigurasi di server Secret atau pengaturan.',
      maskedToken: ''
    });
  }

  try {
    const deviceRes = await fetch('https://api.fonnte.com/device', {
      method: 'POST',
      headers: {
        'Authorization': token
      }
    });

    const deviceData = await deviceRes.json().catch(() => ({}));

    if (deviceRes.ok && deviceData.status === true) {
      const isConnect = String(deviceData.device_status || '').toLowerCase() === 'connect';
      return res.status(200).json({
        configured: true,
        connected: isConnect,
        device_status: deviceData.device_status || 'connected',
        device: deviceData.device || '',
        name: deviceData.name || '',
        message: isConnect 
          ? 'Perangkat WhatsApp Guru terhubung & siap kirim.' 
          : 'Perangkat Fonnte terdaftar namun belum terhubung (QR belum di-scan di fonnte.com).',
        maskedToken: maskToken(token)
      });
    } else {
      return res.status(200).json({
        configured: true,
        connected: false,
        device_status: 'disconnected',
        message: deviceData.reason || 'Token tidak valid atau perangkat tidak terhubung di Fonnte.',
        maskedToken: maskToken(token)
      });
    }
  } catch (err: any) {
    return res.status(200).json({
      configured: true,
      connected: false,
      status: 'network_error',
      message: 'Gagal menghubungi server Fonnte: ' + (err.message || 'Network error'),
      maskedToken: maskToken(token)
    });
  }
});

// 2. GET & POST /api/whatsapp/config
app.get('/api/whatsapp/config', (req, res) => {
  const token = getEffectiveFonnteToken();
  res.json({
    hasToken: Boolean(token),
    isEnvToken: Boolean(process.env.FONNTE_TOKEN && process.env.FONNTE_TOKEN.trim()),
    maskedToken: maskToken(token)
  });
});

app.post('/api/whatsapp/config', (req, res) => {
  const { token } = req.body || {};
  if (token && typeof token === 'string') {
    serverRuntimeFonnteToken = token.trim();
  }
  const currentToken = getEffectiveFonnteToken();
  res.json({
    success: true,
    hasToken: Boolean(currentToken),
    maskedToken: maskToken(currentToken),
    message: 'Token Fonnte berhasil disimpan di sisi server.'
  });
});

// Global multi-phone deduplication cache for WhatsApp attendance notifications (24h TTL)
const sentWaCache = new Map<string, number>();

function cleanupSentWaCache() {
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  for (const [key, ts] of sentWaCache.entries()) {
    if (ts < cutoff) sentWaCache.delete(key);
  }
}

// 3. POST /api/whatsapp/send
app.post('/api/whatsapp/send', async (req, res) => {
  const { target, message, apiKey, recordId, delay } = req.body || {};

  if (!target || !message) {
    return res.status(400).json({ status: false, reason: 'Nomor tujuan dan pesan wajib diisi' });
  }

  const cleanTarget = cleanPhone(target);
  if (!cleanTarget || cleanTarget.length < 9) {
    return res.status(400).json({ status: false, reason: 'Nomor WhatsApp tidak valid (contoh: 081234567890)' });
  }

  // Server-wide idempotency guard across all concurrent teachers' phones
  let dedupKey = '';
  if (recordId && typeof recordId === 'string') {
    dedupKey = `${recordId.trim()}::${cleanTarget}`;
    if (sentWaCache.has(dedupKey)) {
      return res.status(200).json({
        status: true,
        success: true,
        deduplicated: true,
        message: `Notifikasi untuk presensi ini ke ${cleanTarget} sudah dikirim sebelumnya (anti-duplikasi server).`
      });
    }
    sentWaCache.set(dedupKey, Date.now());
    if (sentWaCache.size > 5000) cleanupSentWaCache();
  }

  const token = getEffectiveFonnteToken(apiKey);
  if (!token) {
    if (dedupKey) sentWaCache.delete(dedupKey);
    return res.status(400).json({ 
      status: false, 
      reason: 'Token Fonnte belum disetel di server (FONNTE_TOKEN) atau menu Pengaturan WhatsApp.' 
    });
  }

  try {
    const params: Record<string, string> = {
      target: cleanTarget,
      message: message,
      countryCode: '62'
    };
    if (delay && typeof delay === 'string' && delay.trim()) {
      params.delay = delay.trim();
    }

    const formBody = new URLSearchParams(params).toString();

    const apiResponse = await fetch('https://api.fonnte.com/send', {
      method: 'POST',
      headers: {
        'Authorization': token,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: formBody
    });

    const responseData = await apiResponse.json().catch(() => ({}));

    if (apiResponse.ok && (responseData.status === true || responseData.status === 'true' || responseData.status === 'success')) {
      return res.status(200).json({
        status: true,
        success: true,
        message: `Pesan berhasil dikirim ke nomor ${cleanTarget}`,
        detail: responseData
      });
    } else {
      if (dedupKey) sentWaCache.delete(dedupKey);
      return res.status(apiResponse.status || 400).json({
        status: false,
        success: false,
        reason: responseData.reason || responseData.message || 'Gagal mengirim pesan melalui Fonnte',
        detail: responseData
      });
    }
  } catch (err: any) {
    if (dedupKey) sentWaCache.delete(dedupKey);
    return res.status(500).json({ status: false, reason: err.message || 'Server proxy error' });
  }
});

// Explicit download route for Absen_Nesaka.apk
app.get(['/Absen_Nesaka.apk', '/absen_nesaka.apk', '/download/apk', '/api/download/apk'], (_req, res) => {
  const apkPath = path.join(__dirname, 'public', 'Absen_Nesaka.apk');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', 'attachment; filename="Absen_Nesaka.apk"');
  res.sendFile(apkPath);
});

// Explicit download route for GitHub-ready source code ZIP
app.get(['/api/download/github-source.zip', '/download/github-source.zip', '/absen-nesaka-github.zip'], (_req, res) => {
  const publicZipPath = path.join(__dirname, 'public', 'absen-nesaka-github.zip');
  const exportZipPath = path.join(__dirname, 'exports', 'absen-nesaka-github.zip');
  const zipPath = fs.existsSync(publicZipPath) ? publicZipPath : exportZipPath;

  if (!fs.existsSync(zipPath)) {
    return res.status(404).json({ error: 'Arsip kode sumber GitHub belum tersedia.' });
  }
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="absen-nesaka-github.zip"');
  res.sendFile(zipPath);
});

// Start Express server and integrate with Vite
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const httpServer = http.createServer(app);

  if (!isProd) {
    const { createServer } = await import('vite');
    const hmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createServer({
      server: {
        middlewareMode: true,
        hmr: hmrDisabled ? false : { server: httpServer },
        ws: hmrDisabled ? false : { server: httpServer }
      },
      plugins: hmrDisabled
        ? [
            {
              name: 'disable-hmr-client-ws',
              transform(code, id) {
                if (id.includes('vite/dist/client/client.mjs')) {
                  return code.replace(
                    /const transport = normalizeModuleRunnerTransport\(\(\(\) => \{[\s\S]*?\}\)\(\)\);/,
                    'const transport = normalizeModuleRunnerTransport({ connect() {}, disconnect() {}, send() {} });'
                  );
                }
              }
            }
          ]
        : [],
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
