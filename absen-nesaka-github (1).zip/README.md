# 📚 Absen Nesaka — Sistem Presensi QR Code & WhatsApp Gateway

Aplikasi presensi siswa berbasis **QR Code / Barcode**, **Firebase Firestore (Real-Time Multi-HP)**, **PWA / Android APK**, dan **Fonnte WhatsApp Gateway** untuk **SMP Negeri 1 Kalipare**.

---

## ✨ Fitur Utama
- **Scan QR / Barcode Serentak Multi-HP:** Mendukung pemindaian serentak untuk 472+ siswa menggunakan banyak HP guru sekaligus dengan transaksi atomik Firestore (`runTransaction`) anti-bentrok & cache offline.
- **5 Sesi Presensi:** Masuk Sekolah, Kepulangan, Sholat Dhuhur Berjamaah (terkunci 11:50–12:30 WIB Senin–Kamis + mode khusus siswi berhalangan/haid), Sholat Jumat (putra), dan Keputrian (putri), lengkap dengan pengecualian siswa non-Muslim.
- **Integrasi Fonnte WhatsApp Gateway (Server-Side):**
  - Notifikasi WhatsApp otomatis ke Guru & Wali Murid setelah scan berhasil.
  - Anti-duplikasi notifikasi lintas perangkat.
  - Pengiriman rekapitulasi absensi per kelas & pengujian koneksi langsung dari dashboard.
- **Dashboard Live & Rekapitulasi:** Statistik real-time per kelas, export **Excel (.xlsx)**, **PDF**, cetak **Kartu QR Siswa**, serta sinkronisasi **Google Apps Script (Google Sheets)**.
- **Android APK & PWA Ready:** Dapat diinstal di HP Android (`Absen_Nesaka.apk` atau 1-klik PWA).

---

## 🛠️ Teknologi
- **Frontend:** React 19, TypeScript, Tailwind CSS v4, Vite, `vite-plugin-pwa`, `html5-qrcode`
- **Backend Proxy:** Node.js + Express (`server.ts`)
- **Database:** Firebase Firestore (`firebase-applet-config.json`)
- **WhatsApp API:** Fonnte (`https://api.fonnte.com/send`)

---

## 🚀 Cara Menjalankan di Lokal / Server

### 1. Clone Repository
```bash
git clone https://github.com/USERNAME_ANDA/absen-nesaka.git
cd absen-nesaka
```

### 2. Install Dependensi
```bash
npm install
```

### 3. Konfigurasi Environment Variable
Salin file `.env.example` menjadi `.env` lalu isi token Fonnte Anda:
```bash
cp .env.example .env
```
Isi `.env`:
```env
FONNTE_TOKEN="ISI_TOKEN_FONNTE_ANDA_DISINI"
PORT=3000
```
> **Penting:** Jangan pernah meng-upload file `.env` ke GitHub. File `.gitignore` sudah disiapkan untuk melindunginya secara otomatis.

### 4. Jalankan Mode Development
```bash
npm run dev
```
Aplikasi berjalan di `http://localhost:3000`.

### 5. Build & Jalankan Mode Production
```bash
npm run build
NODE_ENV=production npm start
```

---

## ☁️ Cara Deploy dari GitHub (Railway / Render / VPS / Cloud Run)
1. Push repository ini ke GitHub Anda.
2. Hubungkan repository GitHub ke platform hosting pilihan Anda (misalnya **Railway**, **Render**, **Fly.io**, atau **Google Cloud Run**).
3. Tambahkan Environment Variables di pengaturan hosting:
   - `FONNTE_TOKEN` = Token device Fonnte Anda
   - `NODE_ENV` = `production`
4. Setel perintah:
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
5. Deploy aturan keamanan Firestore (`firestore.rules`) jika menggunakan proyek Firebase baru:
   ```bash
   firebase deploy --only firestore:rules
   ```

---

## 🏫 Pengembang / Instansi
**SMP Negeri 1 Kalipare** — Kabupaten Malang, Jawa Timur.
