import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'url';
import { defineConfig, Plugin } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

import dotenv from 'dotenv';
dotenv.config();

const rootDir = fileURLToPath(new URL('.', import.meta.url));

// Server-side token storage in case configured at runtime (persisted in server memory)
let serverRuntimeFonnteToken = (process.env.FONNTE_TOKEN || '').trim();

function getEffectiveFonnteToken(clientProvidedKey?: string): string {
  if (process.env.FONNTE_TOKEN && process.env.FONNTE_TOKEN.trim()) {
    return process.env.FONNTE_TOKEN.trim();
  }
  if (serverRuntimeFonnteToken) {
    return serverRuntimeFonnteToken;
  }
  if (clientProvidedKey && clientProvidedKey.trim()) {
    // Cache runtime token on server
    serverRuntimeFonnteToken = clientProvidedKey.trim();
    return serverRuntimeFonnteToken;
  }
  return '';
}

function maskToken(token: string): string {
  if (!token) return '';
  if (token.length <= 6) return '••••••';
  return `${token.substring(0, 3)}••••••••${token.slice(-3)}`;
}

function cleanPhone(phone: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '62' + cleaned.substring(1);
  } else if (cleaned.startsWith('8')) {
    cleaned = '628' + cleaned.substring(1);
  }
  return cleaned;
}

function whatsappProxyPlugin(): Plugin {
  const attachMiddlewares = (server: any) => {
    // 1. WhatsApp status check endpoint (GET /api/whatsapp/status)
    server.middlewares.use('/api/whatsapp/status', async (req: any, res: any) => {
      if (req.method !== 'GET') {
        res.statusCode = 405;
        res.end('Method Not Allowed');
        return;
      }

      res.setHeader('Content-Type', 'application/json');
      const url = new URL(req.url || '/', 'http://localhost');
      const queryToken = url.searchParams.get('token');
      const token = getEffectiveFonnteToken(queryToken || undefined);

        if (!token) {
          res.statusCode = 200;
          res.end(JSON.stringify({
            configured: false,
            connected: false,
            status: 'unconfigured',
            message: 'Token Fonnte belum dikonfigurasi di server Secret atau pengaturan.',
            maskedToken: ''
          }));
          return;
        }

        try {
          // Check Fonnte official device API endpoint
          const deviceRes = await fetch('https://api.fonnte.com/device', {
            method: 'POST',
            headers: {
              'Authorization': token
            }
          });

          const deviceData = await deviceRes.json().catch(() => ({}));

          if (deviceRes.ok && deviceData.status === true) {
            const isConnect = String(deviceData.device_status || '').toLowerCase() === 'connect';
            res.statusCode = 200;
            res.end(JSON.stringify({
              configured: true,
              connected: isConnect,
              device_status: deviceData.device_status || 'connected',
              device: deviceData.device || '',
              name: deviceData.name || '',
              message: isConnect ? 'Perangkat WhatsApp Guru terhubung & siap kirim.' : 'Perangkat Fonnte terdaftar namun belum terhubung (QR belum di-scan).',
              maskedToken: maskToken(token)
            }));
          } else {
            res.statusCode = 200;
            res.end(JSON.stringify({
              configured: true,
              connected: false,
              device_status: 'disconnected',
              message: deviceData.reason || 'Token tidak valid atau perangkat tidak terhubung di Fonnte.',
              maskedToken: maskToken(token)
            }));
          }
        } catch (err: any) {
          res.statusCode = 200;
          res.end(JSON.stringify({
            configured: true,
            connected: false,
            status: 'network_error',
            message: 'Gagal menghubungi server Fonnte: ' + (err.message || 'Network error'),
            maskedToken: maskToken(token)
          }));
        }
      });

      // 2. WhatsApp Config endpoint (GET & POST /api/whatsapp/config)
      server.middlewares.use('/api/whatsapp/config', async (req: any, res: any) => {
        res.setHeader('Content-Type', 'application/json');

        if (req.method === 'GET') {
          const token = getEffectiveFonnteToken();
          res.statusCode = 200;
          res.end(JSON.stringify({
            hasToken: Boolean(token),
            isEnvToken: Boolean(process.env.FONNTE_TOKEN && process.env.FONNTE_TOKEN.trim()),
            maskedToken: maskToken(token)
          }));
          return;
        }

        if (req.method === 'POST') {
          let bodyStr = '';
          req.on('data', (chunk: any) => { bodyStr += chunk; });
          req.on('end', async () => {
            try {
              const body = JSON.parse(bodyStr || '{}');
              if (body.token && typeof body.token === 'string') {
                serverRuntimeFonnteToken = body.token.trim();
              }
              const currentToken = getEffectiveFonnteToken();
              res.statusCode = 200;
              res.end(JSON.stringify({
                success: true,
                hasToken: Boolean(currentToken),
                maskedToken: maskToken(currentToken),
                message: 'Token Fonnte berhasil disimpan di sisi server.'
              }));
            } catch (err: any) {
              res.statusCode = 400;
              res.end(JSON.stringify({ success: false, reason: err.message }));
            }
          });
          return;
        }

        res.statusCode = 405;
        res.end('Method Not Allowed');
      });

      // 3. WhatsApp Send message endpoint (POST /api/whatsapp/send)
      server.middlewares.use('/api/whatsapp/send', async (req: any, res: any) => {
        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.end('Method Not Allowed');
          return;
        }

        let bodyStr = '';
        req.on('data', (chunk: any) => { bodyStr += chunk; });
        req.on('end', async () => {
          try {
            const payload = JSON.parse(bodyStr || '{}');
            const { target, message, apiKey } = payload;

            if (!target || !message) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ status: false, reason: 'Nomor tujuan dan pesan wajib diisi' }));
              return;
            }

            const cleanTarget = cleanPhone(target);
            if (!cleanTarget || cleanTarget.length < 9) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ status: false, reason: 'Nomor WhatsApp tidak valid (contoh: 081234567890)' }));
              return;
            }

            // Server-side token resolution (never exposed to client)
            const token = getEffectiveFonnteToken(apiKey);
            if (!token) {
              res.statusCode = 400;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ 
                status: false, 
                reason: 'Token Fonnte belum disetel di server (FONNTE_TOKEN) atau menu Pengaturan WhatsApp.' 
              }));
              return;
            }

            // Official Fonnte API call from backend
            const formBody = new URLSearchParams({
              target: cleanTarget,
              message: message,
              countryCode: '62'
            }).toString();

            const apiResponse = await fetch('https://api.fonnte.com/send', {
              method: 'POST',
              headers: {
                'Authorization': token,
                'Content-Type': 'application/x-www-form-urlencoded'
              },
              body: formBody
            });

            const responseData = await apiResponse.json().catch(() => ({}));

            res.statusCode = apiResponse.status;
            res.setHeader('Content-Type', 'application/json');

            if (apiResponse.ok && (responseData.status === true || responseData.status === 'true' || responseData.status === 'success')) {
              res.end(JSON.stringify({
                status: true,
                success: true,
                message: `Pesan berhasil dikirim ke nomor ${cleanTarget}`,
                detail: responseData
              }));
            } else {
              res.end(JSON.stringify({
                status: false,
                success: false,
                reason: responseData.reason || responseData.message || 'Gagal mengirim pesan melalui Fonnte',
                detail: responseData
              }));
            }
          } catch (err: any) {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ status: false, reason: err.message || 'Server proxy error' }));
          }
        });
      });
  };

  return {
    name: 'whatsapp-gateway-proxy',
    configureServer: attachMiddlewares,
    configurePreviewServer: attachMiddlewares
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(), 
      tailwindcss(), 
      whatsappProxyPlugin(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon-32x32.png', 'apple-touch-icon.png', 'icon.svg', 'pwa-192x192.png', 'pwa-512x512.png', 'pwa-maskable-512x512.png'],
        manifest: {
          id: '/',
          name: 'Absen Nesaka SMPN 1 Kalipare',
          short_name: 'Absen Nesaka',
          description: 'Aplikasi Absensi QR Code Siswa SMP Negeri 1 Kalipare untuk Masuk, Pulang, dan Ibadah.',
          theme_color: '#1e3a8a',
          background_color: '#f8fafc',
          display: 'standalone',
          orientation: 'portrait-primary',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          maximumFileSizeToCacheInBytes: 10 * 1024 * 1024,
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
          navigateFallbackDenylist: [/^\/api\//, /^\/download\//, /\.zip$/i, /\.apk$/i],
          runtimeCaching: [
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'gstatic-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
          ],
        },
        devOptions: {
          enabled: true,
          type: 'module',
        },
      }),
    ],
    resolve: {
      alias: {
        '@': rootDir,
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
